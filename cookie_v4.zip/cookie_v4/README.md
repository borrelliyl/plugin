# 🍪 Cookie Consent IYL

Plugin WordPress moderno per la gestione del consenso cookie conforme al **GDPR** con interfaccia elegante e multilingua.

![Version](https://img.shields.io/badge/version-4.0-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.0%2B-blue.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-blue.svg)
![License](https://img.shields.io/badge/license-GPL2-green.svg)

---

## 📋 Indice

- [Caratteristiche Principali](#-caratteristiche-principali)
- [Requisiti di Sistema](#-requisiti-di-sistema)
- [Installazione](#-installazione)
- [Configurazione](#-configurazione)
- [Personalizzazione](#-personalizzazione)
- [Integrazione E-commerce](#-integrazione-e-commerce)
- [Supporto Multilingua](#-supporto-multilingua)
- [Sviluppatori](#-sviluppatori)
- [FAQ](#-faq)
- [Supporto](#-supporto)
- [Changelog](#-changelog)
- [Licenza](#-licenza)

---

## ✨ Caratteristiche Principali

### 🔒 **Conformità Normative**
- ✅ **GDPR compliant** - Rispetto completo del Regolamento Generale sulla Protezione dei Dati
- ✅ **Cookie Law italiana** - Conforme alle normative italiane sui cookie
- ✅ **Consent Mode v2** - Integrazione avanzata con Google Analytics 4
- ✅ **Privacy by Design** - Blocco preventivo degli script fino al consenso

### 🎨 **Interfaccia Moderna**
- 🎯 **Design minimalista** - Pulsante discreto e personalizzabile
- 📱 **Responsive design** - Ottimizzato per tutti i dispositivi
- 🌈 **Colori personalizzabili** - Sfondo, testo e bordo configurabili
- ✨ **Animazioni fluide** - Micro-interazioni eleganti

### 🌍 **Multilingua**
- 🇮🇹 **Italiano** (predefinito)
- 🇬🇧 **Inglese**
- 🇪🇸 **Spagnolo**
- 🇫🇷 **Francese**
- 🇩🇪 **Tedesco**
- 🔗 **Privacy policy dinamiche** - Link specifici per ogni lingua

### 📊 **Analytics Avanzati**
- 📈 **Google Analytics 4** - Integrazione nativa
- 🎯 **Conversion tracking** - Codice personalizzabile per eventi
- 🛒 **WooCommerce** - Tracciamento acquisti automatico
- 📱 **Eventi predefiniti** - Newsletter, WhatsApp, email, telefono

---

## ⚙️ Requisiti di Sistema

| Componente | Versione Minima | Consigliata |
|------------|----------------|-------------|
| **WordPress** | 5.0 | 6.0+ |
| **PHP** | 7.4 | 8.1+ |
| **MySQL** | 5.6 | 8.0+ |
| **Memoria PHP** | 64MB | 128MB+ |

### Dipendenze Opzionali
- **WooCommerce** 3.0+ (per e-commerce tracking)
- **Elementor** (compatibilità testata)
- **jQuery** (incluso in WordPress)

---

## 🚀 Installazione

### Metodo 1: Upload Manuale
1. Scarica il file ZIP del plugin
2. Vai su **WordPress Admin → Plugin → Aggiungi nuovo**
3. Clicca **"Carica plugin"**
4. Seleziona il file ZIP e clicca **"Installa ora"**
5. Attiva il plugin

### Metodo 2: FTP
1. Estrai il file ZIP
2. Carica la cartella `cookie_v4` in `/wp-content/plugins/`
3. Attiva il plugin dal pannello WordPress

### Verifica Installazione
- Menu **"Impostazioni Cookie"** disponibile nel backend
- Pulsante cookie visibile nel frontend (lato sinistro)

---

## 🔧 Configurazione

### Accesso alle Impostazioni
**WordPress Admin → Impostazioni Cookie**

### 1. Configurazione Base

#### **ID Tracciamento GA4**
```
G-XXXXXXXXXX
```
- Inserisci il tuo Google Analytics 4 ID
- Formato: `G-` seguito da 10 caratteri alfanumerici
- **Obbligatorio** per il tracking

#### **Nome Dominio**
```
tuodominio.com
```
- Dominio principale del sito
- Senza `http://` o `https://`
- Utilizzato per la configurazione cookie

### 2. Codice Tracciamento Conversioni

Esempio di configurazione base:
```javascript
window.onload = () => {
    const gtag_track = (eventname) => {
        if (typeof gtag === 'function') {
            gtag('event', eventname, {
                'event_category': eventname
            });
        } else {
            console.log('Google analytics non presente');
        }
    };

    // Newsletter tracking
    const formNewsletter = document.getElementById('formNewsletter');
    if (formNewsletter) {
        formNewsletter.addEventListener('submit', () => {
            gtag_track('iscrizioneNewsletter');
        });
    }

    // WhatsApp tracking
    var whatsapps = document.querySelectorAll('a[href^="https://wa.me"]');
    whatsapps.forEach(whatsapp => whatsapp.addEventListener('click', () => {
        gtag_track('whatsapp');
    }));
};
```

### 3. Configurazione Lingue

#### Selezione Lingue Attive
- Spunta le lingue utilizzate sul tuo sito
- I campi privacy policy appaiono dinamicamente

#### Privacy Policy Links
- **🇮🇹 Italiano**: `https://tuosito.it/privacy-policy`
- **🇬🇧 Inglese**: `https://tuosito.it/en/privacy-policy`
- **🇪🇸 Spagnolo**: `https://tuosito.it/es/privacy-policy`

---

## 🎨 Personalizzazione

### Impostazioni Stile

#### **Colore Sfondo Pulsante**
- Colore di base del pulsante cookie
- Default: `#f0f0f0` (grigio chiaro)
- Supporta codici HEX

#### **Colore Testo Pulsante**
- Colore del testo "Cookie Policy"
- Default: `#ffffff` (bianco)
- Contrasto automatico calcolato

#### **Colore Bordo Pulsante**
- Colore del bordo laterale
- Default: `#bbbbbb` (grigio medio)
- Definisce il contorno

### CSS Personalizzato

Per personalizzazioni avanzate, aggiungi CSS nel tema:

```css
/* Personalizza posizione */
.fixed-left {
    top: 30% !important; /* Sposta più in alto */
}

/* Personalizza hover */
.fixed-left:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.2) !important;
}
```

---

## 🛒 Integrazione E-commerce

### WooCommerce
Il plugin si integra automaticamente con WooCommerce per tracciare gli acquisti:

```php
// Dati tracciati automaticamente
- ID Transazione
- Valore totale ordine
- Valuta (EUR)
- Dettagli prodotti:
  - ID prodotto
  - Nome prodotto  
  - Prezzo
  - Quantità
```

### Personalizzazione Tracking E-commerce
Modifica la funzione `my_custom_tracking()` in `cookieconsent.php`:

```php
function my_custom_tracking( $order_id ) {
    $order = wc_get_order( $order_id );
    $total = $order->get_total();
    
    // Il tuo codice personalizzato qui
}
```

---

## 🌍 Supporto Multilingua

### Lingue Supportate
| Codice | Lingua | Bandiera |
|--------|--------|----------|
| `it` | Italiano | 🇮🇹 |
| `en` | Inglese | 🇬🇧 |
| `es` | Spagnolo | 🇪🇸 |
| `fr` | Francese | 🇫🇷 |
| `de` | Tedesco | 🇩🇪 |

### Aggiungere Nuove Lingue

1. **Modifica il file `cookieconsent.php`**:
```php
$languages = array(
    'en' => '🇬🇧 Inglese',
    'it' => '🇮🇹 Italiano', 
    'pt' => '🇵🇹 Portoghese', // Nuova lingua
    // ... altre lingue
);
```

2. **Aggiorna la sanitizzazione**:
```php
$allowed_languages = array('en', 'it', 'es', 'fr', 'de', 'pt');
```

### WPML/Polylang
Il plugin è compatibile con:
- ✅ **WPML** - WordPress Multilingual Plugin
- ✅ **Polylang** - WordPress Polyglot
- ✅ **qTranslate-X** - Multilingual plugin

---

## 👨‍💻 Sviluppatori

### Hooks Disponibili

#### Actions
```php
// Prima del caricamento CSS
do_action('cookie_consent_before_css');

// Prima del caricamento JS
do_action('cookie_consent_before_js');

// Dopo il salvataggio impostazioni
do_action('cookie_consent_settings_saved', $settings);
```

#### Filters
```php
// Modifica impostazioni cookie
$settings = apply_filters('cookie_consent_settings', $settings);

// Personalizza colori pulsante
$colors = apply_filters('cookie_consent_button_colors', $colors);

// Modifica lingue disponibili
$languages = apply_filters('cookie_consent_languages', $languages);
```

### Esempi di Utilizzo

#### Personalizzazione Impostazioni
```php
function custom_cookie_settings($settings) {
    $settings['custom_param'] = 'valore';
    return $settings;
}
add_filter('cookie_consent_settings', 'custom_cookie_settings');
```

#### Aggiungere CSS Personalizzato
```php
function custom_cookie_css() {
    echo '<style>.fixed-left { /* CSS custom */ }</style>';
}
add_action('cookie_consent_before_css', 'custom_cookie_css');
```

### Struttura File

```
cookie_v4/
├── cookieconsent.php          # File principale
├── cookieconsent-init.js      # JavaScript cookie consent
├── cookieconsent.css          # Stili cookie consent
├── cookieconsent-min.css      # Stili minificati
└── README.md                  # Documentazione
```

---

## ❓ FAQ

### **Il pulsante cookie non appare**
- Verifica che il plugin sia attivato
- Controlla che non sei sulla pagina Privacy Policy
- Verifica la presenza di JavaScript

### **Google Analytics non traccia**
- Controlla l'ID GA4 nelle impostazioni
- Verifica il consenso cookie
- Controlla la console browser per errori

### **Il pulsante è troppo grande/piccolo**
- Usa le impostazioni colore per modificare l'aspetto
- Su mobile il pulsante si riduce automaticamente
- Per personalizzazioni avanzate usa CSS custom

### **Le lingue non cambiano**
- Verifica le lingue abilitate nelle impostazioni
- Controlla i link privacy policy per ogni lingua
- Assicurati che il sito supporti le lingue selezionate

### **WooCommerce non traccia gli acquisti**
- Verifica che WooCommerce sia attivo
- Controlla l'ID GA4 configurato
- Verifica il consenso cookie nella pagina checkout

---

## 🆘 Supporto

### Supporto Tecnico
- **Email**: [supporto@inyourlife.info](mailto:supporto@inyourlife.info)
- **Sito Web**: [https://www.inyourlife.info](https://www.inyourlife.info)
- **Orari**: Lun-Ven 9:00-18:00 (CET)

### Documentazione
- **Guide**: Disponibili sul sito ufficiale
- **Video Tutorial**: Canale YouTube In Your Life
- **Community**: Forum WordPress ufficiale

### Segnalazione Bug
Per segnalare bug, fornisci:
1. Versione WordPress
2. Versione PHP
3. Plugin attivi
4. Descrizione del problema
5. Log degli errori

---

## 📝 Changelog

### v4.0 (Corrente)
- 🎨 **Design completamente rinnovato** - Interfaccia moderna e minimalista
- 🇮🇹 **Traduzione italiana completa** - Tutto il plugin in italiano
- 🎌 **Bandiere per le lingue** - Identificazione visiva migliorata
- 🔧 **Pannello admin ridisegnato** - UX/UI completamente ripensata
- 📱 **Mobile optimization** - Pulsante compatto su dispositivi mobili
- 🎯 **Colori personalizzabili** - Controllo completo dell'aspetto
- ⚡ **Performance migliorata** - CSS e JS ottimizzati
- 🔒 **Sicurezza potenziata** - Validazione input migliorata

### v3.x
- Supporto multilingua base
- Integrazione Google Analytics
- WooCommerce tracking

### v2.x
- Prima versione pubblica
- Funzionalità cookie consent base

---

## 📄 Licenza

Questo plugin è rilasciato sotto licenza **GPL v2** o successive.

```
Cookie Consent IYL - WordPress Plugin
Copyright (C) 2024 In Your Life Srl

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
```

---

## 🏢 In Your Life Srl

**Sviluppo WordPress e Soluzioni Digitali**

- 🌐 **Sito Web**: [www.inyourlife.info](https://www.inyourlife.info)
- 📧 **Email**: info@inyourlife.info
- 📱 **Servizi**: WordPress, E-commerce, Marketing Digitale
- 🎯 **Specializzazione**: GDPR Compliance, Performance Optimization

---

*Realizzato con ❤️ da **In Your Life Srl** - La tua agenzia digitale di fiducia* 