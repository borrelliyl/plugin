import 'https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.umd.js';

// Get settings from PHP
const settings = window.cookieConsentSettings || {
    domain: '',
    ga4_id: '',
    privacy_links: {},
    enabled_languages: ['it']
};

// Validate settings
function validateSettings() {
    const errors = [];
    
    if (!settings.domain) {
        console.warn('Domain name is not set');
        return false;
    }
    
    if (!settings.ga4_id) {
        console.warn('GA4 Tracking ID is not set');
        return false;
    }
    
    if (!settings.privacy_links || Object.keys(settings.privacy_links).length === 0) {
        console.warn('No privacy policy links are set');
        return false;
    }
    
    if (!settings.enabled_languages || settings.enabled_languages.length === 0) {
        console.warn('No languages are enabled');
        return false;
    }
    
    return true;
}

// Helper function to get privacy policy link for current language
function getPrivacyPolicyLink(lang) {
    const link = settings.privacy_links[lang];
    if (!link) {
        console.warn(`No privacy policy link found for language: ${lang}`);
        return '/privacy-policy';
    }
    return link;
}

// Helper function to get GA4 cookie name
function getGACookieName() {
    if (!settings.ga4_id) {
        console.warn('GA4 Tracking ID is not set');
        return '_ga_G-code';
    }
    return `_ga_${settings.ga4_id.replace('G-', '')}`;
}

// Validate settings before initializing
if (!validateSettings()) {
    console.error('Cookie Consent initialization failed due to invalid settings');
} else {
    CookieConsent.run({
        disablePageInteraction: true,
        guiOptions: {
            consentModal: {
                layout: "cloud",
                position: "middle center",
                equalWeightButtons: true,
                flipButtons: true
            },
            preferencesModal: {
                layout: "box",
                position: "left",
                equalWeightButtons: false,
                flipButtons: false
            }
        },
        
        onConsent: () => {
            updateGtagConsent();
        },

        onChange: ({ changedCategories }) => {
            updateGtagConsent();
        },
        categories: {
            necessary: {
                readOnly: true
            },
            analytics: {
                autoClear: {
                    cookies: [
                        {
                            name: /^(_ga|_gid)/
                        }
                    ]
                }
            },
            functional: {
                autoClear: {
                    cookies: [
                        {
                            name: /^(_ga|_gid)/
                        }
                    ]
                }
            },
            advertisement: {
                autoClear: {
                    cookies: [
                        {
                            name: /^(_ga|_gid)/
                        }
                    ]
                }
            }
        },
        language: {
            default: "it",
            autoDetect: "document",
            translations: {
                it: {
                    consentModal: {
                        title: "Consenso Cookies",
                        description: `Questo sito utilizza cookies per migliorare l'esperienza di navigazione (vedi <b><a href="${getPrivacyPolicyLink('it')}" target="_blank" rel="noopener">Cookie Policy</a></b>).`,
                        acceptAllBtn: "Accetta tutto",
                        acceptNecessaryBtn: "Rifiuta tutto",
                        showPreferencesBtn: "Gestisci preferenze"
                    },
                    preferencesModal: {
                        title: "Preferenze Cookies",
                        acceptAllBtn: "Accetta tutto",
                        acceptNecessaryBtn: "Rifiuta tutto",
                        savePreferencesBtn: "Salva le preferenze",
                        closeIconLabel: "Chiudi la finestra",
                        serviceCounterLabel: "Servizi",
                        sections: [
                            {
                                title: "Uso dei Cookie",
                                description: `Utilizziamo i cookie per migliorare l'esperienza di navigazione dell'utente. Puoi scegliere quali cookie di profilazione abilitare o disabilitare. Per maggiori dettagli, consulta la nostra <a href="${getPrivacyPolicyLink('it')}" target="_blank" rel="noopener">Cookie Policy</a>.`
                            },
                            {
                                title: "Cookie Strettamente Necessari <span class=\"pm__badge\">Sempre Attivi</span>",
                                linkedCategory: "necessary",
                                cookieTable: {
                                    caption: 'Elenco dei cookie',
                                    headers: {
                                        name: 'Nome',
                                        domain: 'Dominio',
                                        description: 'Descrizione',
                                        duration: 'Durata'
                                    },
                                    body: [
                                        {
                                            name: 'cc_cookie',
                                            domain: settings.domain,
                                            description: 'Consenso dei cookie',
                                            duration: '6 mesi'
                                        },
                                        {
                                            name: 'PHPSESSID',
                                            domain: settings.domain,
                                            description: 'Cookie di sessione',
                                            duration: 'sessione'
                                        },
                                        {
                                            name: '^__Secure-',
                                            domain: 'google.it',
                                            description: 'Cookie di Google',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: 'SAPISID',
                                            domain: 'google.it',
                                            description: 'Cookie di Google',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: 'APISID',
                                            domain: 'google.it',
                                            description: 'Cookie di Google',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: 'HSID',
                                            domain: 'google.it',
                                            description: 'Cookie di Google',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: 'SID',
                                            domain: 'google.it',
                                            description: 'Cookie di Google',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: 'SSID',
                                            domain: 'google.it',
                                            description: 'Cookie di Google',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: 'NID',
                                            domain: 'google.com',
                                            description: 'Cookie di Google',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: 'AEC',
                                            domain: 'google.com',
                                            description: 'Cookie di Google',
                                            duration: '6 mesi'
                                        },
                                        {
                                            name: 'SOCS',
                                            domain: 'google.com',
                                            description: 'Cookie di Google',
                                            duration: '6 mesi'
                                        },
                                        {
                                            name: '__Secure-BUCKET',
                                            domain: 'google.com',
                                            description: 'Cookie di Google',
                                            duration: '6 mesi'
                                        }
                                    ]
                                }
                            },
                            {
                                title: "Cookie Misurazione",
                                description: "Questi strumenti di tracciamento ci permettono di migliorare la qualità della tua esperienza utente e consentono le interazioni con piattaforme, reti e contenuti esterni.",
                                linkedCategory: "analytics",
                                cookieTable: {
                                    caption: 'Elenco dei cookie',
                                    headers: {
                                        name: 'Nome',
                                        domain: 'Dominio',
                                        description: 'Descrizione',
                                        duration: 'Durata'
                                    },
                                    body: [
                                        {
                                            name: '_ga',
                                            domain: settings.domain,
                                            description: 'Analisi del traffico',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: getGACookieName(),
                                            domain: settings.domain,
                                            description: 'Analisi del traffico',
                                            duration: '1 anno'
                                        },
                                        {
                                            name: '_gcl_au',
                                            domain: settings.domain,
                                            description: 'Analisi del traffico',
                                            duration: '3 mesi'
                                        }
                                    ]
                                }
                            },
                            {
                                title: "Cookie Funzionalità",
                                description: "Questi strumenti di tracciamento ci permettono di migliorare la qualità della tua esperienza utente e consentono le interazioni con piattaforme, reti e contenuti esterni.",
                                linkedCategory: "functional",
                            },
                            {
                                title: "Cookie Marketing",
                                description: "Questi strumenti di tracciamento ci permettono di migliorare la qualità della tua esperienza utente e consentono le interazioni con piattaforme, reti e contenuti esterni.",
                                linkedCategory: "advertisement",
                            }
                        ]
                    }
                },
                en: {
                    consentModal: {
                        title: "Cookie Consent",
                        description: `This site uses cookies to improve your browsing experience (see <b><a href="${getPrivacyPolicyLink('en')}" target="_blank" rel="noopener">Cookie Policy</a></b>).`,
                        acceptAllBtn: "Accept all",
                        acceptNecessaryBtn: "Reject all",
                        showPreferencesBtn: "Manage preferences"
                    },
                    preferencesModal: {
                        title: "Cookie Preferences",
                        acceptAllBtn: "Accept all",
                        acceptNecessaryBtn: "Reject all",
                        savePreferencesBtn: "Save preferences",
                        closeIconLabel: "Close window",
                        serviceCounterLabel: "Services",
                        sections: [
                            {
                                title: "Use of Cookies",
                                description: `We use cookies to enhance your browsing experience. You can choose which profiling cookies to enable or disable. For more details, see our <a href="${getPrivacyPolicyLink('en')}" target="_blank" rel="noopener">Cookie Policy</a>.`
                            },
                            {
                                title: "Strictly Necessary Cookies <span class=\"pm__badge\">Always Active</span>",
                                linkedCategory: "necessary",
                                cookieTable: {
                                    caption: 'List of cookies',
                                    headers: {
                                        name: 'Name',
                                        domain: 'Domain',
                                        description: 'Description',
                                        duration: 'Duration'
                                    },
                                    body: [
                                        {
                                            name: 'cc_cookie',
                                            domain: settings.domain,
                                            description: 'Cookie consent',
                                            duration: '6 months'
                                        },
                                        {
                                            name: 'PHPSESSID',
                                            domain: settings.domain,
                                            description: 'Session cookie',
                                            duration: 'session'
                                        },
                                        {
                                            name: '^__Secure-',
                                            domain: 'google.it',
                                            description: 'Google cookie',
                                            duration: '1 year'
                                        },
                                        {
                                            name: 'SAPISID',
                                            domain: 'google.it',
                                            description: 'Google cookie',
                                            duration: '1 year'
                                        },
                                        {
                                            name: 'APISID',
                                            domain: 'google.it',
                                            description: 'Google cookie',
                                            duration: '1 year'
                                        },
                                        {
                                            name: 'HSID',
                                            domain: 'google.it',
                                            description: 'Google cookie',
                                            duration: '1 year'
                                        },
                                        {
                                            name: 'SID',
                                            domain: 'google.it',
                                            description: 'Google cookie',
                                            duration: '1 year'
                                        },
                                        {
                                            name: 'SSID',
                                            domain: 'google.it',
                                            description: 'Google cookie',
                                            duration: '1 year'
                                        },
                                        {
                                            name: 'NID',
                                            domain: 'google.com',
                                            description: 'Google cookie',
                                            duration: '1 year'
                                        },
                                        {
                                            name: 'AEC',
                                            domain: 'google.com',
                                            description: 'Google cookie',
                                            duration: '6 months'
                                        },
                                        {
                                            name: 'SOCS',
                                            domain: 'google.com',
                                            description: 'Google cookie',
                                            duration: '6 months'
                                        },
                                        {
                                            name: '__Secure-BUCKET',
                                            domain: 'google.com',
                                            description: 'Google cookie',
                                            duration: '6 months'
                                        }
                                    ]
                                }
                            },
                            {
                                title: "Measurement Cookies",
                                description: "These tracking tools allow us to improve the quality of your user experience and enable interactions with external platforms, networks, and content.",
                                linkedCategory: "analytics",
                                cookieTable: {
                                    caption: 'List of cookies',
                                    headers: {
                                        name: 'Name',
                                        domain: 'Domain',
                                        description: 'Description',
                                        duration: 'Duration'
                                    },
                                    body: [
                                        {
                                            name: '_ga',
                                            domain: settings.domain,
                                            description: 'Traffic analysis',
                                            duration: '1 year'
                                        },
                                        {
                                            name: getGACookieName(),
                                            domain: settings.domain,
                                            description: 'Traffic analysis',
                                            duration: '1 year'
                                        },
                                        {
                                            name: '_gcl_au',
                                            domain: settings.domain,
                                            description: 'Traffic analysis',
                                            duration: '3 months'
                                        }
                                    ]
                                }
                            },
                            {
                                title: "Functionality Cookies",
                                description: "These tracking tools allow us to improve the quality of your user experience and enable interactions with external platforms, networks, and content.",
                                linkedCategory: "functional",
                            },
                            {
                                title: "Marketing Cookies",
                                description: "These tracking tools allow us to improve the quality of your user experience and enable interactions with external platforms, networks, and content.",
                                linkedCategory: "advertisement",
                            }
                        ]
                    }
                },
                de: {
                    consentModal: {
                        title: "Cookie-Einwilligung",
                        description: "Diese Website verwendet Cookies, um Ihre Browser-Erfahrung zu verbessern (siehe <b><a href=\"/privacy-policy\" target=\"_blank\" rel=\"noopener\">Cookie-Richtlinie</a></b>).",
                        acceptAllBtn: "Alle akzeptieren",
                        acceptNecessaryBtn: "Alle ablehnen",
                        showPreferencesBtn: "Einstellungen verwalten"
                    },
                    preferencesModal: {
                        title: "Cookie-Einstellungen",
                        acceptAllBtn: "Alle akzeptieren",
                        acceptNecessaryBtn: "Alle ablehnen",
                        savePreferencesBtn: "Einstellungen speichern",
                        closeIconLabel: "Fenster schließen",
                        serviceCounterLabel: "Dienste",
                        sections: [
                            {
                                title: "Verwendung von Cookies",
                                description: "Wir verwenden Cookies, um Ihre Browser-Erfahrung zu verbessern. Sie können auswählen, welche Profiling-Cookies aktiviert oder deaktiviert werden. Weitere Informationen finden Sie in unserer <a href=\"/privacy-policy\" target=\"_blank\" rel=\"noopener\">Cookie-Richtlinie</a>."
                            },
                            {
                                title: "Unbedingt erforderliche Cookies <span class=\"pm__badge\">Immer aktiv</span>",
                                linkedCategory: "necessary",
                                cookieTable: {
                                    caption: 'Liste der Cookies',
                                    headers: {
                                        name: 'Name',
                                        domain: 'Domain',
                                        description: 'Beschreibung',
                                        duration: 'Dauer'
                                    },
                                    body: [
                                        {
                                            name: 'cc_cookie',
                                            domain: 'dominio.it',
                                            description: 'Cookie-Einwilligung',
                                            duration: '6 Monate'
                                        },
                                        {
                                            name: 'PHPSESSID',
                                            domain: 'dominio.it',
                                            description: 'Sitzungs-Cookie',
                                            duration: 'Sitzung'
                                        },
                                        {
                                            name: '^__Secure-',
                                            domain: 'google.it',
                                            description: 'Google-Cookie',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: 'SAPISID',
                                            domain: 'google.it',
                                            description: 'Google-Cookie',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: 'APISID',
                                            domain: 'google.it',
                                            description: 'Google-Cookie',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: 'HSID',
                                            domain: 'google.it',
                                            description: 'Google-Cookie',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: 'SID',
                                            domain: 'google.it',
                                            description: 'Google-Cookie',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: 'SSID',
                                            domain: 'google.it',
                                            description: 'Google-Cookie',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: 'NID',
                                            domain: 'google.com',
                                            description: 'Google-Cookie',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: 'AEC',
                                            domain: 'google.com',
                                            description: 'Google-Cookie',
                                            duration: '6 Monate'
                                        },
                                        {
                                            name: 'SOCS',
                                            domain: 'google.com',
                                            description: 'Google-Cookie',
                                            duration: '6 Monate'
                                        },
                                        {
                                            name: '__Secure-BUCKET',
                                            domain: 'google.com',
                                            description: 'Google-Cookie',
                                            duration: '6 Monate'
                                        }
                                    ]
                                }
                            },
                            {
                                title: "Mess-Cookies",
                                description: "Diese Tracking-Tools ermöglichen es uns, die Qualität Ihrer Benutzererfahrung zu verbessern und Interaktionen mit externen Plattformen, Netzwerken und Inhalten zu ermöglichen.",
                                linkedCategory: "analytics",
                                cookieTable: {
                                    caption: 'Liste der Cookies',
                                    headers: {
                                        name: 'Name',
                                        domain: 'Domain',
                                        description: 'Beschreibung',
                                        duration: 'Dauer'
                                    },
                                    body: [
                                        {
                                            name: '_ga',
                                            domain: 'dominio.it',
                                            description: 'Verkehrsanalyse',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: '_ga_G-code',
                                            domain: 'dominio.it',
                                            description: 'Verkehrsanalyse',
                                            duration: '1 Jahr'
                                        },
                                        {
                                            name: '_gcl_au',
                                            domain: 'dominio.it',
                                            description: 'Verkehrsanalyse',
                                            duration: '3 Monate'
                                        }
                                    ]
                                }
                            },
                            {
                                title: "Funktionale Cookies",
                                description: "Diese Tracking-Tools ermöglichen es uns, die Qualität Ihrer Benutzererfahrung zu verbessern und Interaktionen mit externen Plattformen, Netzwerken und Inhalten zu ermöglichen.",
                                linkedCategory: "functional",
                            },
                            {
                                title: "Marketing-Cookies",
                                description: "Diese Tracking-Tools ermöglichen es uns, die Qualität Ihrer Benutzererfahrung zu verbessern und Interaktionen mit externen Plattformen, Netzwerken und Inhalten zu ermöglichen.",
                                linkedCategory: "advertisement",
                            }
                        ]
                    }
                },
                fr: {
                    consentModal: {
                        title: "Consentement aux Cookies",
                        description: "Ce site utilise des cookies pour améliorer votre expérience de navigation (voir <b><a href=\"/privacy-policy\" target=\"_blank\" rel=\"noopener\">Politique de Cookies</a></b>).",
                        acceptAllBtn: "Tout accepter",
                        acceptNecessaryBtn: "Tout refuser",
                        showPreferencesBtn: "Gérer les préférences"
                    },
                    preferencesModal: {
                        title: "Préférences des Cookies",
                        acceptAllBtn: "Tout accepter",
                        acceptNecessaryBtn: "Tout refuser",
                        savePreferencesBtn: "Enregistrer les préférences",
                        closeIconLabel: "Fermer la fenêtre",
                        serviceCounterLabel: "Services",
                        sections: [
                            {
                                title: "Utilisation des Cookies",
                                description: "Nous utilisons des cookies pour améliorer votre expérience de navigation. Vous pouvez choisir quels cookies de profilage activer ou désactiver. Pour plus de détails, consultez notre <a href=\"/privacy-policy\" target=\"_blank\" rel=\"noopener\">Politique de Cookies</a>."
                            },
                            {
                                title: "Cookies Strictement Nécessaires <span class=\"pm__badge\">Toujours Actifs</span>",
                                linkedCategory: "necessary",
                                cookieTable: {
                                    caption: 'Liste des cookies',
                                    headers: {
                                        name: 'Nom',
                                        domain: 'Domaine',
                                        description: 'Description',
                                        duration: 'Durée'
                                    },
                                    body: [
                                        {
                                            name: 'cc_cookie',
                                            domain: 'dominio.it',
                                            description: 'Consentement aux cookies',
                                            duration: '6 mois'
                                        },
                                        {
                                            name: 'PHPSESSID',
                                            domain: 'dominio.it',
                                            description: 'Cookie de session',
                                            duration: 'session'
                                        },
                                        {
                                            name: '^__Secure-',
                                            domain: 'google.it',
                                            description: 'Cookie de Google',
                                            duration: '1 an'
                                        },
                                        {
                                            name: 'SAPISID',
                                            domain: 'google.it',
                                            description: 'Cookie de Google',
                                            duration: '1 an'
                                        },
                                        {
                                            name: 'APISID',
                                            domain: 'google.it',
                                            description: 'Cookie de Google',
                                            duration: '1 an'
                                        },
                                        {
                                            name: 'HSID',
                                            domain: 'google.it',
                                            description: 'Cookie de Google',
                                            duration: '1 an'
                                        },
                                        {
                                            name: 'SID',
                                            domain: 'google.it',
                                            description: 'Cookie de Google',
                                            duration: '1 an'
                                        },
                                        {
                                            name: 'SSID',
                                            domain: 'google.it',
                                            description: 'Cookie de Google',
                                            duration: '1 an'
                                        },
                                        {
                                            name: 'NID',
                                            domain: 'google.com',
                                            description: 'Cookie de Google',
                                            duration: '1 an'
                                        },
                                        {
                                            name: 'AEC',
                                            domain: 'google.com',
                                            description: 'Cookie de Google',
                                            duration: '6 mois'
                                        },
                                        {
                                            name: 'SOCS',
                                            domain: 'google.com',
                                            description: 'Cookie de Google',
                                            duration: '6 mois'
                                        },
                                        {
                                            name: '__Secure-BUCKET',
                                            domain: 'google.com',
                                            description: 'Cookie de Google',
                                            duration: '6 mois'
                                        }
                                    ]
                                }
                            },
                            {
                                title: "Cookies de Mesure",
                                description: "Ces outils de suivi nous permettent d'améliorer la qualité de votre expérience utilisateur et d'autoriser les interactions avec des plateformes, des réseaux et des contenus externes.",
                                linkedCategory: "analytics",
                                cookieTable: {
                                    caption: 'Liste des cookies',
                                    headers: {
                                        name: 'Nom',
                                        domain: 'Domaine',
                                        description: 'Description',
                                        duration: 'Durée'
                                    },
                                    body: [
                                        {
                                            name: '_ga',
                                            domain: 'dominio.it',
                                            description: 'Analyse du trafic',
                                            duration: '1 an'
                                        },
                                        {
                                            name: '_ga_G-code',
                                            domain: 'dominio.it',
                                            description: 'Analyse du trafic',
                                            duration: '1 an'
                                        },
                                        {
                                            name: '_gcl_au',
                                            domain: 'dominio.it',
                                            description: 'Analyse du trafic',
                                            duration: '3 mois'
                                        }
                                    ]
                                }
                            },
                            {
                                title: "Cookies Fonctionnels",
                                description: "Ces outils de suivi nous permettent d'améliorer la qualité de votre expérience utilisateur et d'autoriser les interactions avec des plateformes, des réseaux et des contenus externes.",
                                linkedCategory: "functional",
                            },
                            {
                                title: "Cookies Marketing",
                                description: "Ces outils de suivi nous permettent d'améliorer la qualité de votre expérience utilisateur et d'autoriser les interactions avec des plateformes, des réseaux et des contenus externes.",
                                linkedCategory: "advertisement",
                            }
                        ]
                    }
                },            
            }
        }
    });
}

function updateGtagConsent() {
    if (typeof gtag != "undefined") {
        gtag('consent', 'update', {
            'ad_storage': CookieConsent.acceptedCategory('advertisement') ? 'granted' : 'denied',
            'ad_user_data': CookieConsent.acceptedCategory('advertisement') ? 'granted' : 'denied',
            'ad_personalization': CookieConsent.acceptedCategory('advertisement') ? 'granted' : 'denied',
            'analytics_storage': CookieConsent.acceptedCategory('analytics') ? 'granted' : 'denied',
            'functionality_storage': CookieConsent.acceptedCategory('functional') ? 'granted' : 'denied',
            'personalization_storage': CookieConsent.acceptedCategory('functional') ? 'granted' : 'denied',
        });
    }
}
