<?php
/*
Plugin Name:  Cookie Consent IYL
Plugin URI:   https://www.inyourlife.info 
Description:  Plugin moderno per la gestione del consenso cookie conforme al GDPR con interfaccia elegante e multilingua.
Version:      4.0
Author:       In Your Life Srl
Author URI:   https://www.inyourlife.info
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  cookie-consent
Domain Path:  /languages
*/

// Add admin menu
add_action('admin_menu', 'cookie_consent_admin_menu');
function cookie_consent_admin_menu() {
    add_menu_page(
        'Impostazioni Cookie Consent',
        'Impostazioni Cookie',
        'manage_options',
        'cookie-consent-settings',
        'cookie_consent_settings_page',
        'dashicons-shield',
        30
    );
}

// Register settings
add_action('admin_init', 'cookie_consent_register_settings');
function cookie_consent_register_settings() {
    register_setting('cookie_consent_settings', 'cookie_consent_ga4_id');
    register_setting('cookie_consent_settings', 'cookie_consent_domain');
    register_setting('cookie_consent_settings', 'cookie_consent_conversion_tracking');
    register_setting('cookie_consent_settings', 'cookie_consent_enabled_languages', 'cookie_consent_sanitize_enabled_languages');
    register_setting('cookie_consent_settings', 'cookie_consent_privacy_links');
    register_setting('cookie_consent_settings', 'cookie_consent_button_bg_color');
    register_setting('cookie_consent_settings', 'cookie_consent_button_text_color');
    register_setting('cookie_consent_settings', 'cookie_consent_button_border_color');
    register_setting('cookie_consent_settings', 'cookie_consent_button_bg_color_hover');
    register_setting('cookie_consent_settings', 'cookie_consent_button_text_color_hover');
    register_setting('cookie_consent_settings', 'cookie_consent_use_gradient');
    register_setting('cookie_consent_settings', 'cookie_consent_gradient_start');
    register_setting('cookie_consent_settings', 'cookie_consent_gradient_end');
    register_setting('cookie_consent_settings', 'cookie_consent_gradient_direction');
    register_setting('cookie_consent_settings', 'cookie_consent_use_gradient_hover');
    register_setting('cookie_consent_settings', 'cookie_consent_gradient_start_hover');
    register_setting('cookie_consent_settings', 'cookie_consent_gradient_end_hover');
    register_setting('cookie_consent_settings', 'cookie_consent_position_horizontal');
    register_setting('cookie_consent_settings', 'cookie_consent_position_vertical');
    register_setting('cookie_consent_settings', 'cookie_consent_position_offset');

    // Add settings updated message
    if (isset($_GET['settings-updated'])) {
        add_settings_error(
            'cookie_consent_messages',
            'cookie_consent_message',
            __('Impostazioni salvate con successo!', 'cookie-consent'),
            'updated'
        );
    }
}

// Sanitization function for enabled languages
function cookie_consent_sanitize_enabled_languages($input) {
    if (!is_array($input)) {
        return array('it'); // Default to Italian if not array
    }
    
    $allowed_languages = array('en', 'it', 'es', 'fr', 'de');
    $sanitized = array();
    
    foreach ($input as $language) {
        if (in_array($language, $allowed_languages)) {
            $sanitized[] = sanitize_text_field($language);
        }
    }
    
    // Ensure at least one language is selected
    if (empty($sanitized)) {
        $sanitized = array('it');
    }
    
    return $sanitized;
}

// Settings page content
function cookie_consent_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Show settings errors/messages
    settings_errors('cookie_consent_messages');
    ?>
    <div class="wrap cookie-consent-admin">
        <style>
        .cookie-consent-admin {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;
        }
        
        .cookie-consent-admin h1 {
            color: #1e293b;
            font-size: 2.2em;
            font-weight: 600;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .cookie-consent-admin h1::before {
            content: "🍪";
            font-size: 0.8em;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            padding: 8px;
            filter: grayscale(100%);
        }
        
        .cookie-consent-admin h2 {
            color: #374151;
            font-size: 1.4em;
            font-weight: 600;
            margin: 30px 0 20px 0;
            padding: 15px 0;
            border-bottom: 2px solid #e5e7eb;
            position: relative;
        }
        
        .cookie-consent-admin h2::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 60px;
            height: 2px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .cookie-consent-admin .form-table {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            margin-bottom: 24px;
            overflow: hidden;
        }
        
        .cookie-consent-admin .form-table th,
        .cookie-consent-admin .form-table td {
            padding: 20px 24px;
            border-bottom: 1px solid #f3f4f6;
        }
        
        .cookie-consent-admin .form-table tr:last-child th,
        .cookie-consent-admin .form-table tr:last-child td {
            border-bottom: none;
        }
        
        .cookie-consent-admin .form-table th {
            background: #f8fafc;
            font-weight: 600;
            color: #374151;
            width: 200px;
            vertical-align: top;
            padding-top: 24px;
        }
        
        .cookie-consent-admin .form-table td {
            background: #ffffff;
        }
        
        .cookie-consent-admin input[type="text"],
        .cookie-consent-admin input[type="color"],
        .cookie-consent-admin textarea {
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 12px 16px;
            font-size: 14px;
            transition: all 0.2s ease;
            background: #ffffff;
        }
        
        .cookie-consent-admin input[type="text"]:focus,
        .cookie-consent-admin textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .cookie-consent-admin input[type="color"] {
            width: 60px;
            height: 40px;
            padding: 4px;
            cursor: pointer;
            border-radius: 8px;
        }
        
        .cookie-consent-admin input[type="color"]:hover {
            transform: scale(1.05);
        }
        
        .cookie-consent-admin textarea {
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
            font-size: 13px;
            line-height: 1.5;
            background: #1f2937;
            color: #e5e7eb;
            border-color: #374151;
        }
        
        .cookie-consent-admin textarea:focus {
            border-color: #667eea;
            background: #111827;
        }
        
        .cookie-consent-admin .description {
            color: #6b7280;
            font-size: 13px;
            line-height: 1.4;
            margin-top: 8px;
            font-style: italic;
        }
        
        .cookie-consent-admin label {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            margin: 4px 8px 4px 0;
            background: #f3f4f6;
            border-radius: 20px;
            border: 2px solid transparent;
            transition: all 0.2s ease;
            cursor: pointer;
            font-weight: 500;
        }
        
        .cookie-consent-admin label:hover {
            background: #e5e7eb;
            transform: translateY(-1px);
        }
        
        .cookie-consent-admin input[type="checkbox"] {
            margin-right: 8px;
            transform: scale(1.2);
            accent-color: #667eea;
        }
        
        .cookie-consent-admin input[type="checkbox"]:checked + span {
            color: #667eea;
            font-weight: 600;
        }
        
        .cookie-consent-admin .submit {
            text-align: center;
            margin-top: 32px;
        }
        
        .cookie-consent-admin .button-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 12px 32px;
            font-size: 16px;
            font-weight: 600;
            text-shadow: none;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            transition: all 0.3s ease;
        }
        
        .cookie-consent-admin .button-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }
        
        .cookie-consent-admin .button-primary:active {
            transform: translateY(0);
        }
        
        .privacy-link-container {
            background: #f8fafc;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 12px;
            border-left: 4px solid #667eea;
            transition: all 0.2s ease;
        }
        
        .privacy-link-container:hover {
            background: #f1f5f9;
            transform: translateX(4px);
        }
        
        .privacy-link-container label {
            background: transparent;
            padding: 0;
            margin: 0 0 8px 0;
            border-radius: 0;
            font-weight: 600;
            color: #374151;
        }
        
        .language-toggle {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 8px;
        }
        
        .notice.notice-success {
            border-left-color: #10b981;
            background: #ecfdf5;
            border-radius: 8px;
            margin: 16px 0;
        }
        
        @media (max-width: 768px) {
            .cookie-consent-admin .form-table th,
            .cookie-consent-admin .form-table td {
                display: block;
                width: 100%;
                padding: 16px;
            }
            
            .cookie-consent-admin .form-table th {
                background: transparent;
                font-size: 16px;
                padding-bottom: 8px;
            }
        }
        
        /* Enhanced styles for new sections */
        .cookie-consent-admin h2 {
            cursor: pointer;
            user-select: none;
            transition: all 0.3s ease;
            position: relative;
            padding-left: 35px;
        }
        
        .cookie-consent-admin h2:hover {
            color: #667eea;
        }
        
        .cookie-consent-admin h2::before {
            content: "▼";
            position: absolute;
            left: 0;
            transition: transform 0.3s ease;
            color: #667eea;
            font-size: 0.8em;
        }
        
        .cookie-consent-admin h2.collapsed::before {
            transform: rotate(-90deg);
        }
        
        .cookie-consent-admin .section-content {
            transition: all 0.3s ease;
            overflow: hidden;
        }
        
        .cookie-consent-admin .section-content.collapsed {
            max-height: 0;
            opacity: 0;
            margin: 0;
        }
        
        .cookie-consent-admin select {
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 12px 16px;
            font-size: 14px;
            transition: all 0.2s ease;
            background: #ffffff;
            min-width: 200px;
        }
        
        .cookie-consent-admin select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .cookie-consent-admin .form-table tr[data-disabled="true"] {
            opacity: 0.5;
            pointer-events: none;
        }
        
        .cookie-consent-admin .gradient-preview {
            width: 100%;
            height: 40px;
            border-radius: 8px;
            border: 2px solid #e5e7eb;
            margin-top: 10px;
            transition: all 0.3s ease;
        }
        
        .cookie-consent-admin .position-preview {
            width: 120px;
            height: 80px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            position: relative;
            margin-top: 10px;
            background: #f8f9fa;
        }
        
        .cookie-consent-admin .position-preview::after {
            content: "🍪";
            position: absolute;
            width: 20px;
            height: 30px;
            background: #667eea;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            color: white;
            transition: all 0.3s ease;
        }
        
        /* Stili per le intestazioni delle sezioni */
        .cookie-consent-admin .form-table th[colspan="2"] {
            padding: 16px 24px !important;
            border-radius: 8px;
            font-size: 16px;
            text-shadow: 0 1px 2px rgba(0,0,0,0.1);
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border: none !important;
        }
        
        .cookie-consent-admin .form-table tr:has(th[colspan="2"]) {
            border-top: 2px solid #e5e7eb;
            margin-top: 20px;
        }
        
        .cookie-consent-admin .form-table tr:has(th[colspan="2"]):first-child {
            border-top: none;
            margin-top: 0;
        }
        
        .cookie-consent-admin .form-table tr:has(th[colspan="2"]) + tr th,
        .cookie-consent-admin .form-table tr:has(th[colspan="2"]) + tr td {
            border-top: none;
            padding-top: 24px;
        }
        </style>
        
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <p style="color: #6b7280; font-size: 16px; margin-bottom: 32px;">Configura le impostazioni del consenso cookie con una soluzione moderna e conforme al GDPR.</p>
        
        <form action="options.php" method="post">
            <?php
            settings_fields('cookie_consent_settings');
            do_settings_sections('cookie_consent_settings');
            ?>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="cookie_consent_ga4_id">ID Tracciamento GA4</label>
                    </th>
                    <td>
                        <input type="text" id="cookie_consent_ga4_id" name="cookie_consent_ga4_id" 
                               value="<?php echo esc_attr(get_option('cookie_consent_ga4_id')); ?>" 
                               class="regular-text" placeholder="G-XXXXXXXXXX">
                        <p class="description">Inserisci il tuo ID di tracciamento Google Analytics 4 (es. G-XXXXXXXXXX)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cookie_consent_domain">Nome Dominio</label>
                    </th>
                    <td>
                        <input type="text" id="cookie_consent_domain" name="cookie_consent_domain" 
                               value="<?php echo esc_attr(get_option('cookie_consent_domain')); ?>" 
                               class="regular-text">
                        <p class="description">Inserisci il nome del dominio del tuo sito web</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cookie_consent_conversion_tracking">Codice Tracciamento Conversioni</label>
                    </th>
                    <td>
                        <textarea id="cookie_consent_conversion_tracking" name="cookie_consent_conversion_tracking" 
                                  rows="10" cols="50" class="large-text code" placeholder="// Aggiungi qui il tuo codice JavaScript personalizzato
// Esempio: gtag('event', 'iscrizione_newsletter');
window.onload = () => {
    // Il tuo codice di tracciamento va qui
};"><?php 
                            echo esc_textarea(get_option('cookie_consent_conversion_tracking', 'window.onload = () => {
    const gtag_track = (eventname) => {
        if (typeof gtag === \'function\') {
            gtag(\'event\', eventname, {
                \'event_category\': eventname
            });
        } else {
            console.log(\'Google analytics non presente\');
        }
    };

    const formNewsletter = document.getElementById(\'formNewsletter\');
    if (formNewsletter) {
        formNewsletter.addEventListener(\'submit\', () => {
            gtag_track(\'iscrizioneNewsletter\');
        });
    }

    var whatsapps = document.querySelectorAll(\'a[href^="https://wa.me"]\');
    whatsapps.forEach(whatsapp => whatsapp.addEventListener(\'click\', () => {
        gtag_track(\'whatsapp\');
    }));

    var emails = document.querySelectorAll(\'a[href^="mailto:"]\');
    emails.forEach(email => email.addEventListener(\'click\', () => {
        gtag_track(\'email\');
    }));

    var phones = document.querySelectorAll(\'a[href^="tel:"]\');
    phones.forEach(phone => phone.addEventListener(\'click\', () => {
        gtag_track(\'telefono\');
    }));

    jQuery(document).ready(function($) {
        jQuery(document).on(\'submit_success\', function(evt) {
            gtag_track(\'formcontatti\');
        });
    });
};')); ?></textarea>
                        <p class="description">📊 Inserisci qui il tuo codice JavaScript personalizzato per il tracciamento delle conversioni. Questo codice verrà eseguito al caricamento della pagina per tracciare le interazioni dell'utente come invii di moduli, clic, ecc.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Lingue Abilitate</th>
                    <td>
                        <div class="language-toggle">
                        <?php
                        $enabled_languages = get_option('cookie_consent_enabled_languages', array('it'));
                        // Ensure it's always an array
                        if (!is_array($enabled_languages)) {
                            $enabled_languages = array('it'); // Default to Italian if not array
                        }
                        $languages = array(
                            'en' => '🇬🇧 Inglese', 
                            'it' => '🇮🇹 Italiano', 
                            'es' => '🇪🇸 Spagnolo', 
                            'fr' => '🇫🇷 Francese', 
                            'de' => '🇩🇪 Tedesco'
                        );
                        foreach ($languages as $code => $name) {
                            ?>
                            <label style="margin-right: 15px;">
                                <input type="checkbox" name="cookie_consent_enabled_languages[]" 
                                       value="<?php echo $code; ?>" 
                                       <?php checked(in_array($code, $enabled_languages)); ?> 
                                       onchange="togglePrivacyLinks()">
                                <span><?php echo $name; ?></span>
                            </label>
                            <?php
                        }
                        ?>
                        </div>
                        <p class="description">Seleziona quali lingue sono attive sul tuo sito web</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Link Privacy Policy</th>
                    <td>
                        <?php
                        $privacy_links = get_option('cookie_consent_privacy_links', array());
                        
                        foreach ($languages as $code => $name) {
                            $is_enabled = in_array($code, $enabled_languages);
                            ?>
                            <div class="privacy-link-container" id="privacy_link_row_<?php echo $code; ?>" <?php echo $is_enabled ? '' : 'style="display:none;"'; ?>>
                                <label for="privacy_link_<?php echo $code; ?>"><?php echo $name; ?>:</label>
                                <input type="text" id="privacy_link_<?php echo $code; ?>" 
                                       name="cookie_consent_privacy_links[<?php echo $code; ?>]" 
                                       value="<?php echo esc_attr($privacy_links[$code] ?? ''); ?>" 
                                       class="regular-text" style="width: 100%; margin-top: 8px;">
                            </div>
                            <?php
                        }
                        ?>
                        <p class="description">Inserisci gli URL della privacy policy per ogni lingua abilitata</p>
                    </td>
                </tr>
            </table>

            <h2 onclick="toggleSection(this, 'advanced-settings')" data-section="advanced-settings">Impostazioni Stile e Posizione</h2>
            <div id="advanced-settings" class="section-content">
                <table class="form-table">
                    <tr>
                        <th scope="row" colspan="2" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-align: center; font-weight: bold;">
                            🎨 Colori di Sfondo del Pulsante
                        </th>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_button_bg_color">Colore Sfondo (Normale)</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_button_bg_color" name="cookie_consent_button_bg_color" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_button_bg_color', '#f0f0f0')); ?>">
                            <p class="description">Colore di sfondo del pulsante cookie nello stato normale</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_button_bg_color_hover">Colore Sfondo (Hover)</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_button_bg_color_hover" name="cookie_consent_button_bg_color_hover" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_button_bg_color_hover', '#e0e0e0')); ?>">
                            <p class="description">Colore di sfondo del pulsante cookie quando ci si passa sopra</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" colspan="2" style="background: linear-gradient(135deg, #764ba2 0%, #667eea 100%); color: white; text-align: center; font-weight: bold;">
                            📝 Colori del Testo del Pulsante
                        </th>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_button_text_color">Colore Testo (Normale)</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_button_text_color" name="cookie_consent_button_text_color" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_button_text_color', '#ffffff')); ?>">
                            <p class="description">Colore del testo e icona del pulsante cookie nello stato normale</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_button_text_color_hover">Colore Testo (Hover)</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_button_text_color_hover" name="cookie_consent_button_text_color_hover" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_button_text_color_hover', '#0073e6')); ?>">
                            <p class="description">Colore del testo e icona del pulsante cookie quando ci si passa sopra</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" colspan="2" style="background: linear-gradient(45deg, #667eea 0%, #764ba2 50%, #667eea 100%); color: white; text-align: center; font-weight: bold;">
                            🖼️ Stili Aggiuntivi
                        </th>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_button_border_color">Colore Bordo</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_button_border_color" name="cookie_consent_button_border_color" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_button_border_color', '#bbbbbb')); ?>">
                            <p class="description">Colore del bordo che circonda il pulsante cookie</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_use_gradient">🌈 Usa Gradiente per Sfondo</label>
                        </th>
                        <td>
                            <input type="checkbox" id="cookie_consent_use_gradient" name="cookie_consent_use_gradient" value="1"
                                   <?php checked(get_option('cookie_consent_use_gradient', false)); ?>>
                            <span style="margin-left: 8px; font-weight: 500;">Attiva l'effetto gradiente per lo sfondo</span>
                            <p class="description">Se attivato, al posto del colore pieno verrà usato un gradiente personalizzabile</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_gradient_start">Colore Iniziale Gradiente</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_gradient_start" name="cookie_consent_gradient_start" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_gradient_start', '#667eea')); ?>">
                            <p class="description">Primo colore del gradiente (punto di partenza)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_gradient_end">Colore Finale Gradiente</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_gradient_end" name="cookie_consent_gradient_end" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_gradient_end', '#764ba2')); ?>">
                            <p class="description">Secondo colore del gradiente (punto di arrivo)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_gradient_direction">Direzione Gradiente</label>
                        </th>
                        <td>
                            <select id="cookie_consent_gradient_direction" name="cookie_consent_gradient_direction">
                                <option value="to right" <?php selected(get_option('cookie_consent_gradient_direction', 'to right'), 'to right'); ?>>→ Da Sinistra a Destra</option>
                                <option value="to left" <?php selected(get_option('cookie_consent_gradient_direction', 'to right'), 'to left'); ?>>← Da Destra a Sinistra</option>
                                <option value="to bottom" <?php selected(get_option('cookie_consent_gradient_direction', 'to right'), 'to bottom'); ?>>↓ Dall'Alto in Basso</option>
                                <option value="to top" <?php selected(get_option('cookie_consent_gradient_direction', 'to right'), 'to top'); ?>>↑ Dal Basso in Alto</option>
                            </select>
                            <p class="description">Direzione in cui si sviluppa il gradiente</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_use_gradient_hover">🌈 Gradiente Hover Separato</label>
                        </th>
                        <td>
                            <input type="checkbox" id="cookie_consent_use_gradient_hover" name="cookie_consent_use_gradient_hover" value="1"
                                   <?php checked(get_option('cookie_consent_use_gradient_hover', false)); ?>>
                            <span style="margin-left: 8px; font-weight: 500;">Usa gradiente diverso per l'hover</span>
                            <p class="description">Attiva un gradiente personalizzato diverso per l'effetto hover</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_gradient_start_hover">Colore Iniziale (Hover)</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_gradient_start_hover" name="cookie_consent_gradient_start_hover" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_gradient_start_hover', '#667eea')); ?>">
                            <p class="description">Primo colore del gradiente hover</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_gradient_end_hover">Colore Finale (Hover)</label>
                        </th>
                        <td>
                            <input type="color" id="cookie_consent_gradient_end_hover" name="cookie_consent_gradient_end_hover" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_gradient_end_hover', '#764ba2')); ?>">
                            <p class="description">Secondo colore del gradiente hover</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" colspan="2" style="background: linear-gradient(135deg, #10b981 0%, #667eea 100%); color: white; text-align: center; font-weight: bold;">
                            📍 Posizionamento del Pulsante
                        </th>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_position_horizontal">Posizione Orizzontale</label>
                        </th>
                        <td>
                            <select id="cookie_consent_position_horizontal" name="cookie_consent_position_horizontal">
                                <option value="left" <?php selected(get_option('cookie_consent_position_horizontal', 'left'), 'left'); ?>>👈 Sinistra</option>
                                <option value="center" <?php selected(get_option('cookie_consent_position_horizontal', 'left'), 'center'); ?>>🎯 Centro</option>
                                <option value="right" <?php selected(get_option('cookie_consent_position_horizontal', 'left'), 'right'); ?>>👉 Destra</option>
                            </select>
                            <p class="description">Dove posizionare il pulsante lungo l'asse orizzontale della pagina</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_position_vertical">Posizione Verticale</label>
                        </th>
                        <td>
                            <select id="cookie_consent_position_vertical" name="cookie_consent_position_vertical">
                                <option value="top" <?php selected(get_option('cookie_consent_position_vertical', 'center'), 'top'); ?>>⬆️ Alto</option>
                                <option value="center" <?php selected(get_option('cookie_consent_position_vertical', 'center'), 'center'); ?>>🎯 Centro</option>
                                <option value="bottom" <?php selected(get_option('cookie_consent_position_vertical', 'center'), 'bottom'); ?>>⬇️ Basso</option>
                            </select>
                            <p class="description">Dove posizionare il pulsante lungo l'asse verticale della pagina</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="cookie_consent_position_offset">📏 Distanza dal Bordo</label>
                        </th>
                        <td>
                            <input type="text" id="cookie_consent_position_offset" name="cookie_consent_position_offset" 
                                   value="<?php echo esc_attr(get_option('cookie_consent_position_offset', '0')); ?>" 
                                   class="regular-text" placeholder="20px oppure 10%">
                            <p class="description">Distanza dal bordo selezionato. Esempi: <code>20px</code>, <code>5%</code>, <code>2rem</code></p>
                        </td>
                    </tr>
                </table>
            </div>

            <div style="margin: 20px 0; text-align: center;">
                <button type="button" id="show-preview-btn" onclick="showLivePreview()" class="button button-secondary">
                    🍪 Mostra Preview Live
                </button>
                <p class="description">Clicca per vedere un'anteprima in tempo reale del tuo pulsante cookie</p>
            </div>
            <script>
            let livePreviewContainer = null;
            
            function togglePrivacyLinks() {
                const languages = ['en', 'it', 'es', 'fr', 'de'];
                const checkboxes = document.querySelectorAll('input[name="cookie_consent_enabled_languages[]"]');
                
                languages.forEach(lang => {
                    const checkbox = document.querySelector(`input[name="cookie_consent_enabled_languages[]"][value="${lang}"]`);
                    const row = document.getElementById(`privacy_link_row_${lang}`);
                    
                    if (checkbox && row) {
                        row.style.display = checkbox.checked ? 'block' : 'none';
                    }
                });
            }
            
            // Toggle sections (collapsible)
            function toggleSection(headerElement, sectionId) {
                const section = document.getElementById(sectionId);
                const header = headerElement;
                
                if (section && header) {
                    const isCollapsed = section.classList.contains('collapsed');
                    
                    if (isCollapsed) {
                        section.classList.remove('collapsed');
                        header.classList.remove('collapsed');
                        section.style.maxHeight = section.scrollHeight + 'px';
                        setTimeout(() => {
                            section.style.maxHeight = 'none';
                        }, 300);
                    } else {
                        section.style.maxHeight = section.scrollHeight + 'px';
                        setTimeout(() => {
                            section.classList.add('collapsed');
                            header.classList.add('collapsed');
                        }, 10);
                    }
                    
                    // Save state in localStorage
                    localStorage.setItem(`cookie_consent_section_${sectionId}`, isCollapsed ? 'open' : 'collapsed');
                }
            }
            
            // Restore section states from localStorage
            function restoreSectionStates() {
                const sections = ['advanced-settings'];
                sections.forEach(sectionId => {
                    const state = localStorage.getItem(`cookie_consent_section_${sectionId}`);
                    const section = document.getElementById(sectionId);
                    const header = document.querySelector(`[data-section="${sectionId}"]`);
                    
                    if (state === 'collapsed' && section && header) {
                        section.classList.add('collapsed');
                        header.classList.add('collapsed');
                    }
                });
            }
            
            // Toggle gradient fields based on checkbox
            function toggleGradientFields() {
                const useGradient = document.getElementById('cookie_consent_use_gradient');
                const gradientRows = [
                    document.querySelector('#cookie_consent_gradient_start')?.closest('tr'),
                    document.querySelector('#cookie_consent_gradient_end')?.closest('tr'),
                    document.querySelector('#cookie_consent_gradient_direction')?.closest('tr')
                ];
                
                if (useGradient) {
                    const isChecked = useGradient.checked;
                    gradientRows.forEach(row => {
                        if (row) {
                            row.style.opacity = isChecked ? '1' : '0.5';
                            const inputs = row.querySelectorAll('input, select');
                            inputs.forEach(input => input.disabled = !isChecked);
                        }
                    });
                }
            }
            
            function toggleGradientHoverFields() {
                const useGradientHover = document.getElementById('cookie_consent_use_gradient_hover');
                const gradientHoverRows = [
                    document.querySelector('#cookie_consent_gradient_start_hover')?.closest('tr'),
                    document.querySelector('#cookie_consent_gradient_end_hover')?.closest('tr')
                ];
                
                if (useGradientHover) {
                    const isChecked = useGradientHover.checked;
                    gradientHoverRows.forEach(row => {
                        if (row) {
                            row.style.opacity = isChecked ? '1' : '0.5';
                            const inputs = row.querySelectorAll('input');
                            inputs.forEach(input => input.disabled = !isChecked);
                        }
                    });
                }
            }
            
            // Show/Hide Live Preview
            function showLivePreview() {
                if (livePreviewContainer && document.body.contains(livePreviewContainer)) {
                    // Se già esiste, la rimuoviamo
                    livePreviewContainer.remove();
                    livePreviewContainer = null;
                    document.getElementById('show-preview-btn').textContent = '🍪 Mostra Preview Live';
                } else {
                    // Creiamo una nuova preview
                    createLivePreview();
                    document.getElementById('show-preview-btn').textContent = '❌ Nascondi Preview';
                }
            }
            
            // Live preview function
            function createLivePreview() {
                livePreviewContainer = document.createElement('div');
                livePreviewContainer.innerHTML = `
                    <div style="position: fixed; top: 20px; right: 20px; background: white; border: 2px solid #667eea; border-radius: 10px; padding: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.15); z-index: 9999; max-width: 300px;">
                        <h3 style="margin: 0 0 15px 0; color: #667eea; font-size: 16px;">🍪 Live Preview</h3>
                        <div id="cookie-preview" style="position: relative; background: #f8f9fa; border-radius: 8px; padding: 15px; min-height: 100px;">
                            <div id="preview-button" style="position: absolute; background: #f0f0f0; border: 1px solid #bbbbbb; border-radius: 0 8px 8px 0; padding: 8px 4px; min-height: 60px; width: 30px; display: flex; align-items: center; justify-content: center; flex-direction: column; font-size: 12px; color: #000; cursor: pointer;">
                                🍪<br><span style="writing-mode: vertical-rl; text-orientation: mixed; font-size: 8px;">Cookie</span>
                            </div>
                        </div>
                        <button onclick="closeLivePreview()" style="position: absolute; top: 5px; right: 10px; background: none; border: none; font-size: 18px; cursor: pointer;">×</button>
                    </div>
                `;
                document.body.appendChild(livePreviewContainer);
                updatePreview();
            }
            
            function closeLivePreview() {
                if (livePreviewContainer) {
                    livePreviewContainer.remove();
                    livePreviewContainer = null;
                    document.getElementById('show-preview-btn').textContent = '🍪 Mostra Preview Live';
                }
            }
            
            function updatePreview() {
                const previewButton = document.getElementById('preview-button');
                if (!previewButton) return;
                
                // Get current values
                const bgColor = document.getElementById('cookie_consent_button_bg_color')?.value || '#f0f0f0';
                const textColor = document.getElementById('cookie_consent_button_text_color')?.value || '#ffffff';
                const borderColor = document.getElementById('cookie_consent_button_border_color')?.value || '#bbbbbb';
                const useGradient = document.getElementById('cookie_consent_use_gradient')?.checked || false;
                const gradientStart = document.getElementById('cookie_consent_gradient_start')?.value || '#667eea';
                const gradientEnd = document.getElementById('cookie_consent_gradient_end')?.value || '#764ba2';
                const gradientDirection = document.getElementById('cookie_consent_gradient_direction')?.value || 'to right';
                const positionH = document.getElementById('cookie_consent_position_horizontal')?.value || 'left';
                const positionV = document.getElementById('cookie_consent_position_vertical')?.value || 'center';
                
                // Calculate background
                const background = useGradient ? 
                    `linear-gradient(${gradientDirection}, ${gradientStart}, ${gradientEnd})` : 
                    bgColor;
                
                // Calculate position
                let positionStyle = '';
                let borderRadius = '';
                
                if (positionH === 'left') {
                    positionStyle = 'left: 0;';
                    borderRadius = '0 8px 8px 0';
                } else if (positionH === 'right') {
                    positionStyle = 'right: 0;';
                    borderRadius = '8px 0 0 8px';
                } else {
                    positionStyle = 'left: 50%; transform: translateX(-50%);';
                    borderRadius = '8px';
                }
                
                if (positionV === 'top') {
                    positionStyle += ' top: 10px;';
                } else if (positionV === 'bottom') {
                    positionStyle += ' bottom: 10px;';
                } else {
                    positionStyle += ' top: 50%; transform: translateY(-50%);';
                    if (positionH === 'center') {
                        positionStyle = positionStyle.replace('translateX(-50%)', 'translate(-50%, -50%)');
                    }
                }
                
                // Apply styles
                previewButton.style.cssText = `
                    position: absolute;
                    ${positionStyle}
                    background: ${background};
                    border: 1px solid ${borderColor};
                    border-radius: ${borderRadius};
                    padding: 8px 4px;
                    min-height: 60px;
                    width: 30px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex-direction: column;
                    font-size: 12px;
                    color: ${textColor};
                    cursor: pointer;
                    transition: all 0.3s ease;
                `;
            }
            
            // Initialize everything on page load
            document.addEventListener('DOMContentLoaded', function() {
                restoreSectionStates();
                togglePrivacyLinks();
                toggleGradientFields();
                toggleGradientHoverFields();
                
                // Add event listeners for checkboxes
                const langCheckboxes = document.querySelectorAll('input[name="cookie_consent_enabled_languages[]"]');
                langCheckboxes.forEach(cb => cb.addEventListener('change', togglePrivacyLinks));
                
                document.getElementById('cookie_consent_use_gradient')?.addEventListener('change', function() {
                    toggleGradientFields();
                    updatePreview();
                });
                
                document.getElementById('cookie_consent_use_gradient_hover')?.addEventListener('change', function() {
                    toggleGradientHoverFields();
                });
                
                // Add listeners for live preview updates
                const previewFields = [
                    'cookie_consent_button_bg_color',
                    'cookie_consent_button_text_color', 
                    'cookie_consent_button_border_color',
                    'cookie_consent_gradient_start',
                    'cookie_consent_gradient_end',
                    'cookie_consent_gradient_direction',
                    'cookie_consent_position_horizontal',
                    'cookie_consent_position_vertical'
                ];
                
                previewFields.forEach(fieldId => {
                    const field = document.getElementById(fieldId);
                    if (field) {
                        field.addEventListener('change', updatePreview);
                        field.addEventListener('input', updatePreview);
                    }
                });
            });
            </script>

            <?php submit_button('Salva Impostazioni'); ?>
        </form>
    </div>
    <?php
}

// Add admin notice for settings update
add_action('admin_notices', 'cookie_consent_admin_notice');
function cookie_consent_admin_notice() {
    if (isset($_GET['page']) && $_GET['page'] === 'cookie-consent-settings' && isset($_GET['settings-updated'])) {
        ?>
        <div class="notice notice-success is-dismissible" style="border-left-color: #10b981; background: linear-gradient(90deg, #ecfdf5 0%, #f0fdf4 100%); border-radius: 8px; margin: 16px 0; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);">
            <p style="display: flex; align-items: center; gap: 8px; font-weight: 500;">
                <span style="font-size: 18px;">✅</span>
                <?php _e('Le impostazioni del consenso cookie sono state aggiornate con successo! Le tue modifiche sono ora attive.', 'cookie-consent'); ?>
            </p>
        </div>
        <?php
    }
}

// Add settings link to plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'cookie_consent_settings_link');
function cookie_consent_settings_link($links) {
    $settings_link = '<a href="admin.php?page=cookie-consent-settings">' . __('Impostazioni') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

/************* START - In Your Life Srl *************/
define ('MY_CUSTOM_PLUGIN_DIR', plugin_dir_url((__FILE__)));

add_action('wp_head', 'cookie_css_files');
function cookie_css_files(){
    
    $current_page_id = get_the_ID();
    $privacy_policy_page_id = get_option( 'wp_page_for_privacy_policy' );
    
    if( $current_page_id == $privacy_policy_page_id ){
        return false;
    }
		$cccss =MY_CUSTOM_PLUGIN_DIR."cookieconsent-min.css";
		echo<<<eot
			<link rel="stylesheet" href="$cccss" />
eot;
}

add_action('wp_footer', 'cookie_js_files');
function cookie_js_files(){
    $current_page_id = get_the_ID();
    $privacy_policy_page_id = get_option('wp_page_for_privacy_policy');
    
    if($current_page_id == $privacy_policy_page_id){
        return false;
    }
    
    $ccjs = MY_CUSTOM_PLUGIN_DIR.'cookieconsent-init.js';
    $domain = get_option('cookie_consent_domain', '');
    $ga4_id = get_option('cookie_consent_ga4_id', '');
    $privacy_links = get_option('cookie_consent_privacy_links', array());
    $enabled_languages = get_option('cookie_consent_enabled_languages', array('it'));
    
    // Ensure enabled_languages is always an array
    if (!is_array($enabled_languages)) {
        $enabled_languages = array('it'); // Default to Italian if not array
    }
    
    // Ensure privacy_links is always an array
    if (!is_array($privacy_links)) {
        $privacy_links = array();
    }
    
    // Create a JavaScript object with the settings
    $settings = array(
        'domain' => $domain,
        'ga4_id' => $ga4_id,
        'privacy_links' => $privacy_links,
        'enabled_languages' => $enabled_languages
    );
    
    // Debug output
    error_log('Cookie Consent Settings: ' . print_r($settings, true));
    
    $json_settings = json_encode($settings, JSON_HEX_APOS | JSON_HEX_QUOT);
    
    // Get all styling options
    $bg_color = get_option('cookie_consent_button_bg_color', '#f0f0f0');
    $text_color = get_option('cookie_consent_button_text_color', '#ffffff');
    $border_color = get_option('cookie_consent_button_border_color', '#bbbbbb');
    
    // New advanced options
    $bg_color_hover = get_option('cookie_consent_button_bg_color_hover', '#e0e0e0');
    $text_color_hover = get_option('cookie_consent_button_text_color_hover', '#0073e6');
    $use_gradient = get_option('cookie_consent_use_gradient', false);
    $gradient_start = get_option('cookie_consent_gradient_start', '#667eea');
    $gradient_end = get_option('cookie_consent_gradient_end', '#764ba2');
    $gradient_direction = get_option('cookie_consent_gradient_direction', 'to right');
    $use_gradient_hover = get_option('cookie_consent_use_gradient_hover', false);
    $gradient_start_hover = get_option('cookie_consent_gradient_start_hover', '#667eea');
    $gradient_end_hover = get_option('cookie_consent_gradient_end_hover', '#764ba2');
    
    // Position options
    $position_horizontal = get_option('cookie_consent_position_horizontal', 'left');
    $position_vertical = get_option('cookie_consent_position_vertical', 'center');
    $position_offset = get_option('cookie_consent_position_offset', '0');
    
    // Calculate background styles
    $background_normal = $use_gradient ? 
        "linear-gradient({$gradient_direction}, {$gradient_start}, {$gradient_end})" : 
        $bg_color;
    
    $background_hover = $use_gradient_hover ? 
        "linear-gradient({$gradient_direction}, {$gradient_start_hover}, {$gradient_end_hover})" : 
        $bg_color_hover;
    
    // Calculate position styles based on settings
    $position_styles = '';
    $border_radius = '';
    $transform_base = '';
    $transform_hover = '';
    
    if ($position_horizontal === 'left') {
        $position_styles = "left: 0 !important;";
        $border_radius = "0 8px 8px 0 !important;";
        $position_styles .= "border-left: none !important;";
        $transform_hover = "translateX(3px)";
    } elseif ($position_horizontal === 'right') {
        $position_styles = "right: 0 !important;";
        $border_radius = "8px 0 0 8px !important;";
        $position_styles .= "border-right: none !important;";
        $transform_hover = "translateX(-3px)";
    } else { // center
        $position_styles = "left: 50% !important; transform: translateX(-50%)";
        $border_radius = "8px !important;";
        $transform_hover = "translateY(-2px)";
    }
    
    if ($position_vertical === 'top') {
        $offset = $position_offset ? $position_offset : '20px';
        $position_styles .= " top: {$offset} !important;";
        if ($position_horizontal === 'center') {
            $transform_base = "translate(-50%, 0) !important;";
            $transform_hover = "translate(-50%, -2px)";
        }
    } elseif ($position_vertical === 'bottom') {
        $offset = $position_offset ? $position_offset : '20px';
        $position_styles .= " bottom: {$offset} !important;";
        if ($position_horizontal === 'center') {
            $transform_base = "translate(-50%, 0) !important;";
            $transform_hover = "translate(-50%, 2px)";
        }
    } else { // center
        $offset = $position_offset ? $position_offset : '50%';
        $position_styles .= " top: {$offset} !important;";
        if ($position_horizontal === 'center') {
            $transform_base = "translate(-50%, -50%) !important;";
            $transform_hover = "translate(-50%, -52px)";
        } else {
            $transform_base = "translateY(-50%) !important;";
            $transform_hover = $position_horizontal === 'left' ? 
                "translateY(-50%) translateX(3px)" : 
                "translateY(-50%) translateX(-3px)";
        }
    }

    echo <<<EOT
    <script>
        window.cookieConsentSettings = {$json_settings};
    </script>

    <style>
    /* Personalizzazione bottone "Rifiuta tutto" (solo quello con data-role="necessary") */
    #cc-main .cm .cm__btn[data-role="necessary"] {
        background: #b81414 !important;
        color: #ffffff !important;
        border-color: #b81414 !important;
    }
    
    #cc-main .cm .cm__btn[data-role="necessary"]:hover {
        background: #a01212 !important;
        color: #ffffff !important;
        border-color: #a01212 !important;
    }
    
    .fixed-left {
        position: fixed !important;
        {$position_styles}
        padding: 12px 8px !important;
        background: {$background_normal} !important;
        border: 1px solid {$border_color} !important;
        border-radius: {$border_radius};
        z-index: 1000 !important;
        cursor: pointer !important;
        transition: all 0.3s ease !important;
        writing-mode: vertical-rl !important;
        text-orientation: mixed !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 8px !important;
        min-height: 100px !important;
        width: 42px !important;
        transform: {$transform_base};
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15) !important;
    }

    .fixed-left:hover {
        background: {$background_hover} !important;
        transform: {$transform_hover} !important;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25) !important;
    }

    .vertical-text {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
        font-size: 0.75em !important;
        color: {$text_color} !important;
        transform: rotate(180deg) !important;
        letter-spacing: 0.5px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 6px !important;
        font-weight: 500 !important;
        width: 100% !important;
        height: 100% !important;
    }

    .vertical-text a {
        text-decoration: none !important;
        color: {$text_color} !important;
        transition: color 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 6px !important;
        height: 100% !important;
        width: 100% !important;
    }

    .vertical-text a:hover {
        color: {$text_color_hover} !important;
    }

    .cookie-icon {
        font-size: 1.4em !important;
        transition: transform 0.3s ease !important;
        margin-bottom: 4px !important;
        color: {$text_color} !important;
    }

    .fixed-left:hover .cookie-icon {
        transform: rotate(-15deg) !important;
        color: {$text_color_hover} !important;
    }

    .cookie-text {
        font-size: 0.9em !important;
        font-weight: 600 !important;
        margin-top: 4px !important;
        color: {$text_color} !important;
    }

    .fixed-left:hover .cookie-text {
        color: {$text_color_hover} !important;
    }

    /* Mobile responsive - solo icona */
    @media (max-width: 768px) {
        .fixed-left {
            width: 35px !important;
            min-height: 35px !important;
            padding: 8px !important;
            border-radius: {$border_radius};
        }
        
        .cookie-text {
            display: none !important;
        }
        
        .cookie-icon {
            font-size: 1.2em !important;
            margin-bottom: 0 !important;
        }
        
        .vertical-text {
            font-size: 0.75em !important;
            gap: 0 !important;
        }
        
        .vertical-text a {
            gap: 0 !important;
        }
    }
    </style>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <div class="fixed-left" aria-label="Impostazioni Cookie">
        <a href="#" data-cc="show-preferencesModal" class="vertical-text" role="button" tabindex="0" aria-label="Apri Preferenze Cookie">
            <i class="fas fa-cookie-bite cookie-icon" aria-hidden="true"></i>
            <span class="cookie-text">Cookie Policy</span>
        </a>
    </div>
    <script defer type="module" src="$ccjs"></script>
EOT;
}

add_action( 'wp_head', 'google_analytics' );
function google_analytics(){ 
    $ga4_id = get_option('cookie_consent_ga4_id');
    if (empty($ga4_id)) {
        return;
    }
    ?>
<script>
window.dataLayer = window.dataLayer || [];

function gtag() {
    dataLayer.push(arguments);
}
gtag('consent', 'default', {
    'ad_storage': 'denied',
    'ad_user_data': 'denied',
    'ad_personalization': 'denied',
    'analytics_storage': 'denied',
    'functionality_storage': 'denied',
    'personalization_storage': 'denied',
});
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script type="text/plain" data-category="analytics" async
    src="https://www.googletagmanager.com/gtag/js?id=<?php echo esc_attr($ga4_id); ?>"></script>
<script type="text/plain" data-category="analytics">
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '<?php echo esc_attr($ga4_id); ?>');
</script>
<?php
}

add_action( 'wp_head', 'track_analytics' );
function track_analytics(){ ?>
<script>
<?php echo get_option('cookie_consent_conversion_tracking', ''); ?>
</script>
<?php
} 

add_action( 'woocommerce_thankyou', 'my_custom_tracking' );

function my_custom_tracking( $order_id ) {
// Lets grab the order
$order = wc_get_order( $order_id );

// This is the order total
$totale_ordine=$order->get_total();

// This is how to grab line items from the order 
$line_items = $order->get_items();

$code='<script>window.onload = ()=>{gtag("event", "purchase", {
transaction_id: '.$order_id.',
value: '.$totale_ordine.',
currency: "EUR",
items: [';

// This loops over line items
foreach ( $line_items as $item ) {
	// This will be a product
	$product = $order->get_product_from_item( $item );

	$id_prodotto = $product->get_id();
	$nome_prodotto = $product->get_name();
	$qty = $item['qty'];
	// Line item total cost including taxes and rounded
	$total_prod = $order->get_line_total( $item, true, true );
	
	$code.='
	{
	item_id: "'.$id_prodotto.'",
	item_name: "'.$nome_prodotto.'",
	price: '.$total_prod.',
	quantity: '.$qty.'
	},';
}
$code.=']
});}</script>';

echo $code;
}
