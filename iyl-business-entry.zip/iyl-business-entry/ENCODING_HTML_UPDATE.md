# 🔧 Aggiornamento Encoding HTML per Caratteri Speciali

## 📝 Problema Risolto

I campi dei messaggi del form contenenti caratteri speciali italiani (è, à, ò, ù, ecc.) causavano errori nella console quando utilizzati con Elementor, poiché i caratteri non venivano interpretati correttamente.

## ✅ Soluzione Implementata

### 1. **Conversione Automatica in Entità HTML**
- I caratteri speciali vengono automaticamente convertiti in entità HTML
- Esempi: `è` → `&egrave;`, `à` → `&agrave;`, `ò` → `&ograve;`
- Garantisce compatibilità universale con tutti i browser e sistemi

### 2. **Sanitize Callback Migliorato**
- Nuovo callback `sanitize_form_field()` che preserva le entità HTML
- Permette tag HTML di base per i link (campo privacy)
- Conversione automatica durante il salvataggio

### 3. **Rendering Ottimizzato in Elementor**
- Decodifica automatica delle entità HTML nel rendering
- Distinzione tra messaggi semplici e campo privacy (con link)
- Output corretto per tutte le lingue supportate

### 4. **Aggiornamento Retroattivo**
- Funzione per aggiornare i messaggi esistenti nel database
- Pulsante di aggiornamento nel pannello di amministrazione
- Conversione automatica durante l'attivazione del plugin

### 5. **Shortcode per Form Elementor**
- Creati shortcode dedicati per i form di Elementor
- Rilevamento automatico della lingua corrente (Polylang/WPML)
- Supporto per tutti i tipi di messaggio del form
- Gestione corretta dell'encoding HTML

### 6. **Interface Accordion**
- Info box convertite in accordion per ridurre l'impatto visivo
- Apertura/chiusura delle sezioni informative
- Design elegante e accessibile
- Funzionalità esclusiva (un accordion aperto alla volta)

### 7. **Link Privacy Policy Configurabili**
- Nuovo campo "Link Privacy Policy" per ogni lingua
- Link di default specifici per ogni lingua
- Aggiornamento automatico nei messaggi GDPR
- Supporto per strutture URL multilingua

## 🛠️ File Modificati

### `includes/admin/class-iyl-data-multilang-admin.php`
- ✅ Aggiunto `sanitize_form_field()` per preservare entità HTML
- ✅ Aggiunto `convert_special_chars_to_entities()` per conversione automatica
- ✅ Aggiornati i messaggi di default con entità HTML
- ✅ Migliorato rendering admin con decodifica per visualizzazione
- ✅ Aggiunta funzione AJAX per aggiornamento encoding
- ✅ Aggiunto info box nel pannello admin
- ✅ **Aggiunti shortcode per form: `register_form_shortcodes()`**
- ✅ **Shortcode privacy: `shortcode_privacy_text()`**
- ✅ **Shortcode messaggi: `shortcode_form_message()`**
- ✅ **Rilevamento lingua automatico: `get_current_language()`**
- ✅ **Interface accordion per ridurre impatto visivo**
- ✅ **Campo "privacy_policy_link" per ogni lingua**
- ✅ **Link configurabili per messaggi GDPR**

### `iyl-data-for-elementor.php`
- ✅ Aggiornati messaggi di default nell'attivazione
- ✅ Aggiunta funzione per aggiornamento automatico encoding esistente
- ✅ **Aggiunti link privacy policy di default per ogni lingua**

### `includes/elementor/class-iyl-data-multilang-elementor.php`
- ✅ Migliorato rendering form tags con decodifica HTML entities
- ✅ Distinzione tra campo privacy (con HTML) e messaggi semplici

### `includes/elementor/tags/class-iyl-multilang-tag-base.php`
- ✅ Aggiunto metodo `sanitize_output()` con context 'form_message'
- ✅ Aggiunto metodo `get_form_message()` per gestione corretta

### `assets/js/admin.js`
- ✅ Aggiunta funzione `initEncodingUpdate()` per gestire pulsante
- ✅ AJAX call per aggiornamento encoding con feedback utente
- ✅ **Aggiunta funzione `initAccordion()` per gestire accordion**

### `assets/css/admin.css`
- ✅ Stili per info box encoding e pulsante di aggiornamento
- ✅ **Stili completi per accordion con animazioni**
- ✅ **Design elegante e responsive per le info box**

## 🔄 Caratteri Supportati

### Italiano
- `è` → `&egrave;`, `é` → `&eacute;`
- `à` → `&agrave;`, `á` → `&aacute;`
- `ì` → `&igrave;`, `í` → `&iacute;`
- `ò` → `&ograve;`, `ó` → `&oacute;`
- `ù` → `&ugrave;`, `ú` → `&uacute;`

### Altre Lingue
- **Spagnolo**: `ñ` → `&ntilde;`
- **Francese**: `ç` → `&ccedil;`
- **Tedesco**: `ü` → `&uuml;`, `ä` → `&auml;`, `ö` → `&ouml;`, `ß` → `&szlig;`

## 📝 **Shortcode Disponibili**

### 🔒 **Privacy/GDPR**
```
[iyl_privacy_text]                    # Lingua automatica + link configurabile
[iyl_privacy_text lang="en"]          # Lingua specifica + link configurabile
[iyl_gdpr_text]                       # Alias per retrocompatibilità
```

### 💬 **Messaggi del Form**
```
[iyl_form_message type="success"]     # Messaggio di successo
[iyl_form_message type="error"]       # Messaggio di errore
[iyl_form_message type="server_error"] # Errore del server
[iyl_form_message type="invalid"]     # Form non valido

# Con lingua specifica
[iyl_form_message type="success" lang="fr"]
[iyl_form_message type="error" lang="de"]
```

### 🌐 **Parametri Supportati**
- `lang`: Specifica la lingua (it, en, es, fr, de)
- `fallback`: Lingua di fallback (default: it)
- `type`: Tipo di messaggio (per form_message)

## 📱 **Come Usare gli Shortcode**

### **Nel Form di Elementor**
1. **Accettazione Privacy**: 
   - Nel campo "Acceptance Text" inserisci: `[iyl_privacy_text]`
   - Lo shortcode mostrerà il testo GDPR nella lingua corrente

2. **Messaggi di Errore/Successo**:
   - Nei campi dei messaggi inserisci: `[iyl_form_message type="success"]`
   - Supporta tutti i tipi di messaggio configurati

3. **Multilingua Automatico**:
   - Gli shortcode rilevano automaticamente la lingua da Polylang/WPML
   - Fallback all'italiano se la lingua non è disponibile

## 🎯 Risultati

- ✅ **Zero errori di encoding** nella console
- ✅ **Caratteri speciali** visualizzati correttamente
- ✅ **Compatibilità universale** con tutti i browser
- ✅ **Retrocompatibilità** con messaggi esistenti
- ✅ **Gestione automatica** dei nuovi inserimenti

## 💡 Note Tecniche

- Le entità HTML sono lo standard per caratteri speciali nel web
- La decodifica avviene solo nel rendering finale per l'utente
- Il database mantiene le entità per garantire sicurezza e compatibilità
- I link nel campo privacy continuano a funzionare normalmente 

## 🔧 **Link Privacy Policy per Lingua**

### **Link di Default**
- **🇮🇹 Italiano**: `/privacy-policy/`
- **🇬🇧 Inglese**: `/en/privacy-policy/`
- **🇪🇸 Spagnolo**: `/es/politica-de-privacidad/`
- **🇫🇷 Francese**: `/fr/politique-de-confidentialite/`
- **🇩🇪 Tedesco**: `/de/datenschutzerklaerung/`

### **Personalizzazione**
1. **Nel Pannello IYL Data**: Ogni lingua ha il campo "Link Privacy Policy"
2. **Configurazione**: Inserisci il link alla pagina privacy per ogni lingua
3. **Aggiornamento Automatico**: I messaggi GDPR si aggiornano automaticamente

### **Formato GDPR Corretto**
```html
Dichiaro di avere letto e compreso l'informativa sulla <a href="/privacy-policy/" target="_blank">Privacy</a> ai sensi degli artt. 13 e 14 del Regolamento UE 2016/679 *
```

### **Funzionalità Avanzate**
- **Rilevamento Lingua**: Lo shortcode usa automaticamente il link della lingua corrente
- **Fallback Sicuro**: Se il link non è configurato, usa quello di default
- **Aggiornamento Live**: Modifiche ai link si riflettono immediatamente negli shortcode

## 🎨 **Interface Accordion**

### **Funzionalità**
- **Click per Aprire**: Clicca sull'header dell'accordion per aprire/chiudere
- **Comportamento Esclusivo**: Solo un accordion aperto alla volta
- **Animazioni Fluide**: Transizioni eleganti con slideUp/slideDown
- **Icone Dinamiche**: Rotazione automatica delle frecce

### **Vantaggi**
- ✅ **Meno Invasivo**: Le informazioni importanti non occupano sempre spazio
- ✅ **Organizzazione**: Contenuto ben strutturato e facilmente accessibile
- ✅ **User Experience**: Interface più pulita e professionale
- ✅ **Responsive**: Funziona perfettamente su tutti i dispositivi 