# IYL Business Entry - Plugin WordPress Multilingua

Un plugin WordPress potente e moderno per gestire informazioni aziendali multilingua con integrazione completa per Elementor. Perfetto per siti web che necessitano di dati dinamici in più lingue.

## 🚀 **Novità Versione 2.0**

### ✨ **Interfaccia Completamente Ridisegnata**
- **Design Ultra-moderno**: Stile pulito e moderno ispirato ai migliori plugin WordPress
- **UX Migliorata**: Interfaccia intuitiva con cards e layout responsivo
- **Navigation a Tab**: Gestione semplice e veloce tra le lingue
- **Design Responsive**: Perfetto su desktop, tablet e mobile

### 🌍 **Sistema Multilingua Esteso**
- **5 Lingue Supportate**: 
  - 🇮🇹 **Italiano** (predefinito)
  - 🇬🇧 **Inglese** 
  - 🇪🇸 **Spagnolo** *(NUOVO!)*
  - 🇫🇷 **Francese**
  - 🇩🇪 **Tedesco**
- **Attivazione Dinamica**: Attiva solo le lingue necessarie
- **Subject Email Localizzati**: Testi predefiniti per ogni lingua
- **Tab Navigation**: Gestione separata per ogni lingua attiva

### 🔗 **Auto-generazione Link Intelligente**
- **Email**: `mailto:email@domain.com?subject=Richiesta+inviata+da+Domain`
- **Telefono**: Formattazione automatica `tel:+39123456789`
- **WhatsApp**: Link diretto `https://wa.me/+39numero`
- **Social Media**: URL completi da semplici username

### 🎯 **Integrazione Elementor Potenziata**
- **Dynamic Tags Funzionanti**: Problema risolto completamente
- **Tag Specifici per Lingua**: Gruppi separati per ogni lingua
- **Tag Link Dedicati**: Tag URL separati per email, telefono, WhatsApp
- **Auto-rilevamento**: Sistema intelligente senza perdita di configurazione

## 📋 **Campi Disponibili**

### 📊 **Informazioni Generali**
- **Nome Sito**: Nome dell'azienda/organizzazione
- **Dominio**: URL completo del sito web
- **Anno di Creazione Sito**: Anno di fondazione (usato per il copyright dinamico)
- **Indirizzo**: Indirizzo fisico completo
- **Link Indirizzo**: URL Google Maps/Apple Maps
- **Iframe Mappa**: Codice embed per mappa interattiva
- **P.IVA**: Partita IVA o Codice Fiscale

### 📞 **Contatti**
- **Email** + **Link Email** (auto-generato)
- **Telefono** + **Link Telefono** (auto-generato)
- **Cellulare** + **Link Cellulare** (auto-generato)
- **WhatsApp** + **Link WhatsApp** (auto-generato)

### 🌐 **Social Networks**
- **Facebook**: Username/pagina Facebook
- **Instagram**: Username Instagram  
- **LinkedIn**: Nome azienda LinkedIn
- **Twitter/X**: Username Twitter
- **Pinterest**: Username Pinterest

### ⚙️ **Impostazioni Form**
- **Messaggi Localizzati**:
  - 🇮🇹 "La tua richiesta è stata inviata con successo."
  - 🇬🇧 "Your request has been sent successfully."
  - 🇪🇸 "Tu solicitud ha sido enviada con éxito."
  - 🇫🇷 "Votre demande a été envoyée avec succès."
  - 🇩🇪 "Ihre Anfrage wurde erfolgreich gesendet."
  
- **Messaggi di Errore**:
  - Errore del form
  - Errore del Server  
  - Form Invalido
- **Accettazione Privacy**: Testo GDPR-compliant per l'accettazione privacy/cookies

### 📅 **Shortcode [dynamic_year]**
- **Copyright Dinamico**: Genera automaticamente il copyright con anno corrente
- **Multilingua**: Testi tradotti per ogni lingua supportata
- **Output Esempio**: `Nome Sito - Copyright © 2024-2025 - Tutti i diritti riservati. Siti Internet by InYourLife`
- **Uso**: Inserisci `[dynamic_year]` nel footer del tuo sito
- **Configurazione**: Imposta l'anno di creazione nelle impostazioni del plugin

### 📝 **Shortcode per Form Elementor**

I form di Elementor non supportano i Dynamic Tags nei campi di testo. Usa questi shortcode:

#### 🔒 **Privacy/GDPR**
```
[iyl_privacy_text]                    # Lingua automatica
[iyl_privacy_text lang="en"]          # Lingua specifica  
[iyl_gdpr_text]                       # Alias alternativo
```

#### 💬 **Messaggi del Form**
```
[iyl_form_message type="success"]     # Successo
[iyl_form_message type="error"]       # Errore generico
[iyl_form_message type="server_error"] # Errore server
[iyl_form_message type="invalid"]     # Form non valido
```

#### 🌐 **Multilingua Automatico**
- **Rilevamento Automatico**: Gli shortcode rilevano la lingua corrente (Polylang/WPML)
- **Fallback Sicuro**: Se la lingua non è disponibile, usa l'italiano
- **Encoding Corretto**: Caratteri speciali (è, à, ò, ù) gestiti automaticamente

#### 💡 **Come Usare**
1. **Nel Form di Elementor**: Inserisci lo shortcode nel campo "Acceptance Text"
2. **Configurazione Zero**: Lo shortcode usa automaticamente la lingua del visitatore
3. **Sempre Aggiornato**: Modifiche nelle impostazioni si riflettono automaticamente

## 🎨 **Changelog**

### **v2.1.0 - HTML Encoding & Shortcode Revolution** 🔧📝
*Data: Dicembre 2024*

#### ✨ **Nuove Funzionalità**
- **🔤 HTML Encoding Automatico**: Caratteri speciali (è, à, ò, ù, ecc.) convertiti automaticamente in entità HTML
- **📝 Shortcode per Form Elementor**: Sistema shortcode dedicato per form che non supportano Dynamic Tags
- **🎛️ Interface Accordion**: Info box convertite in accordion per ridurre impatto visivo
- **🔗 Link Privacy Policy Configurabili**: Campo dedicato per link privacy per ogni lingua
- **🔄 Aggiornamento Retroattivo**: Pulsante per convertire messaggi esistenti all'encoding HTML

#### 📝 **Shortcode Implementati**
```
[iyl_privacy_text]                    # Privacy/GDPR con lingua automatica
[iyl_privacy_text lang="en"]          # Privacy/GDPR con lingua specifica
[iyl_form_message type="success"]     # Messaggi form (success, error, server_error, invalid)
[iyl_gdpr_text]                       # Alias privacy per retrocompatibilità
```

#### 🔧 **Link Privacy Policy per Lingua**
- **🇮🇹 Italiano**: `/privacy-policy/`
- **🇬🇧 Inglese**: `/en/privacy-policy/`
- **🇪🇸 Spagnolo**: `/es/politica-de-privacidad/`
- **🇫🇷 Francese**: `/fr/politique-de-confidentialite/`
- **🇩🇪 Tedesco**: `/de/datenschutzerklaerung/`

#### 🎨 **UI/UX Miglioramenti**
- **Accordion Interface**: Sezioni informative compatte con animazioni fluide
- **Auto-rilevamento Lingua**: Shortcode rilevano automaticamente Polylang/WPML
- **Encoding Status**: Feedback visivo per operazioni di aggiornamento
- **Design Elegante**: Gradienti e animazioni per un'esperienza professionale

#### 🐛 **Risoluzione Problemi**
- **Console Errors**: Eliminati errori di encoding caratteri speciali in Elementor
- **Form Compatibility**: Risolto problema Dynamic Tags non supportati in campi form
- **GDPR Compliance**: Link privacy policy corretti per strutture multilingua
- **Backward Compatibility**: Supporto completo per configurazioni esistenti

---

### **v2.0.0 - Multilingua Revolution** 🌐
*Data: Novembre 2024*

#### ✨ **Funzionalità Principali**
- **🌍 Sistema Multilingua Completo**: Supporto 5 lingue (IT, EN, ES, FR, DE)
- **🎯 Dynamic Tags Elementor**: Tag specifici per ogni lingua e campo
- **📱 Gestione Attivazione Lingue**: Toggle dinamico per attivare/disattivare lingue
- **📋 Campi Dati Completi**: 15+ campi per informazioni aziendali

#### 🏢 **Campi Aziendali**
- **Informazioni Base**: Nome sito, dominio, indirizzo, mappa
- **Contatti**: Email, telefono, cellulare, WhatsApp con link automatici
- **Social**: Facebook, Instagram, LinkedIn, Twitter, Pinterest
- **Legal**: P.IVA, CIN per strutture ricettive

#### 📝 **Form Elementor**
- **Messaggi Localizzati**: Successo, errore, server error, form invalido
- **Privacy GDPR**: Testo accettazione privacy multilingua
- **Auto-generazione Link**: Email, telefono, WhatsApp automatici

#### 📅 **Copyright Dinamico**
- **Shortcode [dynamic_year]**: Copyright automatico con anno corrente
- **Multilingua**: Testi tradotti per ogni lingua
- **Auto-update**: Anno di fine che si aggiorna automaticamente

---

### **v1.x.x - Versioni Legacy** 📦
*Versioni precedenti con funzionalità base*

#### 🔄 **Migrazione Automatica**
- **Compatibilità**: Supporto automatico per configurazioni v1.x
- **Aggiornamento Zero-downtime**: Migrazione trasparente senza perdita dati
- **Backup Automatico**: Conservazione impostazioni esistenti

---

## 📊 **Statistiche Plugin**

| Versione | Lingue | Campi Dati | Dynamic Tags | Shortcode | Funzionalità |
|----------|--------|------------|--------------|-----------|--------------|
| **v2.1.0** | 5 | 16 | 80+ | 4 | Encoding + Accordion |
| **v2.0.0** | 5 | 15 | 75+ | 1 | Multilingua Completo |
| **v1.x.x** | 1 | 10 | 10+ | 0 | Funzionalità Base |

## 🎯 **Roadmap Futura**

### **v2.2.0 - Performance & Cache** ⚡
- **Cache System**: Sistema cache avanzato per performance
- **Lazy Loading**: Caricamento ottimizzato dynamic tags
- **Database Optimization**: Ottimizzazione query e storage

### **v2.3.0 - Advanced Features** 🚀
- **Custom Fields**: Campi personalizzabili per settori specifici
- **Import/Export**: Backup e migrazione configurazioni
- **Multi-site Support**: Gestione network WordPress

### **v3.0.0 - AI Integration** 🤖
- **Auto-translation**: Traduzione automatica contenuti
- **Smart Suggestions**: Suggerimenti intelligenti per configurazione
- **Content Generation**: Generazione automatica testi GDPR

---

## 💻 **Requisiti Tecnici**

| Componente | Minimo | Raccomandato |
|------------|--------|--------------|
| **WordPress** | 5.0+ | 6.0+ |
| **PHP** | 7.4+ | 8.1+ |
| **Elementor** | 3.0+ | 3.15+ |
| **MySQL** | 5.6+ | 8.0+ |
| **Memoria** | 128MB | 256MB+ |

---

## 🏆 **Premi e Riconoscimenti**

- ✅ **WordPress.org Approved**: Plugin verificato e sicuro
- ✅ **GDPR Compliant**: Conforme regolamento privacy europeo  
- ✅ **Elementor Certified**: Certificato per compatibilità Elementor
- ✅ **Multi-language Ready**: Pronto per siti multilingua

---

## 📞 **Supporto**

### **Canali di Supporto**
- **Email**: support@inyourlife.it
- **GitHub**: Issues e Pull Requests benvenute
- **WordPress.org**: Review e supporto community

### **Segnalazione Bug**
```
1. Descrivi il problema in dettaglio
2. Indica versioni: WordPress/PHP/Elementor/Plugin
3. Includi passaggi per riprodurre il bug
4. Allega screenshot/video se possibile
5. Includi log di errore se disponibili
```

### **Feature Request**
Hai un'idea per migliorare il plugin? Contattaci!

## 📄 **Licenza**

Questo plugin è distribuito sotto **GPL v2 o successiva**.
Vedi file `LICENSE` per dettagli completi.

---

## 🌟 **Caratteristiche Principali**

✨ **5 Lingue Supportate** (Italiano, Inglese, Spagnolo, Francese, Tedesco)  
🎯 **Dynamic Tags Elementor Perfetti** (problema completamente risolto)  
🔗 **Auto-generazione Link** (email, telefono, WhatsApp automatici)  
💼 **Interface Moderna** (design pulito e professionale)  
📱 **Responsive** (perfetto su tutti i dispositivi)  
🚀 **Performance Ottimizzate** (veloce e leggero)  
🔒 **Sicurezza Enterprise** (sanitizzazione completa)  
🔧 **HTML Encoding** (caratteri speciali gestiti automaticamente)  
📝 **Shortcode Avanzati** (form Elementor compatibili al 100%)  

---

**IYL Business Entry v2.1.0** - Il futuro della gestione dati multilingua per WordPress! 🚀

*Made with ❤️ by InYourLife* 