jQuery(document).ready(function($) {
    'use strict';

    // Variabili globali
    let isLoading = false;
    let autoSaveTimeout = null;

    // Inizializzazione
    function init() {
        initTabs();
        initLanguageToggles();
        initFormValidation();
        initAutoLinks();
        initFieldEnhancements();
        initKeyboardShortcuts();
        initLoadingStates();
        initEncodingUpdate();
        initAccordion();
        showWelcomeMessage();
    }

    // Sistema di tab navigation
    function initTabs() {
        $('.tab-button').on('click', function(e) {
            e.preventDefault();
            
            if (isLoading) return;
            
            const targetTab = $(this).data('tab');
            
            // Animazione smooth per il cambio tab
            $('.tab-content.active').fadeOut(200, function() {
                $(this).removeClass('active');
                $('#tab-' + targetTab).fadeIn(300).addClass('active');
            });
            
            // Update navigation
            $('.tab-button').removeClass('active');
            $(this).addClass('active');
            
            // Store ultimo tab aperto
            localStorage.setItem('iyl_last_tab', targetTab);
        });
        
        // Ripristina ultimo tab aperto
        const lastTab = localStorage.getItem('iyl_last_tab');
        if (lastTab && $('.tab-button[data-tab="' + lastTab + '"]').length) {
            $('.tab-button[data-tab="' + lastTab + '"]').click();
        }
    }

    // Gestione language toggles
    function initLanguageToggles() {
        $('.language-checkbox').on('change', function(e) {
            e.preventDefault();
            
            const $checkbox = $(this);
            const $card = $checkbox.closest('.language-card');
            const langCode = $checkbox.val();
            const isActive = $checkbox.is(':checked');
            
            // Previeni disattivazione italiano
            if (langCode === 'it' && !isActive) {
                $checkbox.prop('checked', true);
                showToast(iylData.strings?.error || 'L\'italiano non può essere disattivato', 'error');
                return false;
            }
            
            // Stato loading
            $card.addClass('loading');
            setLoadingState(true);
            
            // AJAX request
            $.ajax({
                url: iylData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'toggle_language',
                    lang_code: langCode,
                    active: isActive,
                    nonce: iylData.nonce
                },
                timeout: 10000,
                success: function(response) {
                    if (response.success) {
                        showToast(response.data.message || 'Lingua aggiornata');
                        
                        // Update hidden field for form submission
                        updateActiveLanguagesField(response.data.active_languages);
                        
                        // Ricarica pagina dopo un delay per aggiornare i tab
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    } else {
                        handleAjaxError($checkbox, isActive, response.data || 'Errore sconosciuto');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    handleAjaxError($checkbox, isActive, 'Errore di connessione');
                },
                complete: function() {
                    $card.removeClass('loading');
                    setLoadingState(false);
                }
            });
        });
    }

    // Update hidden field with active languages
    function updateActiveLanguagesField(activeLanguages) {
        const $hiddenField = $('input[name="iyl_data_active_languages"]');
        if ($hiddenField.length && activeLanguages) {
            $hiddenField.val(activeLanguages.join(','));
        }
    }

    // Gestione errori AJAX
    function handleAjaxError($checkbox, originalState, message) {
        $checkbox.prop('checked', !originalState);
        showToast(message, 'error');
    }

    // Auto-generazione link intelligente
    function initAutoLinks() {
        // Email links con soggetto automatico
        $('input[name*="_email"]').not('input[name*="_link_"]').on('blur', function() {
            generateEmailLink($(this));
        });

        // Phone links con +39
        $('input[name*="_telefono"], input[name*="_cellulare"]').not('input[name*="_link_"]').on('blur', function() {
            generatePhoneLink($(this));
        });

        // WhatsApp links
        $('input[name*="_whatsapp"]').not('input[name*="_link_"]').on('blur', function() {
            generateWhatsAppLink($(this));
        });

        // Auto-update on related field changes
        $('input[name*="_dominio"], input[name*="_email_subject"]').on('blur', function() {
            const name = $(this).attr('name');
            const langMatch = name.match(/udet_(\w+)_/);
            if (langMatch) {
                const langCode = langMatch[1];
                const $emailField = $('input[name="udet_' + langCode + '_email"]');
                if ($emailField.length && $emailField.val()) {
                    generateEmailLink($emailField);
                }
            }
        });
    }

    // Generazione link email
    function generateEmailLink($emailField) {
        const emailValue = $emailField.val().trim();
        if (!emailValue) return;

        const langMatch = $emailField.attr('name').match(/udet_(\w+)_email/);
        if (!langMatch) return;

        const langCode = langMatch[1];
        
        // Prova a prendere l'email subject specifico per la lingua, altrimenti usa il fallback
        let subject = $('input[name="udet_' + langCode + '_email_subject"]').val();
        
        // Se non trova il campo, usa i subject predefiniti per lingua
        if (!subject) {
            const defaultSubjects = {
                'it': 'Nuova richiesta di contatto',
                'en': 'New contact request',
                'es': 'Nueva solicitud de contacto',
                'fr': 'Nouvelle demande de contact',
                'de': 'Neue Kontaktanfrage'
            };
            subject = defaultSubjects[langCode] || defaultSubjects['it'];
        }
        
        const dominio = $('input[name="udet_' + langCode + '_dominio"]').val() || '';
        
        const emailLink = 'mailto:' + emailValue + '?subject=' + encodeURIComponent(subject + ' ' + dominio);
        $('input[name="udet_' + langCode + '_link_email"]').val(emailLink);
        
        showToast('Link email generato', 'success');
    }

    // Generazione link telefono
    function generatePhoneLink($phoneField) {
        const phoneValue = $phoneField.val().trim();
        if (!phoneValue) return;

        const fieldMatch = $phoneField.attr('name').match(/udet_(\w+)_(telefono|cellulare)/);
        if (!fieldMatch) return;

        const langCode = fieldMatch[1];
        const fieldType = fieldMatch[2];
        
        let cleanPhone = phoneValue.replace(/[^\d+]/g, '');
        if (!cleanPhone.startsWith('+')) {
            cleanPhone = '+39' + cleanPhone.replace(/^39/, '');
        }
        
        const phoneLink = 'tel:' + cleanPhone;
        $('input[name="udet_' + langCode + '_link_' + fieldType + '"]').val(phoneLink);
        
        showToast('Link telefono generato', 'success');
    }

    // Generazione link WhatsApp
    function generateWhatsAppLink($whatsappField) {
        const whatsappValue = $whatsappField.val().trim();
        if (!whatsappValue) return;

        const langMatch = $whatsappField.attr('name').match(/udet_(\w+)_whatsapp/);
        if (!langMatch) return;

        const langCode = langMatch[1];
        
        let cleanWhatsApp = whatsappValue.replace(/[^\d+]/g, '');
        if (!cleanWhatsApp.startsWith('+')) {
            cleanWhatsApp = '+39' + cleanWhatsApp.replace(/^39/, '');
        }
        
        const whatsappLink = 'https://wa.me/' + cleanWhatsApp;
        $('input[name="udet_' + langCode + '_link_whatsapp"]').val(whatsappLink);
        
        showToast('Link WhatsApp generato', 'success');
    }

    // Validazione form migliorata
    function initFormValidation() {
        $('.iyl-data-form').on('submit', function(e) {
            if (isLoading) {
                e.preventDefault();
                return false;
            }

            // Ensure active languages are preserved
            updateActiveLanguagesFromCheckboxes();

            let hasErrors = false;
            
            // Reset errori precedenti
            $('.field-input').removeClass('error');
            $('.form-field').removeClass('error');
            
            // Validazione email
            $('input[type="email"]').each(function() {
                if (!validateEmail($(this))) {
                    hasErrors = true;
                }
            });
            
            // Validazione URL
            $('input[type="url"]').each(function() {
                if (!validateUrl($(this))) {
                    hasErrors = true;
                }
            });
            
            // Validazione campi richiesti (solo italiano)
            $('input[name*="udet_it_"]').filter('[name*="nome_sito"], [name*="email"]').each(function() {
                if (!$(this).val().trim()) {
                    $(this).addClass('error').closest('.form-field').addClass('error');
                    hasErrors = true;
                }
            });
            
            if (hasErrors) {
                e.preventDefault();
                showToast('Controlla i campi evidenziati in rosso', 'error');
                
                // Scroll al primo errore
                const $firstError = $('.field-input.error').first();
                if ($firstError.length) {
                    $firstError.focus();
                    $('html, body').animate({
                        scrollTop: $firstError.offset().top - 100
                    }, 500);
                }
                
                return false;
            }
            
            // Loading state durante submit
            setLoadingState(true);
            showToast(iylData.strings?.saving || 'Salvataggio in corso...', 'info');
        });
    }

    // Update hidden field from current checkbox states
    function updateActiveLanguagesFromCheckboxes() {
        const activeLanguages = [];
        $('.language-checkbox:checked').each(function() {
            activeLanguages.push($(this).val());
        });
        
        // Ensure Italian is always included
        if (!activeLanguages.includes('it')) {
            activeLanguages.push('it');
        }
        
        updateActiveLanguagesField(activeLanguages);
    }

    // Validatori
    function validateEmail($field) {
        const email = $field.val().trim();
        if (!email) return true; // Campo opzionale
        
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const isValid = regex.test(email);
        
        if (!isValid) {
            $field.addClass('error').closest('.form-field').addClass('error');
        }
        
        return isValid;
    }

    function validateUrl($field) {
        const url = $field.val().trim();
        if (!url) return true; // Campo opzionale
        
        try {
            new URL(url);
            return true;
        } catch {
            $field.addClass('error').closest('.form-field').addClass('error');
            return false;
        }
    }

    // Miglioramenti campo
    function initFieldEnhancements() {
        // Focus/blur animations
        $('.field-input').on('focus', function() {
            $(this).closest('.form-field').addClass('focused');
        }).on('blur', function() {
            $(this).closest('.form-field').removeClass('focused');
            
            // Rimuovi errori quando l'utente corregge
            if ($(this).hasClass('error') && $(this).val().trim()) {
                $(this).removeClass('error').closest('.form-field').removeClass('error');
            }
        });

        // Caratteri restanti per textarea
        $('.textarea-field .field-input').on('input', function() {
            updateCharacterCount($(this));
        });

        // Auto-resize textarea
        $('.textarea-field .field-input').on('input', function() {
            autoResizeTextarea($(this));
        });
    }

    function updateCharacterCount($textarea) {
        const maxLength = 2000;
        const currentLength = $textarea.val().length;
        const remaining = maxLength - currentLength;
        
        let $counter = $textarea.siblings('.char-counter');
        if (!$counter.length) {
            $counter = $('<div class="char-counter"></div>');
            $textarea.after($counter);
        }
        
        $counter.text(remaining + ' caratteri rimanenti')
                .toggleClass('warning', remaining < 100)
                .toggleClass('danger', remaining < 0);
    }

    function autoResizeTextarea($textarea) {
        $textarea.css('height', 'auto');
        const scrollHeight = $textarea[0].scrollHeight;
        $textarea.css('height', Math.min(scrollHeight, 300) + 'px');
    }

    // Scorciatoie tastiera
    function initKeyboardShortcuts() {
        $(document).on('keydown', function(e) {
            // Ctrl/Cmd + S = Salva
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                $('.iyl-data-form').submit();
                return false;
            }
            
            // Ctrl/Cmd + 1-4 = Cambia tab
            if ((e.ctrlKey || e.metaKey) && e.key >= '1' && e.key <= '4') {
                e.preventDefault();
                const tabIndex = parseInt(e.key) - 1;
                const $targetTab = $('.tab-button').eq(tabIndex);
                if ($targetTab.length) {
                    $targetTab.click();
                }
                return false;
            }

            // Esc = Chiudi toast
            if (e.key === 'Escape') {
                $('.iyl-toast').removeClass('show');
            }
        });
    }

    // Stati di loading
    function initLoadingStates() {
        // Gestisci loading durante AJAX
        $(document).ajaxStart(function() {
            setLoadingState(true);
        }).ajaxStop(function() {
            setLoadingState(false);
        });
    }

    function setLoadingState(loading) {
        isLoading = loading;
        $('body').toggleClass('iyl-loading', loading);
        $('.iyl-save-button').prop('disabled', loading);
        
        if (loading) {
            $('.iyl-save-button').html('<i class="fas fa-spinner fa-spin"></i> Salvataggio...');
        } else {
            $('.iyl-save-button').html('<i class="fas fa-save"></i> Salva Configurazione');
        }
    }

    // Sistema toast notifications
    function showToast(message, type = 'success', duration = 3000) {
        // Rimuovi toast esistenti
        $('.iyl-toast').removeClass('show');
        setTimeout(() => $('.iyl-toast').remove(), 300);
        
        const $toast = $(`
            <div class="iyl-toast ${type}">
                <i class="fas ${getToastIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `);
        
        $('body').append($toast);
        
        // Mostra toast
        setTimeout(() => $toast.addClass('show'), 100);
        
        // Nascondi toast automaticamente
        if (duration > 0) {
            setTimeout(() => {
                $toast.removeClass('show');
                setTimeout(() => $toast.remove(), 300);
            }, duration);
        }
        
        // Click per chiudere
        $toast.on('click', function() {
            $(this).removeClass('show');
            setTimeout(() => $(this).remove(), 300);
        });
    }

    function getToastIcon(type) {
        switch (type) {
            case 'success': return 'fa-check-circle';
            case 'error': return 'fa-exclamation-circle';
            case 'warning': return 'fa-exclamation-triangle';
            case 'info': return 'fa-info-circle';
            default: return 'fa-check-circle';
        }
    }

    // Messaggio di benvenuto
    function showWelcomeMessage() {
        if (localStorage.getItem('iyl_data_welcome') !== 'shown') {
            setTimeout(() => {
                showToast('👋 Benvenuto in IYL Data! Configura i tuoi dati multilingua.', 'info', 5000);
                localStorage.setItem('iyl_data_welcome', 'shown');
            }, 1000);
        }
    }

    // Auto-save (experimental)
    function initAutoSave() {
        $('.field-input').on('input', function() {
            clearTimeout(autoSaveTimeout);
            
            autoSaveTimeout = setTimeout(() => {
                if (!isLoading) {
                    // Implementa auto-save se necessario
                    console.log('Auto-save triggered');
                }
            }, 5000);
        });
    }

    // Gestione errori globali
    window.addEventListener('error', function(e) {
        console.error('JavaScript Error:', e);
        showToast('Si è verificato un errore. Ricarica la pagina.', 'error');
    });

    // Gestione notice WordPress
    function handleWordPressNotices() {
        // Nascondi notices dopo successo
        $('.notice-success').delay(3000).fadeOut();
        
        // Converti notices in toast
        $('.notice').each(function() {
            const $notice = $(this);
            const message = $notice.find('p').text();
            const type = $notice.hasClass('notice-error') ? 'error' : 
                        $notice.hasClass('notice-warning') ? 'warning' : 'success';
            
            if (message) {
                setTimeout(() => showToast(message, type), 500);
                $notice.fadeOut();
            }
        });
    }

    // Gestione aggiornamento encoding
    function initEncodingUpdate() {
        $('#update-encoding-btn').on('click', function() {
            const $button = $(this);
            const $status = $('#encoding-status');
            
            // Loading state
            $button.prop('disabled', true);
            $button.find('i').addClass('fa-spin');
            $status.html('<i class="fas fa-spinner fa-spin"></i> Aggiornamento in corso...');
            
            $.ajax({
                url: iylData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'iyl_update_encoding',
                    nonce: iylData.nonce
                },
                timeout: 30000,
                success: function(response) {
                    if (response.success) {
                        $status.html('<i class="fas fa-check-circle" style="color: #10b981;"></i> ' + response.data.message).css('color', '#10b981');
                        showToast(response.data.message, 'success');
                        
                        // Se sono stati aggiornati dei messaggi, suggerisci di ricaricare
                        if (response.data.count > 0) {
                            setTimeout(function() {
                                if (confirm('Alcuni messaggi sono stati aggiornati. Vuoi ricaricare la pagina per vedere le modifiche?')) {
                                    window.location.reload();
                                }
                            }, 2000);
                        }
                    } else {
                        $status.html('<i class="fas fa-exclamation-triangle" style="color: #ef4444;"></i> Errore: ' + (response.data || 'Errore sconosciuto')).css('color', '#ef4444');
                        showToast('Errore durante l\'aggiornamento dell\'encoding', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    $status.html('<i class="fas fa-exclamation-triangle" style="color: #ef4444;"></i> Errore di connessione').css('color', '#ef4444');
                    showToast('Errore di connessione durante l\'aggiornamento', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false);
                    $button.find('i').removeClass('fa-spin');
                }
            });
        });
    }

    // Gestione accordion
    function initAccordion() {
        $('.accordion-header').on('click', function() {
            const $header = $(this);
            const targetId = $header.data('target');
            const $content = $('#' + targetId);
            const $icon = $header.find('.accordion-icon');
            
            // Toggle current accordion
            if ($content.hasClass('active')) {
                // Chiudi accordion corrente
                $content.removeClass('active');
                $header.removeClass('active');
                $icon.removeClass('fa-chevron-up').addClass('fa-chevron-down');
            } else {
                // Chiudi tutti gli altri accordion (comportamento esclusivo)
                $('.accordion-content.active').removeClass('active');
                $('.accordion-header.active').removeClass('active');
                $('.accordion-header .accordion-icon').removeClass('fa-chevron-up').addClass('fa-chevron-down');
                
                // Apri accordion corrente
                $content.addClass('active');
                $header.addClass('active');
                $icon.removeClass('fa-chevron-down').addClass('fa-chevron-up');
            }
        });

        // Mostra un accordion aperto per default (opzionale)
        // Decommenta se vuoi che il primo accordion sia aperto di default
        // $('.accordion-header').first().trigger('click');
    }

    // Inizializza tutto
    init();
    
    // Gestisci notices WordPress dopo il caricamento
    setTimeout(handleWordPressNotices, 500);
    
    // Debug mode
    if (window.location.search.includes('debug=1')) {
        window.iylDebug = {
            showToast,
            setLoadingState,
            generateEmailLink,
            generatePhoneLink,
            generateWhatsAppLink
        };
        console.log('IYL Data Debug mode enabled');
    }
}); 