<?php
/**
 * Emergency Menu Fix for IYL Data Plugin
 * 
 * Se il menu "IYL Data" non appare, incolla questo codice 
 * temporaneamente in functions.php del tuo tema
 */

if (!defined('ABSPATH')) {
    exit;
}

// EMERGENCY MENU RECOVERY
add_action('admin_menu', 'iyl_emergency_menu_fix', 99);

function iyl_emergency_menu_fix() {
    // Solo se il menu originale non è stato registrato
    if (!menu_page_url('iyl-data-multilang', false)) {
        add_menu_page(
            'IYL Data EMERGENCY',
            'IYL Data EMERGENCY',
            'manage_options',
            'iyl-data-emergency',
            'iyl_emergency_page',
            'dashicons-admin-site-alt3',
            30
        );
    }
}

function iyl_emergency_page() {
    ?>
    <div class="wrap">
        <h1>🚨 IYL Data - Emergency Recovery</h1>
        
        <div style="background: #fff3cd; border: 1px solid #ffecb5; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3>⚠️ Menu di Emergency Attivo</h3>
            <p>Questo è un menu temporaneo per diagnosticare problemi con IYL Data.</p>
        </div>
        
        <?php
        echo '<h2>🔍 Diagnostica Plugin</h2>';
        
        // Test 1: Plugin attivo
        echo '<h3>1. Status Plugin</h3>';
        $plugin_file = 'iyl-business-entry/iyl-data-for-elementor.php';
        $is_active = is_plugin_active($plugin_file);
        echo '<p>Plugin attivo: ' . ($is_active ? '✅ SI' : '❌ NO') . '</p>';
        
        if (!$is_active) {
            echo '<p><strong>SOLUZIONE:</strong> <a href="' . admin_url('plugins.php') . '">Vai ai Plugin</a> e attiva "IYL Business Entry"</p>';
        }
        
        // Test 2: File esistono
        echo '<h3>2. Verifica File</h3>';
        $plugin_path = WP_PLUGIN_DIR . '/iyl-business-entry/';
        $files_check = [
            'iyl-data-for-elementor.php' => 'File principale',
            'includes/admin/class-iyl-data-multilang-admin.php' => 'Classe Admin',
            'assets/css/admin.css' => 'CSS Admin',
            'assets/js/admin.js' => 'JavaScript Admin'
        ];
        
        foreach ($files_check as $file => $desc) {
            $exists = file_exists($plugin_path . $file);
            echo '<p>' . $desc . ': ' . ($exists ? '✅ Esiste' : '❌ Mancante') . '</p>';
        }
        
        // Test 3: Costanti
        echo '<h3>3. Costanti Plugin</h3>';
        echo '<p>IYL_DATA_VERSION: ' . (defined('IYL_DATA_VERSION') ? IYL_DATA_VERSION : '❌ Non definita') . '</p>';
        echo '<p>IYL_DATA_PATH: ' . (defined('IYL_DATA_PATH') ? IYL_DATA_PATH : '❌ Non definita') . '</p>';
        
        // Test 4: Classi caricate
        echo '<h3>4. Classi Plugin</h3>';
        $classes = ['IYL_Data_Plugin', 'IYL_Data_Multilang_Admin'];
        foreach ($classes as $class) {
            echo '<p>' . $class . ': ' . (class_exists($class) ? '✅ Caricata' : '❌ Non caricata') . '</p>';
        }
        
        // Test 5: Funzioni helper
        echo '<h3>5. Funzioni Helper</h3>';
        $functions = ['iyl_get_data', 'iyl_get_email_link', 'iyl_get_phone_link'];
        foreach ($functions as $function) {
            echo '<p>' . $function . ': ' . (function_exists($function) ? '✅ Disponibile' : '❌ Non disponibile') . '</p>';
        }
        
        // Test 6: Opzioni database
        echo '<h3>6. Opzioni Database</h3>';
        $active_languages = get_option('iyl_data_active_languages', []);
        echo '<p>Lingue attive: ' . (empty($active_languages) ? '❌ Nessuna' : '✅ ' . implode(', ', $active_languages)) . '</p>';
        
        // Azioni di recupero
        echo '<h2>🔧 Azioni di Recupero</h2>';
        
        if (isset($_POST['force_reactivate'])) {
            deactivate_plugins($plugin_file);
            activate_plugin($plugin_file);
            echo '<div class="notice notice-success"><p>✅ Plugin riattivato!</p></div>';
            echo '<script>setTimeout(function(){ window.location.reload(); }, 2000);</script>';
        }
        
        if (isset($_POST['reset_options'])) {
            update_option('iyl_data_active_languages', ['it']);
            echo '<div class="notice notice-success"><p>✅ Opzioni ripristinate!</p></div>';
        }
        
        ?>
        
        <form method="post" style="margin: 20px 0;">
            <input type="submit" name="force_reactivate" class="button button-primary" value="🔄 Forza Riattivazione Plugin">
            <input type="submit" name="reset_options" class="button button-secondary" value="⚙️ Reset Opzioni Database">
        </form>
        
        <div style="background: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3>💡 Soluzioni Comuni</h3>
            <ol>
                <li><strong>Riattiva il plugin:</strong> Vai su Plugin → Disattiva → Attiva "IYL Business Entry"</li>
                <li><strong>Controlla i permessi:</strong> chmod -R 755 /wp-content/plugins/iyl-business-entry/</li>
                <li><strong>Svuota la cache:</strong> Se usi plugin di cache, svuotala</li>
                <li><strong>Controlla i log:</strong> Guarda wp-content/debug.log per errori PHP</li>
                <li><strong>Conflitti plugin:</strong> Disattiva temporaneamente altri plugin</li>
            </ol>
        </div>
        
        <div style="background: #fff3cd; border: 1px solid #ffecb5; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3>⚠️ IMPORTANTE</h3>
            <p><strong>Rimuovi questo codice da functions.php dopo aver risolto il problema!</strong></p>
            <p>Questo è solo un tool di emergenza per la diagnosi.</p>
        </div>
        
        <?php if ($is_active && class_exists('IYL_Data_Plugin')): ?>
            <div style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3>🎉 Plugin Sembra Funzionare!</h3>
                <p>Il plugin è attivo e le classi sono caricate. Il menu dovrebbe apparire presto.</p>
                <p><a href="<?php echo admin_url('admin.php?page=iyl-data-multilang'); ?>" class="button button-primary">🔗 Prova ad andare alla pagina IYL Data</a></p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

// Forza il caricamento del plugin se non è stato caricato
if (defined('IYL_DATA_PATH') && !class_exists('IYL_Data_Plugin')) {
    require_once IYL_DATA_PATH . 'iyl-data-for-elementor.php';
}
?> 