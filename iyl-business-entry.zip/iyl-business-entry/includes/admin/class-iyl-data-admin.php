<?php

if (!defined('ABSPATH')) {
    exit;
}

class IYL_Data_Admin {
    private $options_group = 'iyl_data_options';
    private $options_page = 'iyl-data-settings';

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        
        // Carica la classe per i social media
        require_once IYL_DATA_PATH . 'includes/admin/class-iyl-data-social.php';
    }

    public function add_admin_menu() {
        add_options_page(
            __('IYL Data Settings', 'iyl-data'),
            __('IYL Data', 'iyl-data'),
            'manage_options',
            $this->options_page,
            [$this, 'render_settings_page']
        );
    }

    public function register_settings() {
        // Registra le impostazioni base
        register_setting($this->options_group, 'iyl_data_nome_sito');
        register_setting($this->options_group, 'iyl_data_dominio_sito');
        register_setting($this->options_group, 'iyl_data_indirizzo');
        register_setting($this->options_group, 'iyl_data_indirizzo_link');
        register_setting($this->options_group, 'iyl_data_iframe_mappa');
        register_setting($this->options_group, 'iyl_data_email_contatto');
        register_setting($this->options_group, 'iyl_data_numero_di_telefono', [
            'sanitize_callback' => [$this, 'sanitize_phone_display']
        ]);
        register_setting($this->options_group, 'iyl_data_telefono_link', [
            'sanitize_callback' => [$this, 'sanitize_phone_link']
        ]);
        register_setting($this->options_group, 'iyl_data_whatsapp', [
            'sanitize_callback' => [$this, 'sanitize_phone_display']
        ]);
        register_setting($this->options_group, 'iyl_data_whatsapp_link', [
            'sanitize_callback' => [$this, 'sanitize_phone_link']
        ]);
        register_setting($this->options_group, 'iyl_data_codice_fiscale_piva');
        register_setting($this->options_group, 'iyl_data_is_hospitality', [
            'type' => 'boolean',
            'default' => false
        ]);
        register_setting($this->options_group, 'iyl_data_cin');

        // Registra le impostazioni per i social media
        IYL_Data_Social::register_settings();

        // Sezione informazioni principali
        add_settings_section(
            'iyl_data_main_section',
            __('Business Information', 'iyl-data'),
            [$this, 'section_description'],
            $this->options_page
        );

        // Registra i campi principali
        $this->add_settings_fields();

        // Aggiungi la sezione social media
        IYL_Data_Social::add_settings_section($this->options_page);
    }

    public function sanitize_phone_display($input) {
        // Permette spazi, parentesi e trattini per la visualizzazione
        return preg_replace('/[^0-9\s()\-+]/', '', $input);
    }

    public function sanitize_phone_link($input) {
        // Permette solo numeri e il segno + per il link
        return preg_replace('/[^0-9+]/', '', $input);
    }

    public function section_description() {
        echo '<p>' . __('Enter your business information below. These fields will be available as dynamic tags in Elementor.', 'iyl-data') . '</p>';
    }

    private function add_settings_fields() {
        $fields = [
            'nome_sito' => [
                'label' => __('Site Name', 'iyl-data'),
                'type' => 'text'
            ],
            'dominio_sito' => [
                'label' => __('Domain', 'iyl-data'),
                'type' => 'text'
            ],
            'indirizzo' => [
                'label' => __('Address', 'iyl-data'),
                'type' => 'text'
            ],
            'indirizzo_link' => [
                'label' => __('Address Link', 'iyl-data'),
                'type' => 'url'
            ],
            'iframe_mappa' => [
                'label' => __('Map iFrame', 'iyl-data'),
                'type' => 'textarea'
            ],
            'email_contatto' => [
                'label' => __('Contact Email', 'iyl-data'),
                'type' => 'email'
            ],
            'numero_di_telefono' => [
                'label' => __('Phone Number (Display)', 'iyl-data'),
                'type' => 'text',
                'description' => __('Enter the phone number as you want it to be displayed (e.g., +39 123 456 7890)', 'iyl-data')
            ],
            'telefono_link' => [
                'label' => __('Phone Number (Link)', 'iyl-data'),
                'type' => 'text',
                'description' => __('Enter only numbers and + symbol (e.g., +391234567890)', 'iyl-data')
            ],
            'whatsapp' => [
                'label' => __('WhatsApp Number (Display)', 'iyl-data'),
                'type' => 'text',
                'description' => __('Enter the WhatsApp number as you want it to be displayed', 'iyl-data')
            ],
            'whatsapp_link' => [
                'label' => __('WhatsApp Number (Link)', 'iyl-data'),
                'type' => 'text',
                'description' => __('Enter only numbers and + symbol (e.g., +391234567890)', 'iyl-data')
            ],
            'codice_fiscale_piva' => [
                'label' => __('Codice Fiscale / Partita IVA', 'iyl-data'),
                'type' => 'text',
                'description' => __('Enter your Codice Fiscale or Partita IVA', 'iyl-data')
            ],
            'is_hospitality' => [
                'label' => __('Is Hospitality Structure', 'iyl-data'),
                'type' => 'checkbox',
                'description' => __('Check if this is a hospitality structure', 'iyl-data')
            ],
            'cin' => [
                'label' => __('CIN', 'iyl-data'),
                'type' => 'text',
                'description' => __('Enter the CIN (Codice Identificativo Nazionale) for hospitality structures', 'iyl-data')
            ],
        ];

        foreach ($fields as $field_id => $field) {
            $args = [
                'field_id' => $field_id,
                'type' => $field['type']
            ];

            if (isset($field['description'])) {
                $args['description'] = $field['description'];
            }

            add_settings_field(
                "iyl_data_{$field_id}",
                $field['label'],
                [$this, 'render_field'],
                $this->options_page,
                'iyl_data_main_section',
                $args
            );
        }
    }

    public function render_field($args) {
        $field_id = $args['field_id'];
        $type = $args['type'];
        $option_name = "iyl_data_{$field_id}";
        $value = get_option($option_name);

        switch ($type) {
            case 'textarea':
                printf(
                    '<textarea class="large-text code" id="%s" name="%s" rows="5">%s</textarea>',
                    esc_attr($option_name),
                    esc_attr($option_name),
                    esc_textarea($value)
                );
                break;
            
            case 'checkbox':
                printf(
                    '<input type="checkbox" id="%s" name="%s" value="1" %s />',
                    esc_attr($option_name),
                    esc_attr($option_name),
                    checked(1, $value, false)
                );
                break;
            
            default:
                printf(
                    '<input type="%s" class="regular-text" id="%s" name="%s" value="%s" />',
                    esc_attr($type),
                    esc_attr($option_name),
                    esc_attr($option_name),
                    esc_attr($value)
                );
                break;
        }

        if (isset($args['description'])) {
            printf('<p class="description">%s</p>', esc_html($args['description']));
        }
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields($this->options_group);
                do_settings_sections($this->options_page);
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
} 