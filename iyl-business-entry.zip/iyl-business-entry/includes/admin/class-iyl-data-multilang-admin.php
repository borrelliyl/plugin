<?php

if (!defined('ABSPATH')) {
    exit;
}

class IYL_Data_Multilang_Admin {
    private $options_group = 'iyl_data_multilang_options';
    private $options_page = 'iyl-data-multilang';

    // Definizione delle lingue supportate
    private $languages = [
        'it' => ['name' => 'Italiano', 'flag' => '🇮🇹'],
        'en' => ['name' => 'Inglese', 'flag' => '🇬🇧'],
        'es' => ['name' => 'Spagnolo', 'flag' => '🇪🇸'],
        'fr' => ['name' => 'Francese', 'flag' => '🇫🇷'],
        'de' => ['name' => 'Tedesco', 'flag' => '🇩🇪']
    ];

    // Definizione dei campi dati
    private $data_fields = [
        'nome_sito' => 'Nome Sito',
        'anno_creazione' => 'Anno di Creazione Sito',
        'dominio' => 'Dominio',
        'indirizzo' => 'Indirizzo',
        'link_indirizzo' => 'Link Indirizzo',
        'iframe_mappa' => 'Iframe Mappa',
        'email' => 'Email',
        'link_email' => 'Link Email',
        'telefono' => 'Telefono',
        'link_telefono' => 'Link Telefono',
        'cellulare' => 'Cellulare',
        'link_cellulare' => 'Link Cellulare',
        'whatsapp' => 'WhatsApp',
        'link_whatsapp' => 'Link WhatsApp',
        'piva' => 'P.IVA',
        'privacy_policy_link' => 'Link Privacy Policy'
    ];

    // Definizione dei campi form Elementor
    private $form_fields = [
        'form_success_message' => 'Messaggio inviato con successo',
        'form_error_message' => 'Errore del form',
        'form_server_error' => 'Errore del Server',
        'form_invalid' => 'Form Invalido',
        'form_privacy_message' => 'Accettazione Privacy'
    ];

    // Definizione dei social networks
    private $social_networks = [
        'facebook' => ['name' => 'Facebook', 'icon' => 'fab fa-facebook', 'base_url' => 'https://facebook.com/'],
        'instagram' => ['name' => 'Instagram', 'icon' => 'fab fa-instagram', 'base_url' => 'https://instagram.com/'],
        'linkedin' => ['name' => 'LinkedIn', 'icon' => 'fab fa-linkedin', 'base_url' => 'https://linkedin.com/company/'],
        'twitter' => ['name' => 'Twitter/X', 'icon' => 'fab fa-x-twitter', 'base_url' => 'https://twitter.com/'],
        'pinterest' => ['name' => 'Pinterest', 'icon' => 'fab fa-pinterest', 'base_url' => 'https://pinterest.com/'],
    ];

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_toggle_language', [$this, 'ajax_toggle_language']);
        add_action('admin_notices', [$this, 'admin_notices']);
        add_action('wp_ajax_iyl_update_encoding', [$this, 'ajax_update_encoding']);
        
        // Registra gli shortcode per i form
        add_action('init', [$this, 'register_form_shortcodes']);
    }

    public function add_admin_menu() {
        add_menu_page(
            __('IYL Data', 'iyl-data'),
            __('IYL Data', 'iyl-data'),
            'manage_options',
            $this->options_page,
            [$this, 'render_settings_page'],
            'dashicons-admin-site-alt3',
            30
        );
    }

    public function enqueue_admin_scripts($hook) {
        // Verifica che siamo nella pagina corretta
        if (strpos($hook, $this->options_page) === false) {
            return;
        }

        // Enqueue Font Awesome
        wp_enqueue_style(
            'font-awesome',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
            [],
            '6.5.1'
        );

        // Enqueue admin CSS
        wp_enqueue_style(
            'iyl-data-admin',
            IYL_DATA_URL . 'assets/css/admin.css',
            ['font-awesome'],
            IYL_DATA_VERSION
        );

        // Enqueue admin JS
        wp_enqueue_script(
            'iyl-data-admin',
            IYL_DATA_URL . 'assets/js/admin.js',
            ['jquery'],
            IYL_DATA_VERSION,
            true
        );

        // Localize script per AJAX
        wp_localize_script('iyl-data-admin', 'iylData', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('iyl_data_nonce'),
            'strings' => [
                'saving' => __('Salvataggio in corso...', 'iyl-data'),
                'saved' => __('Configurazione salvata!', 'iyl-data'),
                'error' => __('Errore durante il salvataggio', 'iyl-data')
            ]
        ]);
    }

    public function register_settings() {
        // Registra le lingue attive
        register_setting(
            $this->options_group,
            'iyl_data_active_languages',
            [
                'type' => 'array',
                'default' => ['it'],
                'sanitize_callback' => [$this, 'sanitize_active_languages']
            ]
        );

        // Registra tutti i campi per ogni lingua
        foreach ($this->languages as $lang_code => $lang_data) {
            foreach ($this->data_fields as $field_key => $field_title) {
                register_setting(
                    $this->options_group,
                    "udet_{$lang_code}_{$field_key}",
                    [
                        'type' => 'string',
                        'sanitize_callback' => [$this, 'sanitize_field_value']
                    ]
                );
            }

            // Registra i social per ogni lingua
            foreach ($this->social_networks as $social_key => $social_data) {
                register_setting(
                    $this->options_group,
                    "udet_{$lang_code}_social_{$social_key}",
                    [
                        'type' => 'string',
                        'sanitize_callback' => 'sanitize_text_field'
                    ]
                );
            }

            // Registra i campi form Elementor per ogni lingua
            foreach ($this->form_fields as $field_key => $field_title) {
                register_setting(
                    $this->options_group,
                    "udet_{$lang_code}_{$field_key}",
                    [
                        'type' => 'string',
                        'default' => $this->get_default_form_message($lang_code, $field_key),
                        'sanitize_callback' => [$this, 'sanitize_form_field']
                    ]
                );
            }

            // Registra email subject per ogni lingua (per generazione automatica link)
            register_setting(
                $this->options_group,
                "udet_{$lang_code}_email_subject",
                [
                    'type' => 'string',
                    'default' => $this->get_default_email_subject($lang_code),
                    'sanitize_callback' => 'sanitize_text_field'
                ]
            );
        }
    }

    public function sanitize_field_value($value) {
        if (empty($value)) {
            return '';
        }
        
        // Per textarea (iframe_mappa) mantieni HTML
        if (strpos($value, '<iframe') !== false) {
            return wp_kses($value, [
                'iframe' => [
                    'src' => true,
                    'width' => true,
                    'height' => true,
                    'frameborder' => true,
                    'allowfullscreen' => true,
                    'style' => true,
                    'class' => true
                ]
            ]);
        }
        
        return sanitize_text_field($value);
    }

    public function sanitize_active_languages($languages) {
        // Handle both array and comma-separated string formats
        if (is_string($languages)) {
            $languages = explode(',', $languages);
        }
        
        if (!is_array($languages)) {
            return ['it'];
        }
        
        // Clean and validate languages
        $languages = array_map('trim', $languages);
        $valid_languages = array_keys($this->languages);
        $sanitized = array_filter($languages, function($lang) use ($valid_languages) {
            return in_array($lang, $valid_languages);
        });
        
        // Assicurati che l'italiano sia sempre presente
        if (!in_array('it', $sanitized)) {
            $sanitized[] = 'it';
        }
        
        return array_values($sanitized);
    }

    public function admin_notices() {
        // Mostra notice dopo il salvataggio
        if (isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true') {
            echo '<div class="notice notice-success is-dismissible"><p>' . 
                 __('Configurazione IYL Data salvata con successo!', 'iyl-data') . 
                 '</p></div>';
        }
    }

    public function ajax_toggle_language() {
        check_ajax_referer('iyl_data_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }

        $lang_code = sanitize_text_field($_POST['lang_code'] ?? '');
        $active = ($_POST['active'] ?? 'false') === 'true';
        
        if (empty($lang_code) || !isset($this->languages[$lang_code])) {
            wp_send_json_error('Lingua non valida');
        }
        
        $active_languages = get_option('iyl_data_active_languages', ['it']);
        
        if ($active && !in_array($lang_code, $active_languages)) {
            $active_languages[] = $lang_code;
        } elseif (!$active && in_array($lang_code, $active_languages)) {
            $active_languages = array_diff($active_languages, [$lang_code]);
        }

        // Assicurati che almeno l'italiano rimanga attivo
        if (empty($active_languages) || !in_array('it', $active_languages)) {
            $active_languages[] = 'it';
        }

        update_option('iyl_data_active_languages', array_values($active_languages));
        
        wp_send_json_success([
            'active_languages' => array_values($active_languages),
            'message' => __('Lingua aggiornata con successo', 'iyl-data')
        ]);
    }

    public function ajax_update_encoding() {
        check_ajax_referer('iyl_data_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permessi insufficienti');
        }
        
        $updated_count = $this->update_form_messages_encoding();
        
        wp_send_json_success([
            'message' => sprintf('Aggiornati %d messaggi con il nuovo encoding HTML', $updated_count),
            'count' => $updated_count
        ]);
    }

    /**
     * Aggiorna l'encoding dei messaggi del form esistenti
     */
    private function update_form_messages_encoding() {
        $languages = ['it', 'en', 'es', 'fr', 'de'];
        $form_fields = ['form_success_message', 'form_error_message', 'form_server_error', 'form_invalid', 'form_privacy_message'];
        $updated_count = 0;
        
        $special_chars = [
            'à' => '&agrave;', 'á' => '&aacute;', 'è' => '&egrave;', 'é' => '&eacute;',
            'ì' => '&igrave;', 'í' => '&iacute;', 'ò' => '&ograve;', 'ó' => '&oacute;',
            'ù' => '&ugrave;', 'ú' => '&uacute;', 'ç' => '&ccedil;', 'ñ' => '&ntilde;',
            'ü' => '&uuml;', 'ä' => '&auml;', 'ö' => '&ouml;', 'ß' => '&szlig;',
            'À' => '&Agrave;', 'Á' => '&Aacute;', 'È' => '&Egrave;', 'É' => '&Eacute;',
            'Ì' => '&Igrave;', 'Í' => '&Iacute;', 'Ò' => '&Ograve;', 'Ó' => '&Oacute;',
            'Ù' => '&Ugrave;', 'Ú' => '&Uacute;', 'Ç' => '&Ccedil;', 'Ñ' => '&Ntilde;',
            'Ü' => '&Uuml;', 'Ä' => '&Auml;', 'Ö' => '&Ouml;'
        ];
        
        foreach ($languages as $lang_code) {
            foreach ($form_fields as $field_key) {
                $option_name = "udet_{$lang_code}_{$field_key}";
                $current_value = get_option($option_name, '');
                
                if (!empty($current_value)) {
                    // Controlla se il valore contiene già entità HTML
                    if (strpos($current_value, '&') === false) {
                        // Converti solo se non contiene già entità
                        $updated_value = str_replace(array_keys($special_chars), array_values($special_chars), $current_value);
                        
                        if ($updated_value !== $current_value) {
                            update_option($option_name, $updated_value);
                            $updated_count++;
                        }
                    }
                }
            }
        }
        
        return $updated_count;
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Non hai i permessi sufficienti per accedere a questa pagina.'));
        }

        $active_languages = get_option('iyl_data_active_languages', ['it']);
        
        // Assicurati che ci sia almeno l'italiano
        if (empty($active_languages) || !in_array('it', $active_languages)) {
            $active_languages = ['it'];
            update_option('iyl_data_active_languages', $active_languages);
        }
        ?>
        
        <div class="wrap iyl-data-admin-wrap">
            <div class="iyl-data-header">
                <h1 class="iyl-data-title">
                    <i class="fas fa-globe"></i>
                    <?php _e('IYL Data - Configurazione Multilingua', 'iyl-data'); ?>
                </h1>
                <p class="iyl-data-subtitle">
                    <?php _e('Gestisci i tuoi dati aziendali in più lingue con facilità', 'iyl-data'); ?>
                </p>
            </div>
            
            <!-- Specchietto informativo per lo shortcode -->
            <div class="iyl-accordion">
                <div class="accordion-header" data-target="copyright-info">
                    <h3><i class="fas fa-info-circle"></i> 📝 Importante: Copyright Dinamico</h3>
                    <i class="fas fa-chevron-down accordion-icon"></i>
                </div>
                <div class="accordion-content" id="copyright-info">
                    <p><strong>Ricorda:</strong> Nel footer del tuo sito inserisci lo shortcode <code>[dynamic_year]</code> per visualizzare la data dinamica con il copyright che si traduce automaticamente in tutte le lingue supportate.</p>
                    <p><strong>Output esempio:</strong> Nome Sito - Copyright © 2024 - 2025 - Tutti i diritti riservati. Siti Internet by InYourLife</p>
                    <p><em>Imposta l'anno di creazione nel campo qui sotto per personalizzare il copyright.</em></p>
                </div>
            </div>

            <!-- Info box per encoding HTML -->
            <div class="iyl-accordion">
                <div class="accordion-header" data-target="encoding-info">
                    <h3><i class="fas fa-code"></i> 🔧 Encoding HTML per Caratteri Speciali</h3>
                    <i class="fas fa-chevron-down accordion-icon"></i>
                </div>
                <div class="accordion-content" id="encoding-info">
                    <p><strong>Novità:</strong> I caratteri speciali (à, è, ì, ò, ù, ecc.) vengono ora automaticamente convertiti in entità HTML per garantire la corretta visualizzazione in Elementor.</p>
                    <p><strong>Cosa significa?</strong> I messaggi del form saranno sempre visualizzati correttamente, senza errori di encoding nei browser.</p>
                    <button type="button" id="update-encoding-btn" class="button button-secondary">
                        <i class="fas fa-sync-alt"></i> Aggiorna Encoding Messaggi Esistenti
                    </button>
                    <span id="encoding-status" style="margin-left: 10px; font-weight: bold;"></span>
                </div>
            </div>

            <!-- Info box per gli shortcode -->
            <div class="iyl-accordion">
                <div class="accordion-header" data-target="shortcode-info">
                    <h3><i class="fas fa-brackets-curly"></i> 📝 Shortcode per Form Elementor</h3>
                    <i class="fas fa-chevron-down accordion-icon"></i>
                </div>
                <div class="accordion-content" id="shortcode-info">
                    <p><strong>Problema risolto:</strong> I campi di testo nei form di Elementor non supportano i Dynamic Tags. Ora puoi usare questi shortcode!</p>
                    
                    <div style="margin: 15px 0;">
                        <h4 style="margin: 10px 0 5px 0; color: #10b981;">🔒 Per l'accettazione Privacy/GDPR:</h4>
                        <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; color: #1e40af;">[iyl_privacy_text]</code>
                        <p style="margin: 5px 0; font-size: 13px; color: #64748b;">Usa questo shortcode nel campo di testo dell'accettazione privacy nei form di Elementor</p>
                    </div>
                    
                    <div style="margin: 15px 0;">
                        <h4 style="margin: 10px 0 5px 0; color: #10b981;">💬 Per i messaggi del form:</h4>
                        <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; color: #1e40af;">[iyl_form_message type="success"]</code><br>
                        <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; color: #1e40af;">[iyl_form_message type="error"]</code><br>
                        <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; color: #1e40af;">[iyl_form_message type="server_error"]</code><br>
                        <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; color: #1e40af;">[iyl_form_message type="invalid"]</code>
                    </div>
                    
                    <div style="margin: 15px 0;">
                        <h4 style="margin: 10px 0 5px 0; color: #10b981;">🌐 Con lingua specifica:</h4>
                        <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; color: #1e40af;">[iyl_privacy_text lang="en"]</code><br>
                        <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; color: #1e40af;">[iyl_form_message type="success" lang="fr"]</code>
                        <p style="margin: 5px 0; font-size: 13px; color: #64748b;">Gli shortcode rilevano automaticamente la lingua corrente (Polylang/WPML)</p>
                    </div>
                    
                    <div style="background: #fef3c7; border: 1px solid #f59e0b; border-radius: 6px; padding: 10px; margin-top: 15px;">
                        <p style="margin: 0; font-size: 13px;"><strong>💡 Come usare:</strong> Copia e incolla questi shortcode nei campi di testo dei tuoi form di Elementor al posto dei Dynamic Tags non supportati.</p>
                    </div>
                </div>
            </div>
            
            <div class="iyl-data-content">
                <!-- Language Toggle Section -->
                <div class="iyl-language-section">
                    <div class="section-header">
                        <h2><i class="fas fa-language"></i> <?php _e('Lingue Attive', 'iyl-data'); ?></h2>
                        <p><?php _e('Seleziona le lingue che vuoi utilizzare per il tuo sito', 'iyl-data'); ?></p>
                    </div>
                    
                    <div class="language-toggle-grid">
                        <?php foreach ($this->languages as $lang_code => $lang_data): ?>
                            <div class="language-card" data-lang="<?php echo esc_attr($lang_code); ?>">
                                <input type="checkbox" 
                                       id="lang_<?php echo esc_attr($lang_code); ?>" 
                                       value="<?php echo esc_attr($lang_code); ?>"
                                       <?php checked(in_array($lang_code, $active_languages)); ?>
                                       <?php disabled($lang_code === 'it'); ?>
                                       class="language-checkbox">
                                <label for="lang_<?php echo esc_attr($lang_code); ?>" class="language-label">
                                    <div class="language-info">
                                        <span class="language-flag"><?php echo $lang_data['flag']; ?></span>
                                        <span class="language-name"><?php echo esc_html($lang_data['name']); ?></span>
                                    </div>
                                    <?php if ($lang_code === 'it'): ?>
                                        <span class="language-badge"><?php _e('Predefinito', 'iyl-data'); ?></span>
                                    <?php endif; ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Tabs Section -->
                <div class="iyl-tabs-section">
                    <div class="tabs-nav">
                        <?php foreach ($active_languages as $index => $lang_code): ?>
                            <?php if (isset($this->languages[$lang_code])): ?>
                                <button class="tab-button <?php echo $index === 0 ? 'active' : ''; ?>" 
                                        data-tab="<?php echo esc_attr($lang_code); ?>">
                                    <span class="tab-flag"><?php echo $this->languages[$lang_code]['flag']; ?></span>
                                    <span class="tab-name"><?php echo esc_html($this->languages[$lang_code]['name']); ?></span>
                                </button>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>

                    <form method="post" action="options.php" class="iyl-data-form">
                        <?php 
                        settings_fields($this->options_group);
                        wp_nonce_field('iyl_data_save', 'iyl_data_nonce_field');
                        
                        // IMPORTANT: Include active languages in form to preserve them
                        echo '<input type="hidden" name="iyl_data_active_languages" value="' . esc_attr(implode(',', $active_languages)) . '">';
                        ?>
                        
                        <!-- Tab Content -->
                        <?php foreach ($active_languages as $index => $lang_code): ?>
                            <?php if (isset($this->languages[$lang_code])): ?>
                                <div class="tab-content <?php echo $index === 0 ? 'active' : ''; ?>" 
                                     id="tab-<?php echo esc_attr($lang_code); ?>">
                                    
                                    <div class="form-section">
                                        <div class="section-header">
                                            <h3><i class="fas fa-info-circle"></i> <?php _e('Informazioni Generali', 'iyl-data'); ?></h3>
                                        </div>
                                        <div class="form-grid">
                                            <?php $this->render_data_fields($lang_code); ?>
                                        </div>
                                    </div>

                                    <div class="form-section">
                                        <div class="section-header">
                                            <h3><i class="fas fa-share-alt"></i> <?php _e('Social Networks', 'iyl-data'); ?></h3>
                                        </div>
                                        <div class="form-grid">
                                            <?php $this->render_social_fields($lang_code); ?>
                                        </div>
                                    </div>

                                    <div class="form-section">
                                        <div class="section-header">
                                            <h3><i class="fas fa-list-ul"></i> <?php _e('Impostazioni Form', 'iyl-data'); ?></h3>
                                        </div>
                                        <div class="form-grid">
                                            <?php $this->render_form_settings($lang_code); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        
                        <div class="submit-section">
                            <button type="submit" class="iyl-save-button">
                                <i class="fas fa-save"></i>
                                <?php _e('Salva Configurazione', 'iyl-data'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    private function render_data_fields($lang_code) {
        foreach ($this->data_fields as $field_key => $field_title) {
            $option_name = "udet_{$lang_code}_{$field_key}";
            $value = get_option($option_name, '');
            
            $field_type = 'text';
            $field_class = 'form-field';
            
            if ($field_key === 'iframe_mappa') {
                $field_type = 'textarea';
                $field_class .= ' textarea-field';
            } elseif (strpos($field_key, 'link_') === 0) {
                $field_type = 'url';
                $field_class .= ' url-field';
            } elseif ($field_key === 'email') {
                $field_type = 'email';
                $field_class .= ' email-field';
            } elseif ($field_key === 'anno_creazione') {
                $field_type = 'number';
                $field_class .= ' year-field important-field';
            }

            echo '<div class="' . esc_attr($field_class) . '">';
            printf('<label for="%s" class="field-label">%s</label>', 
                   esc_attr($option_name), 
                   esc_html($field_title));
            
            if ($field_type === 'textarea') {
                printf(
                    '<textarea id="%s" name="%s" rows="4" class="field-input" placeholder="%s">%s</textarea>',
                    esc_attr($option_name),
                    esc_attr($option_name),
                    esc_attr__('Inserisci il codice iframe della mappa...', 'iyl-data'),
                    esc_textarea($value)
                );
            } else {
                $placeholder = '';
                switch ($field_key) {
                    case 'nome_sito':
                        $placeholder = __('Es: La Mia Azienda', 'iyl-data');
                        break;
                    case 'dominio':
                        $placeholder = __('Es: https://www.example.com', 'iyl-data');
                        break;
                    case 'anno_creazione':
                        $placeholder = __('Es: 2025', 'iyl-data');
                        break;
                    case 'email':
                        $placeholder = __('Es: info@example.com', 'iyl-data');
                        break;
                    case 'telefono':
                    case 'cellulare':
                        $placeholder = __('Es: 123 456 7890', 'iyl-data');
                        break;
                    case 'whatsapp':
                        $placeholder = __('Es: 123 456 7890', 'iyl-data');
                        break;
                }
                
                // Attributi speciali per il campo anno
                $extra_attrs = '';
                if ($field_key === 'anno_creazione') {
                    $current_year = date('Y');
                    $extra_attrs = ' min="1990" max="' . $current_year . '"';
                }
                
                printf(
                    '<input type="%s" id="%s" name="%s" value="%s" class="field-input" placeholder="%s"%s>',
                    esc_attr($field_type),
                    esc_attr($option_name),
                    esc_attr($option_name),
                    esc_attr($value),
                    esc_attr($placeholder),
                    $extra_attrs
                );
            }
            
            // Aggiungi descrizioni specifiche
            $description = '';
            switch ($field_key) {
                case 'telefono':
                case 'cellulare':
                    $description = __('Il numero verrà automaticamente formattato con +39', 'iyl-data');
                    break;
                case 'whatsapp':
                    $description = __('Il link WhatsApp verrà generato automaticamente', 'iyl-data');
                    break;
                case 'email':
                    $description = __('Il link email includerà automaticamente il subject personalizzato', 'iyl-data');
                    break;
                case 'dominio':
                    $description = __('URL completo del sito (incluso https://)', 'iyl-data');
                    break;
                case 'anno_creazione':
                    $description = __('Anno di creazione del sito. Usato nello shortcode [dynamic_year] per il copyright', 'iyl-data');
                    break;
            }
            
            if (!empty($description)) {
                printf('<p class="field-description">%s</p>', esc_html($description));
            }
            
            echo '</div>';
        }
    }

    private function render_social_fields($lang_code) {
        foreach ($this->social_networks as $social_key => $social_data) {
            $option_name = "udet_{$lang_code}_social_{$social_key}";
            $value = get_option($option_name, '');
            
            echo '<div class="form-field social-field">';
            printf(
                '<label for="%s" class="field-label social-label">
                    <i class="%s"></i> %s
                </label>',
                esc_attr($option_name),
                esc_attr($social_data['icon']),
                esc_html($social_data['name'])
            );
            printf(
                '<input type="text" id="%s" name="%s" value="%s" class="field-input" placeholder="%s">',
                esc_attr($option_name),
                esc_attr($option_name),
                esc_attr($value),
                esc_attr__('username o URL completo', 'iyl-data')
            );
            printf(
                '<p class="field-description">Inserisci solo lo <strong>username</strong> (es: "mioprofilo") oppure l\'<strong>URL completo</strong> (es: "%smioprofilo")</p>',
                esc_html($social_data['base_url'])
            );
            echo '</div>';
        }
    }

    private function render_form_settings($lang_code) {
        // Aggiungi un campo nascosto per l'email subject (usato solo per auto-generazione link)
        $email_subject_option = "udet_{$lang_code}_email_subject";
        $email_subject_value = get_option($email_subject_option, $this->get_default_email_subject($lang_code));
        echo '<input type="hidden" name="' . esc_attr($email_subject_option) . '" value="' . esc_attr($email_subject_value) . '">';
        
        foreach ($this->form_fields as $field_key => $field_title) {
            $option_name = "udet_{$lang_code}_{$field_key}";
            $default_message = $this->get_default_form_message($lang_code, $field_key);
            $value = get_option($option_name, $default_message);
            
            // Decodifica le entità HTML per la visualizzazione nell'admin
            $display_value = html_entity_decode($value, ENT_QUOTES, 'UTF-8');
            
            echo '<div class="form-field">';
            printf('<label for="%s" class="field-label">%s</label>', 
                   esc_attr($option_name), 
                   esc_html($field_title));
            printf(
                '<textarea id="%s" name="%s" rows="2" class="field-input" placeholder="%s">%s</textarea>',
                esc_attr($option_name),
                esc_attr($option_name),
                esc_attr(html_entity_decode($default_message, ENT_QUOTES, 'UTF-8')),
                esc_textarea($display_value)
            );
            
            // Descrizione specifica per il campo privacy
            if ($field_key === 'form_privacy_message') {
                echo '<p class="field-description">' . 
                     __('Testo per l\'accettazione privacy/cookies nel form. Include già il link "privacy-policy" modificabile. I caratteri speciali verranno automaticamente convertiti in entità HTML.', 'iyl-data') . 
                     '</p>';
            } else {
                echo '<p class="field-description">' . 
                     __('Messaggio che verrà mostrato nel form di Elementor. I caratteri speciali verranno automaticamente convertiti in entità HTML.', 'iyl-data') . 
                     '</p>';
            }
            echo '</div>';
        }
    }

    // Metodi getter per altre classi
    public function get_languages() {
        return $this->languages;
    }

    public function get_data_fields() {
        return $this->data_fields;
    }

    public function get_social_networks() {
        return $this->social_networks;
    }

    public function get_form_fields() {
        return $this->form_fields;
    }

    private function get_default_form_message($lang_code, $field_key) {
        // Get privacy policy link for the current language
        $privacy_link = $this->get_default_privacy_link($lang_code);
        
        $messages = [
            'it' => [
                'form_success_message' => 'La tua richiesta &egrave; stata inviata con successo.',
                'form_error_message' => 'La tua richiesta non &egrave; andata a buon fine a causa di un errore.',
                'form_server_error' => 'La tua richiesta non &egrave; andata a buon fine a causa di un errore del server.',
                'form_invalid' => 'La tua richiesta non &egrave; andata a buon fine perch&eacute; il modulo non &egrave; valido.',
                'form_privacy_message' => 'Dichiaro di avere letto e compreso l\'informativa sulla <a href="' . $privacy_link . '" target="_blank">Privacy</a> ai sensi degli artt. 13 e 14 del Regolamento UE 2016/679 *'
            ],
            'en' => [
                'form_success_message' => 'Your request has been sent successfully.',
                'form_error_message' => 'Your request failed due to an error.',
                'form_server_error' => 'Your request failed due to a server error.',
                'form_invalid' => 'Your request failed because the form is invalid.',
                'form_privacy_message' => 'I declare that I have read and understood the <a href="' . $privacy_link . '" target="_blank">Privacy Policy</a> in accordance with articles 13 and 14 of EU Regulation 2016/679 *'
            ],
            'es' => [
                'form_success_message' => 'Tu solicitud ha sido enviada con &eacute;xito.',
                'form_error_message' => 'Tu solicitud no se pudo completar debido a un error.',
                'form_server_error' => 'Tu solicitud no se pudo completar debido a un error del servidor.',
                'form_invalid' => 'Tu solicitud no se pudo completar porque el formulario no es v&aacute;lido.',
                'form_privacy_message' => 'Declaro haber le&iacute;do y comprendido la <a href="' . $privacy_link . '" target="_blank">Pol&iacute;tica de Privacidad</a> de conformidad con los art&iacute;culos 13 y 14 del Reglamento UE 2016/679 *'
            ],
            'fr' => [
                'form_success_message' => 'Votre demande a &eacute;t&eacute; envoy&eacute;e avec succ&egrave;s.',
                'form_error_message' => 'Votre demande n\'a pas pu &ecirc;tre trait&eacute;e en raison d\'une erreur.',
                'form_server_error' => 'Votre demande n\'a pas pu &ecirc;tre trait&eacute;e en raison d\'une erreur serveur.',
                'form_invalid' => 'Votre demande n\'a pas pu &ecirc;tre trait&eacute;e car le formulaire n\'est pas valide.',
                'form_privacy_message' => 'Je d&eacute;clare avoir lu et compris la <a href="' . $privacy_link . '" target="_blank">Politique de Confidentialit&eacute;</a> conform&eacute;ment aux articles 13 et 14 du R&egrave;glement UE 2016/679 *'
            ],
            'de' => [
                'form_success_message' => 'Ihre Anfrage wurde erfolgreich gesendet.',
                'form_error_message' => 'Ihre Anfrage konnte aufgrund eines Fehlers nicht verarbeitet werden.',
                'form_server_error' => 'Ihre Anfrage konnte aufgrund eines Serverfehlers nicht verarbeitet werden.',
                'form_invalid' => 'Ihre Anfrage konnte nicht verarbeitet werden, da das Formular ung&uuml;ltig ist.',
                'form_privacy_message' => 'Ich erkl&auml;re, die <a href="' . $privacy_link . '" target="_blank">Datenschutzerkl&auml;rung</a> gem&auml;&szlig; den Artikeln 13 und 14 der EU-Verordnung 2016/679 gelesen und verstanden zu haben *'
            ]
        ];
        
        return $messages[$lang_code][$field_key] ?? $messages['it'][$field_key] ?? '';
    }

    /**
     * Get default privacy policy link for each language
     */
    private function get_default_privacy_link($lang_code) {
        $default_links = [
            'it' => '/privacy-policy/',
            'en' => '/en/privacy-policy/',
            'es' => '/es/politica-de-privacidad/',
            'fr' => '/fr/politique-de-confidentialite/',
            'de' => '/de/datenschutzerklaerung/'
        ];
        
        return $default_links[$lang_code] ?? $default_links['it'];
    }

    private function get_default_email_subject($lang_code) {
        $subjects = [
            'it' => 'Nuova richiesta di contatto',
            'en' => 'New contact request',
            'es' => 'Nueva solicitud de contacto',
            'fr' => 'Nouvelle demande de contact',
            'de' => 'Neue Kontaktanfrage'
        ];
        
        return $subjects[$lang_code] ?? $subjects['it'] ?? '';
    }

    /**
     * Sanitize callback specifico per i campi del form che preserva le entità HTML
     */
    public function sanitize_form_field($input) {
        // Converti i caratteri speciali in entità HTML per preservare l'encoding
        $input = $this->convert_special_chars_to_entities($input);
        
        // Permetti tag HTML di base per i link (solo per il campo privacy)
        $allowed_html = [
            'a' => [
                'href' => true,
                'target' => true,
                'rel' => true
            ]
        ];
        
        return wp_kses($input, $allowed_html);
    }

    /**
     * Converte i caratteri speciali in entità HTML
     */
    private function convert_special_chars_to_entities($text) {
        $special_chars = [
            'à' => '&agrave;',
            'á' => '&aacute;',
            'è' => '&egrave;',
            'é' => '&eacute;',
            'ì' => '&igrave;',
            'í' => '&iacute;',
            'ò' => '&ograve;',
            'ó' => '&oacute;',
            'ù' => '&ugrave;',
            'ú' => '&uacute;',
            'ç' => '&ccedil;',
            'ñ' => '&ntilde;',
            'ü' => '&uuml;',
            'ä' => '&auml;',
            'ö' => '&ouml;',
            'ß' => '&szlig;',
            'À' => '&Agrave;',
            'Á' => '&Aacute;',
            'È' => '&Egrave;',
            'É' => '&Eacute;',
            'Ì' => '&Igrave;',
            'Í' => '&Iacute;',
            'Ò' => '&Ograve;',
            'Ó' => '&Oacute;',
            'Ù' => '&Ugrave;',
            'Ú' => '&Uacute;',
            'Ç' => '&Ccedil;',
            'Ñ' => '&Ntilde;',
            'Ü' => '&Uuml;',
            'Ä' => '&Auml;',
            'Ö' => '&Ouml;'
        ];
        
        return str_replace(array_keys($special_chars), array_values($special_chars), $text);
    }

    /**
     * Registra gli shortcode per i messaggi del form
     */
    public function register_form_shortcodes() {
        add_shortcode('iyl_privacy_text', [$this, 'shortcode_privacy_text']);
        add_shortcode('iyl_form_message', [$this, 'shortcode_form_message']);
        add_shortcode('iyl_gdpr_text', [$this, 'shortcode_privacy_text']); // Alias per retrocompatibilità
    }

    /**
     * Shortcode per il testo dell'accettazione privacy
     * Uso: [iyl_privacy_text] o [iyl_privacy_text lang="en"]
     */
    public function shortcode_privacy_text($atts = []) {
        $atts = shortcode_atts([
            'lang' => $this->get_current_language(),
            'fallback' => 'it'
        ], $atts, 'iyl_privacy_text');

        $lang_code = sanitize_text_field($atts['lang']);
        $fallback_lang = sanitize_text_field($atts['fallback']);
        
        // Verifica che la lingua sia supportata
        if (!isset($this->languages[$lang_code])) {
            $lang_code = $fallback_lang;
        }
        
        // Verifica che la lingua sia attiva
        $active_languages = get_option('iyl_data_active_languages', ['it']);
        if (!in_array($lang_code, $active_languages)) {
            $lang_code = $fallback_lang;
        }

        // Get privacy policy link from database or use default
        $privacy_link_key = "udet_{$lang_code}_privacy_policy_link";
        $privacy_link = get_option($privacy_link_key, '');
        
        if (empty($privacy_link)) {
            $privacy_link = $this->get_default_privacy_link($lang_code);
        }

        $option_key = "udet_{$lang_code}_form_privacy_message";
        $privacy_text = get_option($option_key, '');

        if (empty($privacy_text)) {
            // Generate default message with current privacy link
            $privacy_text = $this->generate_privacy_message_with_link($lang_code, $privacy_link);
        } else {
            // Update existing message with current privacy link if needed
            $privacy_text = $this->update_privacy_link_in_message($privacy_text, $privacy_link);
        }

        // Decodifica le entità HTML per la visualizzazione finale
        $decoded_text = html_entity_decode($privacy_text, ENT_QUOTES, 'UTF-8');
        
        // Permetti i tag HTML di base per i link
        return wp_kses($decoded_text, [
            'a' => [
                'href' => true,
                'target' => true,
                'rel' => true,
                'class' => true
            ]
        ]);
    }

    /**
     * Generate privacy message with specific link
     */
    private function generate_privacy_message_with_link($lang_code, $privacy_link) {
        $messages = [
            'it' => 'Dichiaro di avere letto e compreso l\'informativa sulla <a href="' . esc_url($privacy_link) . '" target="_blank">Privacy</a> ai sensi degli artt. 13 e 14 del Regolamento UE 2016/679 *',
            'en' => 'I declare that I have read and understood the <a href="' . esc_url($privacy_link) . '" target="_blank">Privacy Policy</a> in accordance with articles 13 and 14 of EU Regulation 2016/679 *',
            'es' => 'Declaro haber le&iacute;do y comprendido la <a href="' . esc_url($privacy_link) . '" target="_blank">Pol&iacute;tica de Privacidad</a> de conformidad con los art&iacute;culos 13 y 14 del Reglamento UE 2016/679 *',
            'fr' => 'Je d&eacute;clare avoir lu et compris la <a href="' . esc_url($privacy_link) . '" target="_blank">Politique de Confidentialit&eacute;</a> conform&eacute;ment aux articles 13 et 14 du R&egrave;glement UE 2016/679 *',
            'de' => 'Ich erkl&auml;re, die <a href="' . esc_url($privacy_link) . '" target="_blank">Datenschutzerkl&auml;rung</a> gem&auml;&szlig; den Artikeln 13 und 14 der EU-Verordnung 2016/679 gelesen und verstanden zu haben *'
        ];
        
        return $messages[$lang_code] ?? $messages['it'];
    }

    /**
     * Update privacy link in existing message
     */
    private function update_privacy_link_in_message($message, $new_link) {
        // Pattern to match href attribute in anchor tags
        $pattern = '/(<a[^>]+href=")([^"]+)("[^>]*>)/i';
        $replacement = '${1}' . esc_url($new_link) . '${3}';
        
        return preg_replace($pattern, $replacement, $message);
    }

    /**
     * Shortcode per i messaggi del form generici
     * Uso: [iyl_form_message type="success"] o [iyl_form_message type="error" lang="en"]
     */
    public function shortcode_form_message($atts = []) {
        $atts = shortcode_atts([
            'type' => 'success',
            'lang' => $this->get_current_language(),
            'fallback' => 'it'
        ], $atts, 'iyl_form_message');

        $message_type = sanitize_text_field($atts['type']);
        $lang_code = sanitize_text_field($atts['lang']);
        $fallback_lang = sanitize_text_field($atts['fallback']);

        // Mappa i tipi di messaggio
        $type_mapping = [
            'success' => 'form_success_message',
            'error' => 'form_error_message',
            'server_error' => 'form_server_error',
            'invalid' => 'form_invalid'
        ];

        if (!isset($type_mapping[$message_type])) {
            $message_type = 'success';
        }

        $field_key = $type_mapping[$message_type];

        // Verifica che la lingua sia supportata
        if (!isset($this->languages[$lang_code])) {
            $lang_code = $fallback_lang;
        }
        
        // Verifica che la lingua sia attiva
        $active_languages = get_option('iyl_data_active_languages', ['it']);
        if (!in_array($lang_code, $active_languages)) {
            $lang_code = $fallback_lang;
        }

        $option_key = "udet_{$lang_code}_{$field_key}";
        $message_text = get_option($option_key, '');

        if (empty($message_text)) {
            // Fallback al messaggio di default
            $message_text = $this->get_default_form_message($lang_code, $field_key);
        }

        // Decodifica le entità HTML per la visualizzazione finale
        return esc_html(html_entity_decode($message_text, ENT_QUOTES, 'UTF-8'));
    }

    /**
     * Rileva la lingua corrente dal contesto (Polylang, WPML, ecc.)
     */
    private function get_current_language() {
        // Supporto per Polylang
        if (function_exists('pll_current_language')) {
            $current_lang = pll_current_language();
            if (!empty($current_lang)) {
                return $current_lang;
            }
        }

        // Supporto per WPML
        if (defined('ICL_LANGUAGE_CODE') && !empty(ICL_LANGUAGE_CODE)) {
            return ICL_LANGUAGE_CODE;
        }

        // Fallback all'italiano
        return 'it';
    }
} 