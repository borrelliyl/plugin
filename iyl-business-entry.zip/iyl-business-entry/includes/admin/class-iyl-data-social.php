<?php

if (!defined('ABSPATH')) {
    exit;
}

class IYL_Data_Social {
    private static $social_networks = [
        'facebook' => [
            'name' => 'Facebook',
            'icon' => 'fab fa-facebook',
            'base_url' => 'https://facebook.com/',
            'placeholder' => 'nomepagina'
        ],
        'instagram' => [
            'name' => 'Instagram',
            'icon' => 'fab fa-instagram',
            'base_url' => 'https://instagram.com/',
            'placeholder' => 'username'
        ],
        'youtube' => [
            'name' => 'YouTube',
            'icon' => 'fab fa-youtube',
            'base_url' => 'https://youtube.com/',
            'placeholder' => '@canale'
        ],
        'twitter' => [
            'name' => 'Twitter/X',
            'icon' => 'fab fa-x-twitter',
            'base_url' => 'https://twitter.com/',
            'placeholder' => 'username'
        ],
        'linkedin' => [
            'name' => 'LinkedIn',
            'icon' => 'fab fa-linkedin',
            'base_url' => 'https://linkedin.com/company/',
            'placeholder' => 'azienda'
        ],
        'telegram' => [
            'name' => 'Telegram',
            'icon' => 'fab fa-telegram',
            'base_url' => 'https://t.me/',
            'placeholder' => 'username'
        ],
        'tiktok' => [
            'name' => 'TikTok',
            'icon' => 'fab fa-tiktok',
            'base_url' => 'https://tiktok.com/@',
            'placeholder' => 'username'
        ],
        'pinterest' => [
            'name' => 'Pinterest',
            'icon' => 'fab fa-pinterest',
            'base_url' => 'https://pinterest.com/',
            'placeholder' => 'username'
        ]
    ];

    public static function get_social_networks() {
        return self::$social_networks;
    }

    public static function get_active_socials() {
        $active_socials = get_option('iyl_data_active_socials', []);
        if (empty($active_socials)) {
            return [];
        }
        return $active_socials;
    }

    public static function get_social_url($social_key) {
        if (!isset(self::$social_networks[$social_key])) {
            return '';
        }

        $value = get_option("iyl_data_social_{$social_key}", '');
        if (empty($value)) {
            return '';
        }

        // Controlla se il valore è già un URL completo
        if (strpos($value, 'http://') === 0 || strpos($value, 'https://') === 0) {
            return $value; // Restituisci l'URL completo così com'è
        }

        // Altrimenti trattalo come username e concatena con base_url
        $network = self::$social_networks[$social_key];
        return $network['base_url'] . $value;
    }

    public static function get_social_data($social_key) {
        if (!isset(self::$social_networks[$social_key])) {
            return null;
        }

        $network = self::$social_networks[$social_key];
        $value = get_option("iyl_data_social_{$social_key}", '');
        $url = self::get_social_url($social_key);

        return [
            'name' => $network['name'],
            'icon' => $network['icon'],
            'username' => $value, // Può essere username o URL completo
            'url' => $url
        ];
    }

    public static function register_settings() {
        // Registra l'opzione per i social attivi
        register_setting('iyl_data_options', 'iyl_data_active_socials', [
            'type' => 'array',
            'default' => []
        ]);

        // Registra le opzioni per ogni social
        foreach (self::$social_networks as $key => $network) {
            register_setting('iyl_data_options', "iyl_data_social_{$key}");
        }
    }

    public static function add_settings_section($page) {
        add_settings_section(
            'iyl_data_social_section',
            __('Social Media', 'iyl-data'),
            [__CLASS__, 'render_section_description'],
            $page
        );

        // Campo per selezionare i social attivi
        add_settings_field(
            'iyl_data_active_socials',
            __('Active Social Networks', 'iyl-data'),
            [__CLASS__, 'render_social_checkboxes'],
            $page,
            'iyl_data_social_section'
        );

        // Campi per gli username dei social attivi
        $active_socials = self::get_active_socials();
        foreach ($active_socials as $social_key) {
            if (isset(self::$social_networks[$social_key])) {
                $network = self::$social_networks[$social_key];
                add_settings_field(
                    "iyl_data_social_{$social_key}",
                    $network['name'],
                    [__CLASS__, 'render_social_field'],
                    $page,
                    'iyl_data_social_section',
                    ['social_key' => $social_key]
                );
            }
        }
    }

    public static function render_section_description() {
        echo '<p>' . __('Select and configure your social media profiles.', 'iyl-data') . '</p>';
    }

    public static function render_social_checkboxes() {
        $active_socials = self::get_active_socials();
        
        echo '<div class="iyl-social-checkboxes">';
        foreach (self::$social_networks as $key => $network) {
            $checked = in_array($key, $active_socials) ? 'checked' : '';
            printf(
                '<label style="display: inline-block; margin-right: 20px; margin-bottom: 10px;">
                    <input type="checkbox" name="iyl_data_active_socials[]" value="%s" %s>
                    <i class="%s" style="margin-right: 5px;"></i>
                    %s
                </label>',
                esc_attr($key),
                $checked,
                esc_attr($network['icon']),
                esc_html($network['name'])
            );
        }
        echo '</div>';
    }

    public static function render_social_field($args) {
        $social_key = $args['social_key'];
        $network = self::$social_networks[$social_key];
        $value = get_option("iyl_data_social_{$social_key}", '');

        printf(
            '<input type="text" class="regular-text" name="iyl_data_social_%s" value="%s" placeholder="%s">
            <p class="description">Inserisci solo lo <strong>username</strong> (es: "%s") oppure l\'<strong>URL completo</strong> (es: "%s")</p>',
            esc_attr($social_key),
            esc_attr($value),
            esc_attr($network['placeholder'] . ' o URL completo'),
            esc_html($network['placeholder']),
            esc_html($network['base_url'] . $network['placeholder'])
        );
    }
} 