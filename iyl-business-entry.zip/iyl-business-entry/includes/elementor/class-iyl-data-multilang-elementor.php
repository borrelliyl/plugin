<?php

if (!defined('ABSPATH')) {
    exit;
}

// Base class for all IYL tags - embedded in this file to avoid loading issues
abstract class IYL_Multilang_Tag_Base extends \Elementor\Core\DynamicTags\Tag {
    
    /**
     * Check if string starts with a given substring (PHP 7.4 compatibility)
     */
    private function str_starts_with($haystack, $needle) {
        if (function_exists('str_starts_with')) {
            return str_starts_with($haystack, $needle);
        }
        return strpos($haystack, $needle) === 0;
    }
    
    /**
     * Generate email link with automatic subject
     */
    protected function generate_email_link($lang_code) {
        $email = get_option("udet_{$lang_code}_email", '');
        if (empty($email)) {
            return '';
        }

        $subject = get_option("udet_{$lang_code}_email_subject", 'Richiesta inviata da');
        $dominio = get_option("udet_{$lang_code}_dominio", '');
        
        $full_subject = $subject . ' ' . $dominio;
        
        return 'mailto:' . $email . '?subject=' . rawurlencode($full_subject);
    }

    /**
     * Generate phone link with +39 prefix
     */
    protected function generate_phone_link($lang_code, $field_type) {
        $phone = get_option("udet_{$lang_code}_{$field_type}", '');
        if (empty($phone)) {
            return '';
        }

        // Remove all non-numeric characters except +
        $clean_phone = preg_replace('/[^0-9+]/', '', $phone);
        
        // Add +39 if not already present
        if (!$this->str_starts_with($clean_phone, '+')) {
            $clean_phone = '+39' . ltrim($clean_phone, '39');
        }

        return 'tel:' . $clean_phone;
    }

    /**
     * Generate WhatsApp link
     */
    protected function generate_whatsapp_link($lang_code) {
        $whatsapp = get_option("udet_{$lang_code}_whatsapp", '');
        if (empty($whatsapp)) {
            return '';
        }

        // Remove all non-numeric characters except +
        $clean_whatsapp = preg_replace('/[^0-9+]/', '', $whatsapp);
        
        // Add +39 if not already present
        if (!$this->str_starts_with($clean_whatsapp, '+')) {
            $clean_whatsapp = '+39' . ltrim($clean_whatsapp, '39');
        }

        return 'https://wa.me/' . $clean_whatsapp;
    }

    /**
     * Generate social network link
     */
    protected function generate_social_link($lang_code, $social_key, $base_url) {
        $value = get_option("udet_{$lang_code}_social_{$social_key}", '');
        if (empty($value)) {
            return '';
        }

        // Controlla se il valore è già un URL completo
        if (strpos($value, 'http://') === 0 || strpos($value, 'https://') === 0) {
            return $value; // Restituisci l'URL completo così com'è
        }

        // Altrimenti trattalo come username e concatena con base_url
        return $base_url . $value;
    }
}

class IYL_Data_Multilang_Elementor {
    private $admin_instance;

    public function __construct($admin_instance) {
        $this->admin_instance = $admin_instance;
        
        // Declare unified tag classes first
        $this->declare_unified_tag_classes();
        
        // Hook più sicuro per Elementor
        add_action('elementor/dynamic_tags/register', [$this, 'register_dynamic_tags'], 10);
        add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_styles']);
    }

    private function declare_unified_tag_classes() {
        // Classes will be declared outside this class
    }

    public function register_dynamic_tags($dynamic_tags) {
        // Verifica che Elementor sia disponibile
        if (!class_exists('\Elementor\Core\DynamicTags\Tag')) {
            error_log('IYL Data: Elementor Tag class not available');
            return;
        }

        // Verifica che l'admin instance sia valida
        if (!$this->admin_instance || !method_exists($this->admin_instance, 'get_languages')) {
            error_log('IYL Data: Admin instance not valid for Elementor integration');
            return;
        }

        $languages = $this->admin_instance->get_languages();
        $data_fields = $this->admin_instance->get_data_fields();
        $social_networks = $this->admin_instance->get_social_networks();
        $form_fields = $this->admin_instance->get_form_fields();
        $active_languages = get_option('iyl_data_active_languages', ['it']);

        error_log('IYL Data: Starting tag registration for languages: ' . implode(', ', $active_languages));

        // Register tag groups for each active language
        foreach ($active_languages as $lang_code) {
            if (isset($languages[$lang_code])) {
                $lang_data = $languages[$lang_code];
                
                // Registra gruppo con controllo errori
                try {
                    \Elementor\Plugin::$instance->dynamic_tags->register_group(
                        'user-data-' . $lang_code,
                        [
                            'title' => $lang_data['flag'] . ' IYL Data - ' . $lang_data['name']
                        ]
                    );
                    error_log('IYL Data: Registered group for ' . $lang_code);
                } catch (Exception $e) {
                    error_log('IYL Data: Errore registrazione gruppo ' . $lang_code . ': ' . $e->getMessage());
                    continue;
                }

                // Registra i tag in modo sicuro
                $this->register_safe_tags($dynamic_tags, $lang_code, $lang_data, $data_fields, $social_networks, $form_fields);
            }
        }
    }

    private function register_safe_tags($dynamic_tags, $lang_code, $lang_data, $data_fields, $social_networks, $form_fields) {
        // Debug: log all data fields being processed
        error_log('IYL Data: Data fields for ' . $lang_code . ': ' . print_r(array_keys($data_fields), true));
        
        // Register data field tags - create individual tags for each field
        foreach ($data_fields as $field_key => $field_title) {
            try {
                // Create a specific tag class for this field
                $tag_class_name = 'IYL_Data_Tag_' . ucfirst($lang_code) . '_' . ucfirst(str_replace('_', '', $field_key));
                $this->create_specific_data_tag_class($tag_class_name, $field_key, $field_title, $lang_code, $lang_data);
                
                $tag = new $tag_class_name();
                $dynamic_tags->register($tag);
                error_log('IYL Data: Registered specific data tag ' . $field_key . ' for ' . $lang_code . ' - Type: ' . (strpos($field_key, 'link_') === 0 ? 'URL' : 'TEXT'));
            } catch (Exception $e) {
                error_log('IYL Data: Errore registrazione tag data ' . $field_key . ': ' . $e->getMessage());
            }
        }

        // Register social network tags - create individual tags for each social
        foreach ($social_networks as $social_key => $social_data) {
            try {
                // Create a specific tag class for this social network
                $tag_class_name = 'IYL_Social_Tag_' . ucfirst($lang_code) . '_' . ucfirst($social_key);
                $this->create_specific_social_tag_class($tag_class_name, $social_key, $social_data, $lang_code, $lang_data);
                
                $tag = new $tag_class_name();
                $dynamic_tags->register($tag);
                error_log('IYL Data: Registered specific social tag ' . $social_key . ' for ' . $lang_code);
            } catch (Exception $e) {
                error_log('IYL Data: Errore registrazione tag social ' . $social_key . ': ' . $e->getMessage());
            }
        }

        // Register form field tags - create individual tags for each form field
        foreach ($form_fields as $field_key => $field_title) {
            try {
                // Create a specific tag class for this form field
                $tag_class_name = 'IYL_Form_Tag_' . ucfirst($lang_code) . '_' . ucfirst(str_replace('_', '', $field_key));
                $this->create_specific_form_tag_class($tag_class_name, $field_key, $field_title, $lang_code, $lang_data);
                
                $tag = new $tag_class_name();
                $dynamic_tags->register($tag);
                error_log('IYL Data: Registered specific form tag ' . $field_key . ' for ' . $lang_code);
            } catch (Exception $e) {
                error_log('IYL Data: Errore registrazione tag form ' . $field_key . ': ' . $e->getMessage());
            }
        }
    }

    private function create_specific_data_tag_class($class_name, $field_key, $field_title, $lang_code, $lang_data) {
        if (class_exists($class_name)) {
            return;
        }

        // Create the specific class using eval (safe because we control all the inputs)
        $tag_name = 'user-data-' . $lang_code . '-' . str_replace('_', '-', $field_key);
        $tag_title = addslashes($lang_data['flag'] . ' ' . $field_title);
        $group_name = 'user-data-' . $lang_code;
        
        $categories_code = $this->get_categories_code_for_field($field_key);
        $render_code = $this->get_render_code_for_field($field_key, $lang_code);
        $output_code = $this->get_output_code_for_field($field_key);

        $class_code = "
        class {$class_name} extends IYL_Multilang_Tag_Base {
            public function get_name() {
                return '{$tag_name}';
            }
            
            public function get_title() {
                return '{$tag_title}';
            }
            
            public function get_group() {
                return '{$group_name}';
            }
            
            public function get_categories() {
                {$categories_code}
            }
            
            public function render() {
                \$lang_code = '{$lang_code}';
                \$field_key = '{$field_key}';
                \$option_key = 'udet_' . \$lang_code . '_' . \$field_key;
                \$value = get_option(\$option_key, '');
                
                error_log('IYL Specific Tag Debug - Class: {$class_name}, Option: ' . \$option_key . ', Value: ' . \$value);
                
                try {
                    {$render_code}
                } catch (Exception \$e) {
                    error_log('IYL Data: Errore generazione link {$field_key}: ' . \$e->getMessage());
                    \$value = get_option(\$option_key, '');
                }
                
                {$output_code}
            }
        }";

        eval($class_code);
    }

    private function create_specific_social_tag_class($class_name, $social_key, $social_data, $lang_code, $lang_data) {
        if (class_exists($class_name)) {
            return;
        }

        $tag_name = 'user-data-' . $lang_code . '-social-' . $social_key;
        $tag_title = addslashes($lang_data['flag'] . ' ' . $social_data['name']);
        $group_name = 'user-data-' . $lang_code;
        $base_url = addslashes($social_data['base_url']);

        $class_code = "
        class {$class_name} extends IYL_Multilang_Tag_Base {
            public function get_name() {
                return '{$tag_name}';
            }
            
            public function get_title() {
                return '{$tag_title}';
            }
            
            public function get_group() {
                return '{$group_name}';
            }
            
            public function get_categories() {
                return [\Elementor\Modules\DynamicTags\Module::URL_CATEGORY, \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
            }
            
            public function render() {
                \$lang_code = '{$lang_code}';
                \$social_key = '{$social_key}';
                \$base_url = '{$base_url}';
                
                try {
                    \$value = \$this->generate_social_link(\$lang_code, \$social_key, \$base_url);
                    error_log('IYL Social Tag Debug - Social: {$social_key}, Lang: {$lang_code}, Value: ' . \$value);
                    echo esc_url(\$value);
                } catch (Exception \$e) {
                    error_log('IYL Data: Errore generazione social link {$social_key}: ' . \$e->getMessage());
                    echo '';
                }
            }
        }";

        eval($class_code);
    }

    private function create_specific_form_tag_class($class_name, $field_key, $field_title, $lang_code, $lang_data) {
        if (class_exists($class_name)) {
            return;
        }

        $tag_name = 'user-data-' . $lang_code . '-form-' . str_replace('_', '-', $field_key);
        $tag_title = addslashes($lang_data['flag'] . ' ' . $field_title);
        $group_name = 'user-data-' . $lang_code;

        $class_code = "
        class {$class_name} extends IYL_Multilang_Tag_Base {
            public function get_name() {
                return '{$tag_name}';
            }
            
            public function get_title() {
                return '{$tag_title}';
            }
            
            public function get_group() {
                return '{$group_name}';
            }
            
            public function get_categories() {
                return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
            }
            
            public function render() {
                \$lang_code = '{$lang_code}';
                \$field_key = '{$field_key}';
                \$option_key = 'udet_' . \$lang_code . '_' . \$field_key;
                \$value = get_option(\$option_key, '');
                
                error_log('IYL Form Tag Debug - Class: {$class_name}, Option: ' . \$option_key . ', Value: ' . \$value);
                
                // Per il campo privacy, mantieni HTML per i link ma decodifica le entità
                if (\$field_key === 'form_privacy_message') {
                    // Decodifica le entità HTML e permetti i tag di link
                    \$decoded_value = html_entity_decode(\$value, ENT_QUOTES, 'UTF-8');
                    echo wp_kses(\$decoded_value, [
                        'a' => [
                            'href' => true,
                            'target' => true,
                            'rel' => true
                        ]
                    ]);
                } else {
                    // Per gli altri messaggi, decodifica le entità HTML ma mantieni il testo sicuro
                    echo esc_html(html_entity_decode(\$value, ENT_QUOTES, 'UTF-8'));
                }
            }
        }";

        eval($class_code);
    }

    private function get_categories_code_for_field($field_key) {
        if (strpos($field_key, 'link_') === 0 || $field_key === 'dominio') {
            return 'return [\Elementor\Modules\DynamicTags\Module::URL_CATEGORY];';
        }
        
        return 'return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];';
    }

    private function get_render_code_for_field($field_key, $lang_code) {
        if (strpos($field_key, 'link_email') !== false) {
            return "\$value = \$this->generate_email_link('{$lang_code}');";
        } elseif (strpos($field_key, 'link_telefono') !== false || strpos($field_key, 'link_cellulare') !== false) {
            $base_field = str_replace('link_', '', $field_key);
            return "\$value = \$this->generate_phone_link('{$lang_code}', '{$base_field}');";
        } elseif (strpos($field_key, 'link_whatsapp') !== false) {
            return "\$value = \$this->generate_whatsapp_link('{$lang_code}');";
        }
        
        return "// No special processing needed";
    }

    private function get_output_code_for_field($field_key) {
        if ($field_key === 'iframe_mappa') {
            return "echo wp_kses(\$value, [
                'iframe' => [
                    'src' => true,
                    'width' => true,
                    'height' => true,
                    'frameborder' => true,
                    'allowfullscreen' => true,
                    'style' => true,
                    'class' => true,
                    'loading' => true
                ]
            ]);";
        }
        
        return "echo esc_html(\$value);";
    }

    public function enqueue_styles() {
        // Carica Font Awesome per le icone social
        wp_enqueue_style(
            'font-awesome',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
            [],
            '6.5.1'
        );
    }
} 