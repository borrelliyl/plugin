<?php

if (!defined('ABSPATH')) {
    exit;
}

abstract class IYL_Multilang_Tag_Base extends \Elementor\Core\DynamicTags\Tag {
    
    /**
     * Check if string starts with a given substring (PHP 7.4 compatibility)
     */
    private function str_starts_with($haystack, $needle) {
        if (function_exists('str_starts_with')) {
            return str_starts_with($haystack, $needle);
        }
        return strpos($haystack, $needle) === 0;
    }
    
    /**
     * Generate email link with automatic subject
     */
    protected function generate_email_link($lang_code) {
        $email = get_option("udet_{$lang_code}_email", '');
        if (empty($email)) {
            return '';
        }

        $subject = get_option("udet_{$lang_code}_email_subject", 'Richiesta inviata da');
        $dominio = get_option("udet_{$lang_code}_dominio", '');
        
        $full_subject = $subject . ' ' . $dominio;
        
        return 'mailto:' . $email . '?subject=' . rawurlencode($full_subject);
    }

    /**
     * Generate phone link with +39 prefix
     */
    protected function generate_phone_link($lang_code, $field_type) {
        $phone = get_option("udet_{$lang_code}_{$field_type}", '');
        if (empty($phone)) {
            return '';
        }

        // Remove all non-numeric characters except +
        $clean_phone = preg_replace('/[^0-9+]/', '', $phone);
        
        // Add +39 if not already present
        if (!$this->str_starts_with($clean_phone, '+')) {
            $clean_phone = '+39' . ltrim($clean_phone, '39');
        }

        return 'tel:' . $clean_phone;
    }

    /**
     * Generate WhatsApp link
     */
    protected function generate_whatsapp_link($lang_code) {
        $whatsapp = get_option("udet_{$lang_code}_whatsapp", '');
        if (empty($whatsapp)) {
            return '';
        }

        // Remove all non-numeric characters except +
        $clean_whatsapp = preg_replace('/[^0-9+]/', '', $whatsapp);
        
        // Add +39 if not already present
        if (!$this->str_starts_with($clean_whatsapp, '+')) {
            $clean_whatsapp = '+39' . ltrim($clean_whatsapp, '39');
        }

        return 'https://wa.me/' . $clean_whatsapp;
    }

    /**
     * Generate social network link
     */
    protected function generate_social_link($lang_code, $social_key, $base_url) {
        $value = get_option("udet_{$lang_code}_social_{$social_key}", '');
        if (empty($value)) {
            return '';
        }

        // Controlla se il valore è già un URL completo
        if ($this->str_starts_with($value, 'http://') || $this->str_starts_with($value, 'https://')) {
            return $value; // Restituisci l'URL completo così com'è
        }

        // Altrimenti trattalo come username e concatena con base_url
        return $base_url . $value;
    }

    /**
     * Get formatted phone number for display
     */
    protected function format_phone_display($phone) {
        if (empty($phone)) {
            return '';
        }

        // Remove all non-numeric characters except + and spaces
        $clean_phone = preg_replace('/[^0-9+\s()]/', '', $phone);
        
        // Add +39 if not already present
        if (!$this->str_starts_with($clean_phone, '+')) {
            $clean_phone = '+39 ' . ltrim($clean_phone, '39');
        }

        return $clean_phone;
    }

    /**
     * Get option value with language fallback
     */
    protected function get_option_with_fallback($option_key, $lang_code, $default = '') {
        $value = get_option("udet_{$lang_code}_{$option_key}", '');
        
        // If empty and not Italian, try to get Italian value as fallback
        if (empty($value) && $lang_code !== 'it') {
            $value = get_option("udet_it_{$option_key}", '');
        }
        
        return !empty($value) ? $value : $default;
    }

    /**
     * Sanitize output for HTML display
     */
    protected function sanitize_output($value, $context = 'text') {
        switch ($context) {
            case 'url':
                return esc_url($value);
            case 'html':
                return wp_kses_post($value);
            case 'attr':
                return esc_attr($value);
            case 'form_message':
                // Decodifica le entità HTML per i messaggi del form
                return esc_html(html_entity_decode($value, ENT_QUOTES, 'UTF-8'));
            case 'form_privacy':
                // Per il campo privacy, decodifica entità e permetti link
                $decoded_value = html_entity_decode($value, ENT_QUOTES, 'UTF-8');
                return wp_kses($decoded_value, [
                    'a' => [
                        'href' => true,
                        'target' => true,
                        'rel' => true
                    ]
                ]);
            default:
                return esc_html($value);
        }
    }

    /**
     * Get form message with proper encoding
     */
    protected function get_form_message($lang_code, $field_key) {
        $option_key = "udet_{$lang_code}_{$field_key}";
        $value = get_option($option_key, '');
        
        if (empty($value)) {
            return '';
        }
        
        // Gestisci il tipo di encoding in base al campo
        if ($field_key === 'form_privacy_message') {
            return $this->sanitize_output($value, 'form_privacy');
        } else {
            return $this->sanitize_output($value, 'form_message');
        }
    }

    /**
     * Check if field should be displayed (not empty)
     */
    protected function should_display($value) {
        return !empty(trim($value));
    }

    /**
     * Get current language code from Polylang if available
     */
    protected function get_current_language() {
        if (function_exists('pll_current_language')) {
            return pll_current_language();
        }
        
        // Fallback to Italian if no multilingual plugin
        return 'it';
    }

    /**
     * Auto-detect language based on current context
     */
    protected function get_auto_language_value($field_key) {
        $current_lang = $this->get_current_language();
        $active_languages = get_option('iyl_data_active_languages', ['it']);
        
        // If current language is active, use it
        if (in_array($current_lang, $active_languages)) {
            return get_option("udet_{$current_lang}_{$field_key}", '');
        }
        
        // Otherwise, use the first active language
        $first_lang = $active_languages[0] ?? 'it';
        return get_option("udet_{$first_lang}_{$field_key}", '');
    }

    /**
     * Generate structured data for contact information
     */
    protected function get_structured_data($lang_code) {
        $data = [
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => get_option("udet_{$lang_code}_nome_sito", ''),
            'url' => get_option("udet_{$lang_code}_dominio", ''),
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => get_option("udet_{$lang_code}_indirizzo", '')
            ],
            'contactPoint' => [
                '@type' => 'ContactPoint',
                'telephone' => $this->format_phone_display(get_option("udet_{$lang_code}_telefono", '')),
                'email' => get_option("udet_{$lang_code}_email", ''),
                'contactType' => 'customer service'
            ]
        ];

        // Add social media profiles
        $social_networks = ['facebook', 'instagram', 'linkedin', 'twitter', 'pinterest'];
        $social_profiles = [];
        
        foreach ($social_networks as $social) {
            $username = get_option("udet_{$lang_code}_social_{$social}", '');
            if (!empty($username)) {
                $social_profiles[] = $this->generate_social_link($lang_code, $social, $this->get_social_base_url($social));
            }
        }
        
        if (!empty($social_profiles)) {
            $data['sameAs'] = $social_profiles;
        }

        return $data;
    }

    /**
     * Get social media base URL
     */
    private function get_social_base_url($social_key) {
        $base_urls = [
            'facebook' => 'https://facebook.com/',
            'instagram' => 'https://instagram.com/',
            'linkedin' => 'https://linkedin.com/company/',
            'twitter' => 'https://twitter.com/',
            'pinterest' => 'https://pinterest.com/'
        ];

        return $base_urls[$social_key] ?? '';
    }
} 