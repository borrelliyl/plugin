<?php
/**
 * Plugin Name: IYL Business Entry
 * Description: Dynamic business information integration for Elementor with multilingual support
 * Version: 2.1.0
 * Author: InYourLife
 * Text Domain: iyl-data
 * Domain Path: /languages
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Plugin constants
define('IYL_DATA_VERSION', '2.1.0');
define('IYL_DATA_FILE', __FILE__);
define('IYL_DATA_PATH', plugin_dir_path(IYL_DATA_FILE));
define('IYL_DATA_URL', plugin_dir_url(IYL_DATA_FILE));

// Compatibility function for PHP 7.4
if (!function_exists('iyl_str_starts_with')) {
    function iyl_str_starts_with($haystack, $needle) {
        if (function_exists('str_starts_with')) {
            return str_starts_with($haystack, $needle);
        }
        return strpos($haystack, $needle) === 0;
    }
}

// Main plugin class
class IYL_Data_Plugin {
    private static $instance = null;
    private $admin_instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Hooks immediati
        add_action('plugins_loaded', [$this, 'init_plugin']);
        add_action('admin_init', [$this, 'admin_init']);
        register_activation_hook(__FILE__, [$this, 'activate_plugin']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate_plugin']);
        
        // Hook per debug
        add_action('wp_footer', [$this, 'debug_info']);
        add_action('admin_footer', [$this, 'debug_info']);
        
        // Force early initialization se necessario
        add_action('init', [$this, 'ensure_initialization'], 1);
    }

    public function init_plugin() {
        // Load text domain
        load_plugin_textdomain('iyl-data', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Initialize components
        $this->init_components();
        
        // Check if we need to migrate from old version
        $this->maybe_migrate_data();
    }

    public function admin_init() {
        // Force admin components if not loaded
        if (is_admin() && !$this->admin_instance) {
            $this->force_admin_load();
        }
    }

    public function ensure_initialization() {
        // Assicura che i componenti siano caricati
        if (!$this->admin_instance && is_admin()) {
            $this->force_admin_load();
        }
    }

    private function force_admin_load() {
        $this->ensure_directories();
        
        // Load multilingual admin class
        if (file_exists(IYL_DATA_PATH . 'includes/admin/class-iyl-data-multilang-admin.php')) {
            require_once IYL_DATA_PATH . 'includes/admin/class-iyl-data-multilang-admin.php';
            
            if (class_exists('IYL_Data_Multilang_Admin')) {
                $this->admin_instance = new IYL_Data_Multilang_Admin();
            }
        }
    }

    private function init_components() {
        // Assicurati che le directory esistano
        $this->ensure_directories();
        
        // Load multilingual admin class
        if (file_exists(IYL_DATA_PATH . 'includes/admin/class-iyl-data-multilang-admin.php')) {
            require_once IYL_DATA_PATH . 'includes/admin/class-iyl-data-multilang-admin.php';
            
            if (class_exists('IYL_Data_Multilang_Admin')) {
                $this->admin_instance = new IYL_Data_Multilang_Admin();
            }
        }

        // Load Elementor integration with multiple hooks for safety
        add_action('elementor/loaded', [$this, 'init_elementor_integration'], 10);
        add_action('elementor/init', [$this, 'init_elementor_integration'], 10);
        add_action('elementor/dynamic_tags/register', [$this, 'force_elementor_integration'], 5);

        // Load backwards compatibility if needed
        if ($this->needs_backward_compatibility()) {
            $this->load_backward_compatibility();
        }
    }

    public function force_elementor_integration($dynamic_tags = null) {
        // Force load if not already loaded
        if (!class_exists('IYL_Data_Multilang_Elementor')) {
            $this->init_elementor_integration();
        }
    }

    public function init_elementor_integration() {
        // Check if our admin instance is ready
        if (!$this->admin_instance) {
            error_log('IYL Data: Admin instance not ready for Elementor integration');
            return;
        }

        // Load integration file
        $elementor_file = IYL_DATA_PATH . 'includes/elementor/class-iyl-data-multilang-elementor.php';
        if (!file_exists($elementor_file)) {
            error_log('IYL Data: Elementor integration file missing: ' . $elementor_file);
            return;
        }

        try {
            require_once $elementor_file;
            
            if (class_exists('IYL_Data_Multilang_Elementor')) {
                new IYL_Data_Multilang_Elementor($this->admin_instance);
                error_log('IYL Data: Elementor integration loaded successfully');
            } else {
                error_log('IYL Data: Elementor integration class not found after require');
            }
        } catch (Exception $e) {
            error_log('IYL Data: Error loading Elementor integration: ' . $e->getMessage());
        }
    }

    private function ensure_directories() {
        $directories = [
            IYL_DATA_PATH . 'assets',
            IYL_DATA_PATH . 'assets/css',
            IYL_DATA_PATH . 'assets/js',
            IYL_DATA_PATH . 'includes',
            IYL_DATA_PATH . 'includes/admin',
            IYL_DATA_PATH . 'includes/elementor',
            IYL_DATA_PATH . 'includes/elementor/tags'
        ];

        foreach ($directories as $dir) {
            if (!file_exists($dir)) {
                wp_mkdir_p($dir);
            }
        }
    }

    public function activate_plugin() {
        // Set default options on activation
        $default_options = [
            'iyl_data_active_languages' => ['it']
        ];

        // Aggiungi i messaggi del form per ogni lingua
        $languages = ['it', 'en', 'es', 'fr', 'de'];
        
        // Link di default per le privacy policy
        $privacy_links = [
            'it' => '/privacy-policy/',
            'en' => '/en/privacy-policy/',
            'es' => '/es/politica-de-privacidad/',
            'fr' => '/fr/politique-de-confidentialite/',
            'de' => '/de/datenschutzerklaerung/'
        ];
        
        $form_messages = [
            'it' => [
                'form_success_message' => 'La tua richiesta &egrave; stata inviata con successo.',
                'form_error_message' => 'La tua richiesta non &egrave; andata a buon fine a causa di un errore.',
                'form_server_error' => 'La tua richiesta non &egrave; andata a buon fine a causa di un errore del server.',
                'form_invalid' => 'La tua richiesta non &egrave; andata a buon fine perch&eacute; il modulo non &egrave; valido.',
                'form_privacy_message' => 'Dichiaro di avere letto e compreso l\'informativa sulla <a href="' . $privacy_links['it'] . '" target="_blank">Privacy</a> ai sensi degli artt. 13 e 14 del Regolamento UE 2016/679 *'
            ],
            'en' => [
                'form_success_message' => 'Your request has been sent successfully.',
                'form_error_message' => 'Your request failed due to an error.',
                'form_server_error' => 'Your request failed due to a server error.',
                'form_invalid' => 'Your request failed because the form is invalid.',
                'form_privacy_message' => 'I declare that I have read and understood the <a href="' . $privacy_links['en'] . '" target="_blank">Privacy Policy</a> in accordance with articles 13 and 14 of EU Regulation 2016/679 *'
            ],
            'es' => [
                'form_success_message' => 'Tu solicitud ha sido enviada con &eacute;xito.',
                'form_error_message' => 'Tu solicitud no se pudo completar debido a un error.',
                'form_server_error' => 'Tu solicitud no se pudo completar debido a un error del servidor.',
                'form_invalid' => 'Tu solicitud no se pudo completar porque el formulario no es v&aacute;lido.',
                'form_privacy_message' => 'Declaro haber le&iacute;do y comprendido la <a href="' . $privacy_links['es'] . '" target="_blank">Pol&iacute;tica de Privacidad</a> de conformidad con los art&iacute;culos 13 y 14 del Reglamento UE 2016/679 *'
            ],
            'fr' => [
                'form_success_message' => 'Votre demande a &eacute;t&eacute; envoy&eacute;e avec succ&egrave;s.',
                'form_error_message' => 'Votre demande n\'a pas pu &ecirc;tre trait&eacute;e en raison d\'une erreur.',
                'form_server_error' => 'Votre demande n\'a pas pu &ecirc;tre trait&eacute;e en raison d\'une erreur serveur.',
                'form_invalid' => 'Votre demande n\'a pas pu &ecirc;tre trait&eacute;e car le formulaire n\'est pas valide.',
                'form_privacy_message' => 'Je d&eacute;clare avoir lu et compris la <a href="' . $privacy_links['fr'] . '" target="_blank">Politique de Confidentialit&eacute;</a> conform&eacute;ment aux articles 13 et 14 du R&egrave;glement UE 2016/679 *'
            ],
            'de' => [
                'form_success_message' => 'Ihre Anfrage wurde erfolgreich gesendet.',
                'form_error_message' => 'Ihre Anfrage konnte aufgrund eines Fehlers nicht verarbeitet werden.',
                'form_server_error' => 'Ihre Anfrage konnte aufgrund eines Serverfehlers nicht verarbeitet werden.',
                'form_invalid' => 'Ihre Anfrage konnte nicht verarbeitet werden, da das Formular ung&uuml;ltig ist.',
                'form_privacy_message' => 'Ich erkl&auml;re, die <a href="' . $privacy_links['de'] . '" target="_blank">Datenschutzerkl&auml;rung</a> gem&auml;&szlig; den Artikeln 13 und 14 der EU-Verordnung 2016/679 gelesen und verstanden zu haben *'
            ]
        ];

        // Aggiungi i subject email per ogni lingua (per auto-generazione link)
        $email_subjects = [
            'it' => 'Nuova richiesta di contatto',
            'en' => 'New contact request',
            'es' => 'Nueva solicitud de contacto',
            'fr' => 'Nouvelle demande de contact',
            'de' => 'Neue Kontaktanfrage'
        ];

        foreach ($languages as $lang) {
            foreach ($form_messages[$lang] as $field_key => $message) {
                $default_options["udet_{$lang}_{$field_key}"] = $message;
            }
            // Aggiungi anche l'email subject
            $default_options["udet_{$lang}_email_subject"] = $email_subjects[$lang];
            
            // Aggiungi il link privacy policy
            $default_options["udet_{$lang}_privacy_policy_link"] = $privacy_links[$lang];
            
            // Aggiungi l'anno di creazione (uguale per tutte le lingue)
            $default_options["udet_{$lang}_anno_creazione"] = date('Y');
        }

        foreach ($default_options as $option_key => $default_value) {
            if (!get_option($option_key)) {
                update_option($option_key, $default_value);
            }
        }

        // Ensure assets directory exists
        $this->ensure_directories();

        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Set activation flag
        update_option('iyl_data_activated', true);
        
        // Aggiorna i messaggi del form esistenti convertendo i caratteri speciali
        $this->update_existing_form_messages_encoding();
        
        // Force admin load after activation
        if (is_admin()) {
            $this->force_admin_load();
        }
    }

    public function deactivate_plugin() {
        // Clean up if needed
        flush_rewrite_rules();
        delete_option('iyl_data_activated');
    }

    private function needs_backward_compatibility() {
        // Check if old options exist
        $old_options = [
            'iyl_data_nome_sito',
            'iyl_data_dominio_sito',
            'iyl_data_email_contatto'
        ];

        foreach ($old_options as $option) {
            if (get_option($option)) {
                return true;
            }
        }

        return false;
    }

    private function load_backward_compatibility() {
        // Load the old admin class for backwards compatibility
        if (file_exists(IYL_DATA_PATH . 'includes/admin/class-iyl-data-admin.php')) {
        require_once IYL_DATA_PATH . 'includes/admin/class-iyl-data-admin.php';
        }

        // Old Elementor integration files are removed in v2.0 for security
        // Only data migration is maintained
    }

    private function maybe_migrate_data() {
        $migration_version = get_option('iyl_data_migration_version', '1.0.0');
        
        if (version_compare($migration_version, '2.0.0', '<')) {
            $this->migrate_to_version_2();
            update_option('iyl_data_migration_version', '2.0.0');
        }
    }

    private function migrate_to_version_2() {
        // Migrate old single-language data to new multilingual structure
        $old_to_new_mapping = [
            'iyl_data_nome_sito' => 'udet_it_nome_sito',
            'iyl_data_dominio_sito' => 'udet_it_dominio',
            'iyl_data_indirizzo' => 'udet_it_indirizzo',
            'iyl_data_indirizzo_link' => 'udet_it_link_indirizzo',
            'iyl_data_iframe_mappa' => 'udet_it_iframe_mappa',
            'iyl_data_email_contatto' => 'udet_it_email',
            'iyl_data_numero_di_telefono' => 'udet_it_telefono',
            'iyl_data_telefono_link' => 'udet_it_link_telefono',
            'iyl_data_whatsapp' => 'udet_it_whatsapp',
            'iyl_data_whatsapp_link' => 'udet_it_link_whatsapp',
            'iyl_data_codice_fiscale_piva' => 'udet_it_piva'
        ];

        foreach ($old_to_new_mapping as $old_key => $new_key) {
            $old_value = get_option($old_key);
            if (!empty($old_value) && !get_option($new_key)) {
                update_option($new_key, $old_value);
            }
        }

        // Migrate social data if exists
        $social_networks = ['facebook', 'instagram', 'youtube', 'twitter', 'linkedin', 'telegram', 'tiktok', 'pinterest'];
        foreach ($social_networks as $social) {
            $old_social_value = get_option("iyl_data_social_{$social}");
            if (!empty($old_social_value) && !get_option("udet_it_social_{$social}")) {
                update_option("udet_it_social_{$social}", $old_social_value);
            }
        }

        // Ensure Italian is active
        $active_languages = get_option('iyl_data_active_languages', []);
        if (!in_array('it', $active_languages)) {
            $active_languages[] = 'it';
            update_option('iyl_data_active_languages', $active_languages);
        }
    }

    public function debug_info() {
        if (!current_user_can('manage_options') || !isset($_GET['iyl_debug'])) {
            return;
        }

        echo '<!-- IYL Data Debug Info -->';
        echo '<div style="position: fixed; bottom: 10px; right: 10px; background: #333; color: #fff; padding: 10px; border-radius: 5px; z-index: 9999; font-size: 12px; max-width: 300px;">';
        echo '<strong>IYL Data Debug:</strong><br>';
        echo 'Version: ' . IYL_DATA_VERSION . '<br>';
        echo 'Path: ' . IYL_DATA_PATH . '<br>';
        echo 'URL: ' . IYL_DATA_URL . '<br>';
        echo 'Admin Instance: ' . (is_object($this->admin_instance) ? 'Yes' : 'No') . '<br>';
        echo 'Active Languages: ' . implode(', ', get_option('iyl_data_active_languages', [])) . '<br>';
        echo 'CSS File: ' . (file_exists(IYL_DATA_PATH . 'assets/css/admin.css') ? 'Exists' : 'Missing') . '<br>';
        echo 'JS File: ' . (file_exists(IYL_DATA_PATH . 'assets/js/admin.js') ? 'Exists' : 'Missing') . '<br>';
        echo 'Plugin Active: ' . (is_plugin_active(plugin_basename(__FILE__)) ? 'Yes' : 'No') . '<br>';
        echo '</div>';
    }

    public function get_admin_instance() {
        return $this->admin_instance;
    }

    /**
     * Aggiorna i messaggi del form esistenti convertendo i caratteri speciali in entità HTML
     */
    private function update_existing_form_messages_encoding() {
        $languages = ['it', 'en', 'es', 'fr', 'de'];
        $form_fields = ['form_success_message', 'form_error_message', 'form_server_error', 'form_invalid', 'form_privacy_message'];
        
        $special_chars = [
            'à' => '&agrave;',
            'á' => '&aacute;',
            'è' => '&egrave;',
            'é' => '&eacute;',
            'ì' => '&igrave;',
            'í' => '&iacute;',
            'ò' => '&ograve;',
            'ó' => '&oacute;',
            'ù' => '&ugrave;',
            'ú' => '&uacute;',
            'ç' => '&ccedil;',
            'ñ' => '&ntilde;',
            'ü' => '&uuml;',
            'ä' => '&auml;',
            'ö' => '&ouml;',
            'ß' => '&szlig;',
            'À' => '&Agrave;',
            'Á' => '&Aacute;',
            'È' => '&Egrave;',
            'É' => '&Eacute;',
            'Ì' => '&Igrave;',
            'Í' => '&Iacute;',
            'Ò' => '&Ograve;',
            'Ó' => '&Oacute;',
            'Ù' => '&Ugrave;',
            'Ú' => '&Uacute;',
            'Ç' => '&Ccedil;',
            'Ñ' => '&Ntilde;',
            'Ü' => '&Uuml;',
            'Ä' => '&Auml;',
            'Ö' => '&Ouml;'
        ];
        
        foreach ($languages as $lang_code) {
            foreach ($form_fields as $field_key) {
                $option_name = "udet_{$lang_code}_{$field_key}";
                $current_value = get_option($option_name, '');
                
                if (!empty($current_value)) {
                    // Controlla se il valore contiene già entità HTML
                    if (strpos($current_value, '&') === false) {
                        // Converti solo se non contiene già entità
                        $updated_value = str_replace(array_keys($special_chars), array_values($special_chars), $current_value);
                        
                        if ($updated_value !== $current_value) {
                            update_option($option_name, $updated_value);
                            error_log("IYL Data: Updated encoding for {$option_name}: {$current_value} -> {$updated_value}");
                        }
                    }
                }
            }
        }
    }
}

// Initialize the plugin IMMEDIATELY
$iyl_data_plugin = IYL_Data_Plugin::get_instance();

// Utility functions for developers
if (!function_exists('iyl_get_data')) {
    /**
     * Get IYL data value by field key and language
     * 
     * @param string $field_key The field key
     * @param string $lang_code The language code (optional, auto-detects if not provided)
     * @param string $default Default value if not found
     * @return string The field value
     */
    function iyl_get_data($field_key, $lang_code = null, $default = '') {
        if (is_null($lang_code)) {
            if (function_exists('pll_current_language')) {
                $lang_code = pll_current_language();
            } else {
                $lang_code = 'it';
            }
        }

        $value = get_option("udet_{$lang_code}_{$field_key}", '');
        
        // Fallback to Italian if empty and not Italian
        if (empty($value) && $lang_code !== 'it') {
            $value = get_option("udet_it_{$field_key}", '');
        }
        
        return !empty($value) ? $value : $default;
    }
}

if (!function_exists('iyl_get_social_link')) {
    /**
     * Get social media link by platform and language
     * 
     * @param string $platform The social platform key
     * @param string $lang_code The language code (optional, auto-detects if not provided)
     * @return string The social media URL
     */
    function iyl_get_social_link($platform, $lang_code = null) {
        if (is_null($lang_code)) {
            if (function_exists('pll_current_language')) {
                $lang_code = pll_current_language();
            } else {
                $lang_code = 'it';
            }
        }

        $value = get_option("udet_{$lang_code}_social_{$platform}", '');
        if (empty($value)) {
            return '';
        }

        // Controlla se il valore è già un URL completo
        if (iyl_str_starts_with($value, 'http://') || iyl_str_starts_with($value, 'https://')) {
            return $value; // Restituisci l'URL completo così com'è
        }

        // Altrimenti trattalo come username e concatena con base_url
        $base_urls = [
            'facebook' => 'https://facebook.com/',
            'instagram' => 'https://instagram.com/',
            'linkedin' => 'https://linkedin.com/company/',
            'twitter' => 'https://twitter.com/',
            'pinterest' => 'https://pinterest.com/'
        ];

        $base_url = $base_urls[$platform] ?? '';
        return !empty($base_url) ? $base_url . $value : '';
    }
}

if (!function_exists('iyl_get_phone_link')) {
    /**
     * Get formatted phone link
     * 
     * @param string $field_type 'telefono' or 'cellulare'
     * @param string $lang_code The language code (optional, auto-detects if not provided)
     * @return string The tel: link
     */
    function iyl_get_phone_link($field_type, $lang_code = null) {
        if (is_null($lang_code)) {
            if (function_exists('pll_current_language')) {
                $lang_code = pll_current_language();
            } else {
                $lang_code = 'it';
            }
        }

        $phone = get_option("udet_{$lang_code}_{$field_type}", '');
        if (empty($phone)) {
            return '';
        }

        // Clean phone and add +39 if needed
        $clean_phone = preg_replace('/[^0-9+]/', '', $phone);
        if (!iyl_str_starts_with($clean_phone, '+')) {
            $clean_phone = '+39' . ltrim($clean_phone, '39');
        }

        return 'tel:' . $clean_phone;
    }
}

if (!function_exists('iyl_get_whatsapp_link')) {
    /**
     * Get WhatsApp link
     * 
     * @param string $lang_code The language code (optional, auto-detects if not provided)
     * @return string The WhatsApp URL
     */
    function iyl_get_whatsapp_link($lang_code = null) {
        if (is_null($lang_code)) {
            if (function_exists('pll_current_language')) {
                $lang_code = pll_current_language();
            } else {
                $lang_code = 'it';
            }
        }

        $whatsapp = get_option("udet_{$lang_code}_whatsapp", '');
        if (empty($whatsapp)) {
            return '';
        }

        // Clean WhatsApp and add +39 if needed
        $clean_whatsapp = preg_replace('/[^0-9+]/', '', $whatsapp);
        if (!iyl_str_starts_with($clean_whatsapp, '+')) {
            $clean_whatsapp = '+39' . ltrim($clean_whatsapp, '39');
        }

        return 'https://wa.me/' . $clean_whatsapp;
    }
}

if (!function_exists('iyl_get_email_link')) {
    /**
     * Get email link with subject
     * 
     * @param string $lang_code The language code (optional, auto-detects if not provided)
     * @return string The mailto: link
     */
    function iyl_get_email_link($lang_code = null) {
        if (is_null($lang_code)) {
            if (function_exists('pll_current_language')) {
                $lang_code = pll_current_language();
            } else {
                $lang_code = 'it';
            }
        }

        $email = get_option("udet_{$lang_code}_email", '');
        if (empty($email)) {
            return '';
        }

        $subject = get_option("udet_{$lang_code}_email_subject", '');
        
        // Fallback ai subject predefiniti se non impostato
        if (empty($subject)) {
            $default_subjects = [
                'it' => 'Nuova richiesta di contatto',
                'en' => 'New contact request',
                'es' => 'Nueva solicitud de contacto',
                'fr' => 'Nouvelle demande de contact',
                'de' => 'Neue Kontaktanfrage'
            ];
            $subject = $default_subjects[$lang_code] ?? $default_subjects['it'];
        }
        
        $dominio = get_option("udet_{$lang_code}_dominio", '');
        
        $full_subject = $subject . ' ' . $dominio;
        
        return 'mailto:' . $email . '?subject=' . rawurlencode($full_subject);
    }
}

// Shortcode: [dynamic_year] - Copyright dinamico multilingua
if (!function_exists('iyl_dynamic_year_shortcode')) {
    /**
     * Dynamic year shortcode with multilingual support
     * Usage: [dynamic_year]
     * 
     * @return string Copyright string with dynamic year and multilingual text
     */
    function iyl_dynamic_year_shortcode() {
        // Rileva la lingua corrente
        $lang_code = 'it'; // Default
        if (function_exists('pll_current_language')) {
            $lang_code = pll_current_language() ?: 'it';
        }
        
        // Ottieni l'anno di creazione dalle impostazioni del plugin
        $creation_year = get_option("udet_{$lang_code}_anno_creazione", '');
        
        // Fallback se non trovato nella lingua corrente, prova italiano
        if (empty($creation_year) && $lang_code !== 'it') {
            $creation_year = get_option("udet_it_anno_creazione", '');
        }
        
        // Fallback finale all'anno corrente se non impostato
        if (empty($creation_year)) {
            $creation_year = date('Y');
        }
        
        $current_year = date('Y');
        $site_name = get_option("udet_{$lang_code}_nome_sito", '') ?: get_bloginfo('name');
        
        // Mappa per testi multilingua
        $text_map = [
            'it' => '- Tutti i diritti riservati. Siti Internet by <a href="https://www.inyourlife.info" target="_blank">InYourLife</a>',
            'en' => '- All rights reserved. Websites by <a href="https://www.inyourlife.info" target="_blank">InYourLife</a>',
            'de' => '- Alle Rechte vorbehalten. Websites von <a href="https://www.inyourlife.info" target="_blank">InYourLife</a>',
            'fr' => '- Tous droits réservés. Sites web par <a href="https://www.inyourlife.info" target="_blank">InYourLife</a>',
            'es' => '- Todos los derechos reservados. Sitios web por <a href="https://www.inyourlife.info" target="_blank">InYourLife</a>'
        ];
        
        $suffix = $text_map[$lang_code] ?? $text_map['it'];
        
        // Calcola l'output dell'anno
        $year_output = ($current_year != $creation_year) 
            ? "{$creation_year} - {$current_year}" 
            : $creation_year;
        
        return sprintf(
            '%s - Copyright © %s %s',
            esc_html($site_name),
            esc_html($year_output),
            $suffix
        );
    }
}

// Registra lo shortcode
add_shortcode('dynamic_year', 'iyl_dynamic_year_shortcode'); 