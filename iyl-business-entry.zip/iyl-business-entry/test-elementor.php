<?php
/**
 * Test Elementor Integration - IYL Data
 * 
 * Aggiungi ?iyl_test_elementor=1 alla URL per attivare questo test
 * RIMUOVI dopo aver risolto i problemi!
 */

if (!defined('ABSPATH') || !isset($_GET['iyl_test_elementor'])) {
    exit;
}

// Solo per amministratori
if (!current_user_can('manage_options')) {
    wp_die('Non autorizzato');
}

echo '<div style="background: #f1f1f1; padding: 20px; margin: 20px; border-radius: 8px; font-family: Arial, sans-serif;">';
echo '<h1 style="color: #333;">🧪 Test Elementor Integration - IYL Data</h1>';

// Test 1: Elementor disponibile
echo '<h2>1. ✅ Verifica Elementor</h2>';
$elementor_loaded = did_action('elementor/loaded');
$elementor_class = class_exists('\Elementor\Plugin');
$elementor_active = is_plugin_active('elementor/elementor.php');

echo '<ul>';
echo '<li>Elementor hook loaded: ' . ($elementor_loaded ? '✅ Si' : '❌ No') . '</li>';
echo '<li>Elementor classe disponibile: ' . ($elementor_class ? '✅ Si' : '❌ No') . '</li>';
echo '<li>Elementor plugin attivo: ' . ($elementor_active ? '✅ Si' : '❌ No') . '</li>';
echo '</ul>';

if (!$elementor_loaded || !$elementor_class) {
    echo '<div style="background: #fff3cd; border: 1px solid #ffecb5; color: #856404; padding: 15px; border-radius: 5px;">';
    echo '<h3>⚠️ Elementor non disponibile</h3>';
    echo '<p>Installa e attiva Elementor per utilizzare i Dynamic Tags.</p>';
    echo '</div>';
    echo '</div>';
    return;
}

// Test 2: File IYL Data
echo '<h2>2. 📁 Verifica File Plugin</h2>';
$iyl_files = [
    'File principale' => IYL_DATA_PATH . 'iyl-data-for-elementor.php',
    'Classe Admin' => IYL_DATA_PATH . 'includes/admin/class-iyl-data-multilang-admin.php',
    'Integrazione Elementor' => IYL_DATA_PATH . 'includes/elementor/class-iyl-data-multilang-elementor.php',
    'Base Tag Class' => IYL_DATA_PATH . 'includes/elementor/tags/class-iyl-multilang-tag-base.php'
];

echo '<ul>';
foreach ($iyl_files as $desc => $file) {
    $exists = file_exists($file);
    echo '<li>' . $desc . ': ' . ($exists ? '✅ Esiste' : '❌ Mancante') . '</li>';
}
echo '</ul>';

// Test 3: Classi caricate
echo '<h2>3. 🔧 Verifica Classi</h2>';
$iyl_classes = [
    'IYL_Data_Plugin',
    'IYL_Data_Multilang_Admin',
    'IYL_Data_Multilang_Elementor',
    'IYL_Multilang_Tag_Base',
    'IYL_Dynamic_Data_Tag',
    'IYL_Dynamic_Social_Tag'
];

echo '<ul>';
foreach ($iyl_classes as $class) {
    $exists = class_exists($class);
    echo '<li>' . $class . ': ' . ($exists ? '✅ Caricata' : '❌ Non caricata') . '</li>';
}
echo '</ul>';

// Test 4: Dynamic Tags registrati
echo '<h2>4. 🏷️ Verifica Dynamic Tags</h2>';
if (class_exists('\Elementor\Plugin') && isset(\Elementor\Plugin::$instance->dynamic_tags)) {
    $dynamic_tags = \Elementor\Plugin::$instance->dynamic_tags;
    $tags = $dynamic_tags->get_tags();
    
    echo '<p>Totale Dynamic Tags registrati: <strong>' . count($tags) . '</strong></p>';
    
    // Cerca tag IYL
    $iyl_tags = [];
    foreach ($tags as $tag_name => $tag_object) {
        if (strpos($tag_name, 'user-data-') === 0) {
            $iyl_tags[] = $tag_name;
        }
    }
    
    echo '<p>Tag IYL trovati: <strong>' . count($iyl_tags) . '</strong></p>';
    
    if (!empty($iyl_tags)) {
        echo '<details>';
        echo '<summary>Mostra tag IYL (click per espandere)</summary>';
        echo '<ul style="max-height: 200px; overflow-y: auto; margin: 10px 0;">';
        foreach ($iyl_tags as $tag) {
            echo '<li><code>' . $tag . '</code></li>';
        }
        echo '</ul>';
        echo '</details>';
    }
} else {
    echo '<p>❌ Dynamic Tags system non disponibile</p>';
}

// Test 5: Gruppi registrati
echo '<h2>5. 📂 Verifica Gruppi</h2>';
if (class_exists('\Elementor\Plugin') && isset(\Elementor\Plugin::$instance->dynamic_tags)) {
    $groups = \Elementor\Plugin::$instance->dynamic_tags->get_groups();
    
    echo '<p>Totale gruppi registrati: <strong>' . count($groups) . '</strong></p>';
    
    // Cerca gruppi IYL
    $iyl_groups = [];
    foreach ($groups as $group_id => $group_data) {
        if (strpos($group_id, 'user-data-') === 0) {
            $iyl_groups[$group_id] = $group_data;
        }
    }
    
    echo '<p>Gruppi IYL trovati: <strong>' . count($iyl_groups) . '</strong></p>';
    
    if (!empty($iyl_groups)) {
        echo '<ul>';
        foreach ($iyl_groups as $group_id => $group_data) {
            echo '<li><strong>' . $group_id . '</strong>: ' . ($group_data['title'] ?? 'Senza titolo') . '</li>';
        }
        echo '</ul>';
    }
} else {
    echo '<p>❌ Groups system non disponibile</p>';
}

// Test 6: Test creazione tag
echo '<h2>6. 🧪 Test Creazione Tag</h2>';
try {
    // Simula creazione di un tag
    if (class_exists('IYL_Dynamic_Data_Tag') && class_exists('IYL_Multilang_Tag_Base')) {
        $test_lang_data = ['flag' => '🇮🇹', 'name' => 'Italiano'];
        $test_tag = new IYL_Dynamic_Data_Tag('nome_sito', 'Nome Sito', 'it', $test_lang_data);
        
        echo '<ul>';
        echo '<li>Tag name: <code>' . $test_tag->get_name() . '</code> ✅</li>';
        echo '<li>Tag title: ' . $test_tag->get_title() . ' ✅</li>';
        echo '<li>Tag group: <code>' . $test_tag->get_group() . '</code> ✅</li>';
        echo '<li>Tag categories: ' . implode(', ', $test_tag->get_categories()) . ' ✅</li>';
        echo '</ul>';
        
        echo '<p>✅ Test creazione tag superato!</p>';
    } else {
        echo '<p>❌ Classi tag non disponibili per test</p>';
    }
} catch (Exception $e) {
    echo '<p>❌ Errore durante test creazione tag: ' . esc_html($e->getMessage()) . '</p>';
}

// Test 7: Dati disponibili
echo '<h2>7. 💾 Verifica Dati</h2>';
$active_languages = get_option('iyl_data_active_languages', []);
echo '<p>Lingue attive: ' . (empty($active_languages) ? '❌ Nessuna' : '✅ ' . implode(', ', $active_languages)) . '</p>';

if (!empty($active_languages)) {
    echo '<table style="width: 100%; border-collapse: collapse; margin: 10px 0;">';
    echo '<tr style="background: #f9f9f9;">';
    echo '<th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Lingua</th>';
    echo '<th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Nome Sito</th>';
    echo '<th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Email</th>';
    echo '<th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Telefono</th>';
    echo '</tr>';
    
    foreach ($active_languages as $lang) {
        $nome_sito = get_option("udet_{$lang}_nome_sito", '');
        $email = get_option("udet_{$lang}_email", '');
        $telefono = get_option("udet_{$lang}_telefono", '');
        
        echo '<tr>';
        echo '<td style="border: 1px solid #ddd; padding: 8px;">' . strtoupper($lang) . '</td>';
        echo '<td style="border: 1px solid #ddd; padding: 8px;">' . (empty($nome_sito) ? '❌ Vuoto' : '✅ ' . esc_html($nome_sito)) . '</td>';
        echo '<td style="border: 1px solid #ddd; padding: 8px;">' . (empty($email) ? '❌ Vuoto' : '✅ ' . esc_html($email)) . '</td>';
        echo '<td style="border: 1px solid #ddd; padding: 8px;">' . (empty($telefono) ? '❌ Vuoto' : '✅ ' . esc_html($telefono)) . '</td>';
        echo '</tr>';
    }
    echo '</table>';
}

// Test 8: Logs degli errori
echo '<h2>8. 📋 Controllo Errori</h2>';
$error_log_file = WP_CONTENT_DIR . '/debug.log';
if (file_exists($error_log_file)) {
    $log_content = file_get_contents($error_log_file);
    $iyl_errors = [];
    
    $lines = explode("\n", $log_content);
    foreach (array_reverse($lines) as $line) {
        if (stripos($line, 'iyl') !== false && count($iyl_errors) < 10) {
            $iyl_errors[] = $line;
        }
    }
    
    if (!empty($iyl_errors)) {
        echo '<div style="background: #fff3cd; border: 1px solid #ffecb5; color: #856404; padding: 15px; border-radius: 5px;">';
        echo '<h4>⚠️ Errori recenti trovati nei log:</h4>';
        echo '<pre style="background: #fff; padding: 10px; border-radius: 3px; overflow-x: auto; max-height: 200px;">';
        foreach ($iyl_errors as $error) {
            echo esc_html($error) . "\n";
        }
        echo '</pre>';
        echo '</div>';
    } else {
        echo '<p>✅ Nessun errore IYL trovato nei log recenti</p>';
    }
} else {
    echo '<p>ℹ️ File di log non disponibile (debug.log)</p>';
}

// Conclusioni e soluzioni
echo '<h2>🎯 Conclusioni e Soluzioni</h2>';

$issues = [];
if (!$elementor_loaded || !$elementor_class) $issues[] = 'Elementor non disponibile';
if (!class_exists('IYL_Data_Multilang_Elementor')) $issues[] = 'Classe integrazione mancante';
if (empty($active_languages)) $issues[] = 'Nessuna lingua attiva';

if (empty($issues)) {
    echo '<div style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px;">';
    echo '<h3>🎉 Tutto Sembra Funzionare!</h3>';
    echo '<p>L\'integrazione con Elementor dovrebbe funzionare correttamente.</p>';
    echo '<p><strong>Prossimi passi:</strong></p>';
    echo '<ul>';
    echo '<li>Vai su una pagina di Elementor</li>';
    echo '<li>Aggiungi un widget di testo</li>';
    echo '<li>Clicca sull\'icona Dynamic Content (⚡)</li>';
    echo '<li>Cerca i gruppi "🇮🇹 IYL Data - Italiano"</li>';
    echo '<li><strong>RIMUOVI QUESTO FILE DI TEST!</strong></li>';
    echo '</ul>';
    echo '</div>';
} else {
    echo '<div style="background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px;">';
    echo '<h3>⚠️ Problemi Rilevati</h3>';
    echo '<ul>';
    foreach ($issues as $issue) {
        echo '<li>' . $issue . '</li>';
    }
    echo '</ul>';
    echo '<p><strong>Soluzioni:</strong></p>';
    echo '<ul>';
    echo '<li>Installa e attiva Elementor se mancante</li>';
    echo '<li>Riattiva il plugin IYL Data</li>';
    echo '<li>Configura almeno una lingua in IYL Data Admin</li>';
    echo '<li>Controlla i log degli errori sopra</li>';
    echo '</ul>';
    echo '</div>';
}

echo '<div style="background: #fff3cd; border: 1px solid #ffecb5; color: #856404; padding: 15px; border-radius: 5px; margin-top: 20px;">';
echo '<h3>⚠️ IMPORTANTE</h3>';
echo '<p><strong>Rimuovi questo file di test dopo aver risolto i problemi!</strong></p>';
echo '<p>URL: <code>' . __FILE__ . '</code></p>';
echo '</div>';

echo '</div>';
?> 