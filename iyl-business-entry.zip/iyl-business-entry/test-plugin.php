<?php
/**
 * IYL Data Plugin Test File
 * 
 * Questo file serve per testare tutte le funzionalità del plugin
 * IMPORTANTE: Rimuovi questo file dopo i test!
 */

if (!defined('ABSPATH')) {
    exit;
}

// Verifica se il plugin è attivo
if (!function_exists('iyl_get_data')) {
    wp_die('IYL Data Plugin non è attivo!');
}

echo '<div style="background: #f1f1f1; padding: 20px; margin: 20px; border-radius: 8px; font-family: Arial, sans-serif;">';
echo '<h1 style="color: #333;">🧪 IYL Data Plugin - Test Suite</h1>';

// Test 1: Verifica costanti
echo '<h2>1. ✅ Verifica Costanti</h2>';
echo '<ul>';
echo '<li>Version: ' . (defined('IYL_DATA_VERSION') ? IYL_DATA_VERSION : '❌ Non definita') . '</li>';
echo '<li>Path: ' . (defined('IYL_DATA_PATH') ? IYL_DATA_PATH : '❌ Non definito') . '</li>';
echo '<li>URL: ' . (defined('IYL_DATA_URL') ? IYL_DATA_URL : '❌ Non definito') . '</li>';
echo '</ul>';

// Test 2: Verifica file
echo '<h2>2. 📁 Verifica File</h2>';
$files_to_check = [
    'assets/css/admin.css',
    'assets/js/admin.js',
    'includes/admin/class-iyl-data-multilang-admin.php',
    'includes/elementor/class-iyl-data-multilang-elementor.php',
    'includes/elementor/tags/class-iyl-multilang-tag-base.php'
];

echo '<ul>';
foreach ($files_to_check as $file) {
    $full_path = IYL_DATA_PATH . $file;
    $exists = file_exists($full_path);
    echo '<li>' . $file . ': ' . ($exists ? '✅ Esiste' : '❌ Mancante') . '</li>';
}
echo '</ul>';

// Test 3: Verifica opzioni
echo '<h2>3. ⚙️ Verifica Opzioni</h2>';
$active_languages = get_option('iyl_data_active_languages', []);
echo '<p><strong>Lingue Attive:</strong> ' . (empty($active_languages) ? '❌ Nessuna' : '✅ ' . implode(', ', $active_languages)) . '</p>';

// Test alcuni valori
$test_values = [
    'udet_it_nome_sito' => 'Nome Sito IT',
    'udet_it_email' => 'Email IT',
    'udet_it_telefono' => 'Telefono IT',
    'udet_it_email_subject' => 'Subject Email IT'
];

echo '<ul>';
foreach ($test_values as $option => $description) {
    $value = get_option($option);
    echo '<li>' . $description . ': ' . (empty($value) ? '❌ Vuoto' : '✅ ' . esc_html($value)) . '</li>';
}
echo '</ul>';

// Test 4: Verifica funzioni helper
echo '<h2>4. 🔧 Verifica Funzioni Helper</h2>';
$helper_functions = [
    'iyl_get_data',
    'iyl_get_social_link',
    'iyl_get_phone_link',
    'iyl_get_whatsapp_link',
    'iyl_get_email_link'
];

echo '<ul>';
foreach ($helper_functions as $function) {
    $exists = function_exists($function);
    echo '<li>' . $function . ': ' . ($exists ? '✅ Disponibile' : '❌ Mancante') . '</li>';
}
echo '</ul>';

// Test 5: Test pratici delle funzioni
echo '<h2>5. 🧪 Test Pratici</h2>';

// Aggiungi dati di test
update_option('udet_it_nome_sito', 'Test Azienda');
update_option('udet_it_email', 'test@example.com');
update_option('udet_it_telefono', '1234567890');
update_option('udet_it_whatsapp', '1234567890');
update_option('udet_it_dominio', 'https://example.com');
update_option('udet_it_email_subject', 'Test Subject');
update_option('udet_it_social_facebook', 'testpage');

echo '<ul>';

// Test iyl_get_data
$nome_sito = iyl_get_data('nome_sito');
echo '<li>iyl_get_data(\'nome_sito\'): ' . ($nome_sito ? '✅ ' . esc_html($nome_sito) : '❌ Vuoto') . '</li>';

// Test iyl_get_email_link
$email_link = iyl_get_email_link();
echo '<li>iyl_get_email_link(): ' . ($email_link ? '✅ ' . esc_html($email_link) : '❌ Vuoto') . '</li>';

// Test iyl_get_phone_link
$phone_link = iyl_get_phone_link('telefono');
echo '<li>iyl_get_phone_link(\'telefono\'): ' . ($phone_link ? '✅ ' . esc_html($phone_link) : '❌ Vuoto') . '</li>';

// Test iyl_get_whatsapp_link
$whatsapp_link = iyl_get_whatsapp_link();
echo '<li>iyl_get_whatsapp_link(): ' . ($whatsapp_link ? '✅ ' . esc_html($whatsapp_link) : '❌ Vuoto') . '</li>';

// Test iyl_get_social_link
$facebook_link = iyl_get_social_link('facebook');
echo '<li>iyl_get_social_link(\'facebook\'): ' . ($facebook_link ? '✅ ' . esc_html($facebook_link) : '❌ Vuoto') . '</li>';

echo '</ul>';

// Test 6: Verifica Elementor
echo '<h2>6. ⚡ Verifica Elementor</h2>';
$elementor_active = did_action('elementor/loaded') || class_exists('\Elementor\Plugin');
echo '<p>Elementor: ' . ($elementor_active ? '✅ Attivo' : '❌ Non attivo') . '</p>';

if ($elementor_active) {
    echo '<p>✅ Dynamic Tags dovrebbero essere disponibili</p>';
} else {
    echo '<p>ℹ️ Installa Elementor per testare i Dynamic Tags</p>';
}

// Test 7: Verifica classi admin
echo '<h2>7. 👨‍💼 Verifica Classi Admin</h2>';
$admin_classes = [
    'IYL_Data_Plugin',
    'IYL_Data_Multilang_Admin',
    'IYL_Data_Multilang_Elementor',
    'IYL_Multilang_Tag_Base'
];

echo '<ul>';
foreach ($admin_classes as $class) {
    $exists = class_exists($class);
    echo '<li>' . $class . ': ' . ($exists ? '✅ Caricata' : '❌ Mancante') . '</li>';
}
echo '</ul>';

// Test 8: Verifica permessi
echo '<h2>8. 🔐 Verifica Permessi</h2>';
echo '<ul>';
echo '<li>Utente corrente: ' . wp_get_current_user()->user_login . '</li>';
echo '<li>Può gestire opzioni: ' . (current_user_can('manage_options') ? '✅ Si' : '❌ No') . '</li>';
echo '<li>È admin: ' . (current_user_can('administrator') ? '✅ Si' : '❌ No') . '</li>';
echo '</ul>';

// Test 9: Performance
echo '<h2>9. ⚡ Test Performance</h2>';
$start_time = microtime(true);

// Test 100 chiamate alle funzioni
for ($i = 0; $i < 100; $i++) {
    iyl_get_data('nome_sito');
    iyl_get_email_link();
    iyl_get_phone_link('telefono');
}

$end_time = microtime(true);
$execution_time = ($end_time - $start_time) * 1000; // in milliseconds

echo '<p>100 chiamate alle funzioni: ' . number_format($execution_time, 2) . ' ms</p>';
echo '<p>' . ($execution_time < 100 ? '✅ Performance Ottime' : '⚠️ Performance da migliorare') . '</p>';

// Conclusioni
echo '<h2>🎯 Conclusioni</h2>';
echo '<div style="background: #fff; padding: 15px; border-radius: 5px; border-left: 4px solid #00a0d2;">';

$issues = 0;

// Conta problemi
if (!defined('IYL_DATA_VERSION')) $issues++;
if (empty($active_languages)) $issues++;
if (!function_exists('iyl_get_data')) $issues++;
if (!class_exists('IYL_Data_Plugin')) $issues++;

if ($issues === 0) {
    echo '<h3 style="color: #00a32a;">🎉 Tutto Funziona Perfettamente!</h3>';
    echo '<p>Il plugin IYL Data è installato e configurato correttamente. Tutte le funzionalità sono operative.</p>';
    echo '<p><strong>Prossimi passi:</strong></p>';
    echo '<ul>';
    echo '<li>Vai su <strong>IYL Data</strong> nel menu admin per configurare i tuoi dati</li>';
    echo '<li>Attiva le lingue che ti servono</li>';
    echo '<li>Compila i campi per ogni lingua</li>';
    echo '<li>Usa i Dynamic Tags in Elementor</li>';
    echo '<li><strong>RIMUOVI QUESTO FILE DI TEST!</strong></li>';
    echo '</ul>';
} else {
    echo '<h3 style="color: #d63638;">⚠️ Problemi Rilevati (' . $issues . ')</h3>';
    echo '<p>Ci sono alcuni problemi da risolvere:</p>';
    echo '<ul>';
    if (!defined('IYL_DATA_VERSION')) echo '<li>Costanti del plugin non definite</li>';
    if (empty($active_languages)) echo '<li>Nessuna lingua attiva</li>';
    if (!function_exists('iyl_get_data')) echo '<li>Funzioni helper non disponibili</li>';
    if (!class_exists('IYL_Data_Plugin')) echo '<li>Classe principale non caricata</li>';
    echo '</ul>';
    echo '<p><strong>Soluzioni:</strong></p>';
    echo '<ul>';
    echo '<li>Disattiva e riattiva il plugin</li>';
    echo '<li>Controlla che tutti i file siano presenti</li>';
    echo '<li>Verifica i permessi delle cartelle</li>';
    echo '<li>Controlla i log di errore di WordPress</li>';
    echo '</ul>';
}

echo '</div>';

// Warning finale
echo '<div style="background: #fff3cd; border: 1px solid #ffecb5; color: #856404; padding: 15px; border-radius: 5px; margin-top: 20px;">';
echo '<h3>⚠️ IMPORTANTE</h3>';
echo '<p><strong>Questo file di test contiene informazioni sensibili e deve essere rimosso dopo l\'uso!</strong></p>';
echo '<p>Per rimuoverlo: <code>rm ' . __FILE__ . '</code></p>';
echo '</div>';

echo '</div>';

// Aggiungi link per tornare all'admin
echo '<p style="text-align: center; margin-top: 20px;">';
echo '<a href="' . admin_url('admin.php?page=iyl-data-multilang') . '" class="button button-primary">🔙 Torna a IYL Data Admin</a>';
echo '</p>';
?> 